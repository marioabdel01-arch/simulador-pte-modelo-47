function x = pte47_clamp(x, P)
%PTE47_CLAMP  Aplica al VECTOR DE ESTADO los mismos limites que digpte47
%             aplica a sus copias locales (anti-windup).
%
%   x = PTE47_CLAMP(x, P)
%
%   En el modelo original de Usoro (Fortran + DYSYS) las variables de
%   control vivian en COMMON: la linea  c3md = limchk(c3md)  recortaba la
%   variable de estado misma, asi que el integrador nunca se cargaba mas
%   alla de su limite.  En el port a MATLAB el estado vive en x(23) y
%   limchk solo recorta la copia local, asi que el integrador SI se carga
%   (windup) y tarda mucho o nunca en volver.
%
%   Esta funcion restaura el comportamiento original recortando el estado
%   despues de cada paso RK4.  Se activa con
%       R = pte47_run(4, 'clampStates', true);
%   y por omision esta APAGADA, para que el resultado siga siendo
%   identico al del codigo original.
%
%   Se usan las mismas funciones limchk/check del modelo, asi que los
%   limites son por construccion los mismos, sin duplicar constantes.
%
%   Estados afectados (23..46), segun las llamadas del cuerpo de digpte47:
%       limchk : 23 c3md  24 c5ar  25 c5fl  26 c3fn  27 c2gr  28 c2ft
%                30 c7fv  32 c8dv  33 c5rh  34 c5sy
%                35 card  36 cfld  37 cfnd  38 cgrd  39 cftd
%                40 cfwd  41 cdwd  42 cxggd 43 csyd
%       check  : 29 c3fv [-5,5]   31 c3dv [-5,5]   44 c2tr [-1,1]
%                45 c4tr [0,5]    46 cacvd [0,5]
%
%   Nota: x(38) (cgrd) lleva ademas check(cgrd,kcwgr,kcl) dentro del
%   modelo, con un limite superior kcwgr que depende de wfl y por eso no
%   se puede aplicar aqui; solo se aplica el limchk.
%
%   Los estados 35..43 son retardos de 1er orden (xdot = (u-x)/tau) y no
%   se cargan por si mismos, pero se recortan igual por consistencia.
%
%   See also PTE47_RUN, DIGPTE47.

for k = [23 24 25 26 27 28 30 32 33 34 35 36 37 38 39 40 41 42 43]
    x(k) = limchk(x(k));
end

x(29) = check(x(29), P.kn5, P.km5);     % c3fv
x(31) = check(x(31), P.kn5, P.km5);     % c3dv
x(44) = check(x(44), P.kn1, P.km1);     % c2tr
x(45) = check(x(45), P.kn5, P.kn0);     % c4tr
x(46) = check(x(46), P.kn5, P.kn0);     % cacvd

end
