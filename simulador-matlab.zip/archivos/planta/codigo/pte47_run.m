function R = pte47_run(caseName, varargin)
%PTE47_RUN  Fixed-step RK4 simulation of the 47-state Usoro plant model.
%
%   R = PTE47_RUN(N)                          N = 1..4, prueba de la tesis
%   R = PTE47_RUN(NAME)                       NAME = '100' | '775' | '50'
%   R = PTE47_RUN(..., 'field', value, ...)   overrides any field of P
%
%   Con un numero corre una de las cuatro pruebas de carga del capitulo V
%   de la tesis, con su caso inicial y su rampa ya puestos (ver PTE47_TEST):
%       1: 100% -> 77.5%    2: 77.5% -> 50%
%       3: 50%  -> 77.5%    4: 77.5% -> 100%
%   Con un nombre de caso corre ese estado inicial con la rampa por
%   omision (la de la prueba 1), que es lo que hacia el codigo original.
%
%   Classic 4th-order Runge-Kutta at Ts = 0.1 s, the same scheme the thesis
%   used (DYSYS, p.49).  RK4 is stable for the undamped ntr/delta swing pair;
%   the earlier frozen-derivative scheme (equivalent to explicit Euler) is
%   not, which is why those states used to be frozen.
%
%   R is a struct with
%       R.t      (samples+1) x 1   time of each stored state row
%       R.xx     (samples+1) x 47  state trajectory (row per step, x0 first)
%       R.xx2    nlog x 25         log rows, one per second, for plotting
%       R.res    47 x (samples+2)  [ (1:47)'  xx' ], as in the old scripts
%       R.P      the constant struct actually used
%
%   Useful overrides:
%       'samples'   number of RK4 steps
%       'ldcStart', 'ldcRate', 'ldcT0', 'ldcT1'   load-demand ramp
%       'x0'        alternative initial state
%
%   Example:
%       R = pte47_run('775');            pte47_plot(R);
%       R = pte47_run('50', 'ldcStart', 2.5, 'ldcRate', 0.0125);
%
%   See also PTE47_PARAMS, DIGPTE47, PTE47_PLOT.

if nargin < 1 || isempty(caseName), caseName = '100'; end

% Numero de prueba -> caso + rampa.  Los overrides del usuario van despues,
% asi que ganan sobre los de la prueba.
if isnumeric(caseName)
    [caseName, ramp_] = pte47_test(caseName);
    varargin = [ramp_, varargin];
end

P  = pte47_params(caseName, varargin{:});
Ts = P.Ts;
n  = P.samples;
x  = P.x0(:);
nx = numel(x);

% ---- preallocation ------------------------------------------------------
% The original scripts grew xx and xx2 with xx=[xx;x0'] inside the loop,
% which reallocates and copies the whole array on every one of the 7001
% iterations.  Both are preallocated here and trimmed at the end.
xx        = zeros(n+1, nx);
xx(1, :)  = x.';
tvec      = zeros(n+1, 1);

useStride = ~isempty(P.logStride);
if useStride
    nlog = floor((n-1)/P.logStride) + 2;
else
    nlog = floor(n*Ts) + 2;
end
xx2       = zeros(nlog, 38);
klog      = 0;
tprint    = 0;

t = -Ts;

% -------------------------------------------------------------------------
% ---------                  >>>   MAIN LOOP   <<<                   ------
% -------------------------------------------------------------------------
for i = 1:n
    t  = t + Ts;
    t0 = t - Ts;

    % classic RK4 step from t0 to t0+Ts.  The log row is only requested on
    % the sample that is actually stored, so ylog is built ~700 times
    % instead of 7001.
    if useStride
        doLog = (mod(i-1, P.logStride) == 0);   % entero exacto, sin deriva
    else
        doLog = (t >= tprint);
    end
    if doLog
        [xd1, ylog] = digpte47(t0, x, P);
        klog        = klog + 1;
        xx2(klog,:) = ylog;
        tprint      = tprint + 1;
    else
        xd1 = digpte47(t0, x, P);
    end

    xd2 = digpte47(t0 + Ts/2, x + (Ts/2)*xd1, P);
    xd3 = digpte47(t0 + Ts/2, x + (Ts/2)*xd2, P);
    xd4 = digpte47(t0 + Ts,   x +  Ts   *xd3, P);

    x = x + (Ts/6)*(xd1 + 2*xd2 + 2*xd3 + xd4);

    % anti-windup opcional: recorta los estados de control 23..46 con los
    % mismos limchk/check del modelo (ver pte47_clamp).  Apagado por
    % omision para reproducir exactamente el codigo original.
    if P.clampStates
        x = pte47_clamp(x, P);
    end

    xx(i+1, :) = x.';
    tvec(i+1)  = t;

    if P.stopOnNaN && ~all(isfinite(x))
        warning('pte47_run:diverged', ...
            ['Non-finite state at t = %g s (step %d), states [%s]. ' ...
             'Stopping and returning the partial trajectory.'], ...
            t, i, num2str(find(~isfinite(x)).'));
        xx   = xx(1:i+1, :);
        tvec = tvec(1:i+1);
        break
    end
end

xx2 = xx2(1:klog, :);

R.t    = tvec;
R.xx   = xx;
R.xx2  = xx2;
R.res  = [(1:nx).' xx.'];
R.P    = P;

end
