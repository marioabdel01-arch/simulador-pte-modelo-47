function P = pte47_params(caseName, varargin)
%PTE47_PARAMS  Build the constant/parameter struct for the 47-state model.
%
%   P = PTE47_PARAMS(NAME)                    NAME = '100' | '775' | '50'
%   P = PTE47_PARAMS(NAME, 'field', value, ...)
%
%   Runs the case data plus const1/const2/const3 ONCE and packs every
%   resulting variable into the struct P, which digpte47 then reads as
%   P.<name>.  In the original code these scripts were re-executed on every
%   derivative evaluation (4 per RK4 step x 7001 steps = 28004 times); that
%   was the single largest cost of the simulation.
%
%   Evaluation ORDER IS PRESERVED exactly as in the original files:
%       diginit header constants -> const1 -> const2 -> const3
%   This matters: diginit set kntr = 377.0 and const2 then overwrote it with
%   376.991, and diginit set kmrl = 0.111 which const3 overwrote with 0.5.
%   The values that reach the model are therefore unchanged.
%
%   Optional name/value pairs override any field of P after loading, e.g.
%       P = pte47_params('775', 'ldcStart', 3.875, 'samples', 7001);
%
%   See also PTE47_CASE, DIGPTE47, PTE47_RUN.

if nargin < 1 || isempty(caseName), caseName = '100'; end

% ---- case data (x0, ldc, Ts, samples) ----------------------------------
pte47case_ = pte47_case(caseName);
x0      = pte47case_.x0;
ldc     = pte47case_.ldc;
Ts      = pte47case_.Ts;
samples = pte47case_.samples;
clear pte47case_

% ---- numeric literals formerly at the top of diginit*.m ----------------
knp33 = 0.333333; knp5 = 0.5;  knp6 = 0.6;  knp79 = 0.788654;
knp8  = 0.8;      kn1p3 = 1.234;
kn0   = 0.0;  kn1 = 1.0;  km1 = -1.0;
kn2   = 2.0;  kn3 = 3.0;  kn4 = 4.0;  km4 = -4.0;
kn5   = 5.0;  km5 = -5.0; kn6 = 6.0;  kn144 = 144.0;
kmwx  = 1.355e-6; kmwr = 4.428e8;
kntr  = 377.0;    kc1gn = 1.0;              % kntr is overwritten by const2
catvd = 5.0; caivd = 5.0;                   % kept for reference; unused
kmrl  = 0.111;                              % overwritten by const3

% ---- plant / control constants (user's own files, untouched) -----------
const1
const2
const3

% ---- load-demand ramp ldc(t), see digpte47 -----------------------------
% Defaults reproduce EXACTLY the ramp hard-coded in the original
% digpte47_100/_775/_50:   ldc = 5 - 0.0125*(min(t,100)-10)
ldcT0    = 10;                              % ramp start time (s)
ldcT1    = 100;                             % ramp end time  (s)
ldcStart = 5.0;                             % ldc at t = ldcT0
ldcRate  = -0.0125;                         % dldc/dt during the ramp

% ---- integrator options -------------------------------------------------
stopOnNaN = true;   % abort the run (with a warning) on the first non-finite
                    % state instead of burning through the remaining steps;
                    % set false to reproduce the original "run to the end"
                    % behaviour exactly.

clampStates = false;  % anti-windup: recortar los estados de control 23..46
                      % despues de cada paso RK4 con los mismos limchk /
                      % check que usa el modelo (ver pte47_clamp).  En el
                      % Fortran original las variables de control estaban en
                      % COMMON y limchk recortaba el estado mismo; en este
                      % port solo recorta la copia local, asi que los
                      % integradores se cargan.  Apagado por omision para
                      % reproducir el codigo original tal cual.

% ---- pack the whole workspace into P -----------------------------------
% Antes esto se hacia con save/load de un .mat temporal.  Se cambio a WHO +
% EVAL porque un .mat no admite function handles y varargin puede traer uno
% (P.uFcn de la identificacion en lazo abierto).  Ademas evita el disco.
vars_ = who;
skip_ = {'caseName','varargin','vars_','skip_','k_','ii_','P','ans'};
P = struct();
for k_ = 1:numel(vars_)
    if ~any(strcmp(vars_{k_}, skip_))
        P.(vars_{k_}) = eval(vars_{k_});
    end
end

% ---- identificacion en lazo abierto (Amin et al., 1984) ----------------
% Se ponen DESPUES del empaquetado porque un function handle no se puede
% guardar en un .mat.
%   openLoop = [cbmd cxgg cwsy] logico.  Cada true abre ese lazo: la variable
%   de control se toma de uFcn(t) y su integrador se congela (ver digpte47).
%   Por omision todo cerrado, asi que el modelo queda identico al verificado.
P.openLoop = [false false false];
P.uFcn     = @(t) [0;0;0];

% soloTilt: deja cerrada la valvula de atemperacion del recalentador, que en
% el modelo de Usoro comparte la senal CXGG con la inclinacion de quemadores
% (rango partido: abre al bajar CXGG de 2 a 1 V).  Es la hipotesis de planta
% de Amin et al. (1984).  Apagado por omision: el modelo queda identico al
% verificado contra Usoro.  Ver AMIN_PLANTA y DIGPTE47.
P.soloTilt = false;

% logStride: numero de pasos RK4 entre filas del log.  [] = comportamiento
% original (una fila por segundo, con la marca de tiempo desfasada -Ts).
% Con Ts = 0.1 s, logStride = 200 da una fila cada 20 s (el Ts del articulo).
P.logStride = [];

% ldcFcn: impone ldc(t) desde fuera (ver digpte47).  Vacio = rampa del caso.
P.ldcFcn = [];

% rateLim: velocidad maxima de los servos (V/s) para los estados 35..43.
% Escalar o vector de 9.  Vacio = sin limite (ver digpte47).
P.rateLim = [];

% noiseFcn: ruido de medicion.  Funcion determinista y constante a tramos
% que devuelve [dtsso; dtrho; dpsso] en unidades fisicas (ver PTE47_NOISE y
% digpte47).  Vacio = medida perfecta (comportamiento original verificado).
P.noiseFcn = [];

% ---- pruebas de emergencia V.5 a V.7 de Usoro ---------------------------
% Las cuatro pruebas 1-4 son rampas de demanda de carga.  Las tres de
% emergencia entran por OTRO camino: el sistema electrico auxiliar y el lado
% del aire, no por ldc.  Eso las hace un banco de validacion independiente
% del que se uso para disenar el controlador.
%
%   velecFcn  tension de la barra auxiliar (V) en funcion de t.  Vacio =
%             P.velec constante (4160 V).   Prueba 5: escalon a 2912 V.
%   nelecFcn  velocidad sincrona (rad/s) en funcion de t.  Vacio = P.nelec
%             constante (376,991 = 2*pi*60).  Prueba 6: rampa a 0,8 Hz/s
%             durante 5 s, de 60 a 56 Hz.
%   knfdFcn   numero de ventiladores de tiro forzado en operacion.
%   knidFcn   idem de tiro inducido.  Prueba 7: de 2 a 1.
%   grFreeze  congela el control de recirculacion de gases (estado 38).
%             Usoro lo desactiva EXPRESAMENTE en las pruebas 6 y 7; dice que
%             con el puesto el sistema tarda mucho mas en asentarse, y que en
%             la planta real ese lazo se pone a veces en manual.
% kfcal: calibracion de los coeficientes de curva de los ventiladores en
% ARFLOW.  El port la fijo en 1,10 porque el listado impreso entrega como
% mucho ~1219 lb/s de aire y las figuras de Usoro muestran 1230,3.  Vacio =
% 1,10, o sea el valor con el que se verificaron las pruebas 1 a 4.
P.kfcal = [];

P.velecFcn = [];
P.nelecFcn = [];
P.knfdFcn  = [];
P.knidFcn  = [];
P.grFreeze = false;

% actNL: no linealidades del actuador (ver digpte47).  Struct con
%   .dead  zona muerta en volts, escalar o vector del tamano de .idx
%   .idx   estados afectados            [36 42 43] = cfld, cxggd, csyd
%   .tau   constantes de tiempo de esos estados
% Vacio = actuador ideal (comportamiento original verificado).
P.actNL = [];

% ---- optional overrides -------------------------------------------------
if mod(numel(varargin), 2) ~= 0
    error('pte47_params:badPairs', 'Overrides must be name/value pairs.');
end
for ii_ = 1:2:numel(varargin)
    P.(varargin{ii_}) = varargin{ii_+1};
end

P.caseName = char(caseName);

end
