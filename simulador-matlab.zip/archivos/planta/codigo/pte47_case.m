function C = pte47_case(caseName)
%PTE47_CASE  Case data (initial state, load reference, run length).
%
%   C = PTE47_CASE(NAME), NAME = '100' | '775' | '50', returns a struct with
%   fields x0 (47x1), ldc, Ts and samples.
%
%   Replaces diginit100.m / diginit775.m / diginit50.m: those three files were
%   identical except for these four items, so they are one switch now.  The
%   long commented-out alternative x0 vectors were left behind in the original
%   files (nothing was deleted there).
%
%   Usoro, "A drum boiler-turbine power plant under emergency state control",
%   MIT 1977.  Order = 47.

switch char(caseName)

    case '100'                      % 100% load, ldc = 5.0 (thesis p.288)
        C.ldc     = 5.0;
        C.samples = 7001;
        C.x0 = [
    542.15
    478.11
    634.72
    1170.5
    9.4534
    187.19
    1159.8
    5.0129
    1247.9
    3.1381
    1460.1
    2.5600
    0.65599
    1519.0
    0.25448
    376.99
    186.56
    198.99
    6817.4
    0.13307
    61.880
    92.452
    4.5628
    4.5500
    4.5622
    4.9586
    2.4688
    4.0743
    4.9667e-3
    4.6042
    5.8393e-3
    4.5196
    3.1173
    4.4259
    4.5486
    4.5617
    4.9573
    2.4688
    4.0737
    4.6034
    4.5238
    3.1167
    4.4245
    0.0
    5.0
    5.00
    0.52362];

    case '775'                      % 77.5% load, ldc = 3.875 (18ago'26)
        C.ldc     = 3.875;
        C.samples = 3501;
        C.x0 = [
    4.8695e+02
    4.5517e+02
    6.5775e+02
    1.1703e+03
    8.2347e+00
    1.8711e+02
    1.1483e+03
    4.2876e+00
    1.3071e+03
    3.1373e+00
    1.4603e+03
    1.8682e+00
    4.8931e-01
    1.5230e+03
    1.8898e-01
    3.7699e+02
    1.8670e+02
    1.8689e+02
    6.8171e+03
    1.0647e-01
    6.2414e+01
    9.3472e+01
    3.8216e+00
    3.4736e+00
    3.8198e+00
    3.8840e+00
    3.8202e+00
    3.5928e+00
    -1.1426e-02
    3.3915e+00
    -1.6286e-02
    3.3655e+00
    3.0060e+00
    1.6891e+00
    3.4750e+00
    3.8214e+00
    3.8847e+00
    3.8202e+00
    3.5921e+00
    3.3822e+00
    3.3492e+00
    3.0319e+00
    1.6683e+00
    -2.1566e-01
    3.6592e+00
    3.6583e+00
    4.0485e-01];

    case '50'                       % 50% load, ldc = 2.5
        C.ldc     = 2.5;
        C.samples = 7001;
        C.x0 = [
    4.5103e+02
    4.3506e+02
    6.5161e+02
    1.1688e+03
    7.5987e+00
    1.8707e+02
    1.1400e+03
    3.9552e+00
    1.3387e+03
    3.2166e+00
    1.4454e+03
    1.2283e+00
    3.2053e-01
    1.5038e+03
    1.2074e-01
    3.7696e+02
    1.8680e+02
    1.5744e+02
    6.8172e+03
    7.4243e-02
    6.2662e+01
    9.3963e+01
    2.8814e+00
    2.3627e+00
    2.8834e+00
    2.6438e+00
    4.0229e+00
    3.1484e+00
    -4.3841e-03
    2.4612e+00
    2.3102e-02
    2.7268e+00
    2.6716e+00
    1.8195e+00
    2.3457e+00
    2.8687e+00
    2.6298e+00
    4.0577e+00
    3.1532e+00
    2.4715e+00
    2.7170e+00
    2.5238e+00
    1.9248e+00
    -1.4371e-01
    2.3569e+00
    2.3577e+00
    2.5453e-01];

    otherwise
        error('pte47_case:unknownCase', ...
            'Unknown case "%s".  Use ''100'', ''775'' or ''50''.', char(caseName));
end

C.Ts = 0.1;                         % sampling / integration step (s)

end
