function figs = pte47_plot(R)
%PTE47_PLOT  The six 2x2 result figures of the 47-state Usoro model.
%
%   PTE47_PLOT(R)        R from PTE47_RUN
%   figs = PTE47_PLOT(R) also returns the figure handles
%
%   Replaces the ~50 copy-pasted plot lines that appeared four times over
%   (pba1..pba4).  Column 1 of R.xx2 is time; columns 2..25 are the logged
%   signals, in the order digpte47 packs them into ylog.
%
%   See also PTE47_RUN.

% column of xx2, title
sig = { ...
     2, 'TURBINE SPEED (rad/s) - ntr'
     3, 'POWER OUTPUT (MW) - mwo'
     4, 'THROTTLE PRESSURE (psia) - psso'
     5, 'MAIN STEAM FLOW (lb/s) - whp'
     6, 'BOILER MASTER DEMAND (V) - c3md'
     7, 'GOVERNOR VALVE CONTROL (V) - cacvd'
     8, 'FUEL FLOW CONTROL (V) - cfld'
     9, 'AIR FLOW CONTROL (V) - card'
    10, 'DRUM WATER VOLUME (ft^3) - vdrw'
    11, 'DEAERATOR WATER VOLUME (ft^3) - vdew'
    12, 'FEEDWATER FLOW CONTROL (V) - cfwd'
    13, 'CONDENSATE FLOW CONTROL (V) - cdwd'
    14, 'SEC. SUPERHEATER ENTHALPY (Btu/lb) - hsso'
    15, 'REHEAT ENTHALPY (Btu/lb) - hrho'
    16, 'SUPERHEAT TEMPERATURE CONTROL (V) - csyd'
    17, 'REHEAT TEMPERATURE CONTROL (V) - cxggd'
    18, 'BOILER FEEDPUMP SPEED (rad/s) - nfp'
    19, 'GAS RECIR. CONTROL (V) - cgrd'
    20, 'FURNACE PRESSURE CONTROL (V) - cfnd'
    21, 'WATERWALL METAL TEMPERATURE (R) - twwm'
    22, 'FD FAN SPEED (rad/s) - nfd'
    23, 'ID FAN SPEED (rad/s) - nid'
    24, 'RECIRCULATING PUMP SPEED (rad/s) - nrp'
    25, 'CONDENSATE PUMP SPEED (rad/s) - ncp'
    };

tt   = R.xx2(:,1);
npf  = 4;                                   % panels per figure
nfig = ceil(size(sig,1)/npf);
if exist('gobjects', 'builtin') == 5 || exist('gobjects', 'file') == 2
    figs = gobjects(nfig,1);        % MATLAB
else
    figs = zeros(nfig,1);           % Octave
end

for f = 1:nfig
    figs(f) = figure('Name', sprintf('PTE47 %s - %d/%d', ...
                     R.P.caseName, f, nfig), 'NumberTitle', 'off');
    for k = 1:npf
        idx = (f-1)*npf + k;
        if idx > size(sig,1), break, end
        ax = subplot(2, 2, k);
        plot(ax, tt, R.xx2(:, sig{idx,1}));
        title(ax, sig{idx,2});
        xlabel(ax, 'time (s)');
        grid(ax, 'on');
    end
end

if nargout == 0, clear figs, end

end
