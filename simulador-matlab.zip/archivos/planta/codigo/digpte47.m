function [xdot, ylog] = digpte47(t, x, P)
%DIGPTE47  Derivative f(t,x) of the full 47-state plant + control model.
%
%   XDOT        = DIGPTE47(T, X, P)
%   [XDOT,YLOG] = DIGPTE47(T, X, P)
%
%   Usoro, "A drum boiler-turbine power plant under emergency state control",
%   MIT 1977.  Order = 47.  True f(t,x) evaluation, so a Runge-Kutta
%   integrator can advance ALL 47 states: nfp (1) and ntr (16) are no longer
%   frozen (thesis pp.152-153 and pp.159-160).
%
%   P is the constant struct built ONCE by pte47_params.  This replaces the
%   original digpte47_100 / digpte47_775 / digpte47_50, which were three
%   byte-identical copies apart from the diginit script they called, and
%   which re-ran diginit + const1 + const2 + const3 on EVERY evaluation.
%
%   YLOG (38 columns) is only assembled when a second output is requested.
%   1..25 log original, 26..31 y/u de la identificacion, 32..34 consignas,
%   35 ldc, 36..38 salidas MEDIDAS (con ruido de medicion).
%
%   See also PTE47_PARAMS, PTE47_RUN, PTE47_PLOT.

xdot=zeros(47,1);
% equivalence
% x=[nfp, hhho, heco, vdrw, rdrs,...  %1-5
%    nrp, twwm, rpso, hpso, rsso,...  %6-10
%    hsso, rsco, rrho, hrho, rcro,... %11-15
%    ntr, ncp, hlho, vdew, rdes,...   %16-20
%    nfd, nid, c3md, c5ar, c5fl,...   %21-25
%    c3fn, c2gr, c2ft, c3fv, c7fv,... %26-30
%    c3dv, c8dv, c5rh, c5sy, card,... %31-35
%    cfld, cfnd, cgrd, cftd, cfwd,... %36-40
%    cdwd, cxggd, csyd, c2tr, c4tr, cacvd, delta]; %47
nfp=x(1); hhho=x(2); heco=x(3); vdrw=x(4);
rdrs=x(5); nrp=x(6); twwm=x(7); rpso=x(8);
hpso=x(9); rsso=x(10); hsso=x(11); rsco=x(12);
rrho=x(13); hrho=x(14); rcro=x(15); ntr=x(16);
ncp=x(17); hlho=x(18); vdew=x(19); rdes=x(20);
nfd=x(21); nid=x(22); c3md=x(23); % 23 ss
c5ar=x(24); c5fl=x(25); c3fn=x(26); c2gr=x(27);
c2ft=x(28); c3fv=x(29); c7fv=x(30); c3dv=x(31);
c8dv=x(32); c5rh=x(33); c5sy=x(34); card=x(35);
cfld=x(36); cfnd=x(37); cgrd=x(38); cftd=x(39);
cfwd=x(40); cdwd=x(41); cxggd=x(42); csyd=x(43);
c2tr=x(44); c4tr=x(45); cacvd=x(46); delta=x(47);
% ---- load demand ldc(t) -------------------------------------------------
% Default (P.ldc*) reproduces EXACTLY the ramp hard-coded in the original
% digpte47_100/_775/_50: ldc = 5 - 0.0125*(min(t,100)-10)  [100%->77.5%].
% Override any of P.ldcT0 / P.ldcT1 / P.ldcStart / P.ldcRate in pte47_run
% to run a different test without touching this file.
% NOTE: the three original copies all used ldcStart = 5 even for the 50% and
% 77.5% cases, which makes ldc jump from 2.5 (or 3.875) to 5 at t = 10 s.
% If that was not intended, set 'ldcStart' to the case's own ldc.
ldc = P.ldc;
if t >= P.ldcT0
    ldc = P.ldcStart + P.ldcRate*(min(t,P.ldcT1) - P.ldcT0);
end
% P.ldcFcn permite imponer ldc(t) desde fuera (identificacion con la demanda
% de carga como entrada exogena medible).  Vacio = rampa de la prueba.
if ~isempty(P.ldcFcn)
    ldc = P.ldcFcn(t);
end
% if(t>=10) knfd=1; knid=1; end % pba7
% if(t>=10 && t<=15)           % t<=100 /120
    % freq=60-0.8*(t-10);    % ldc=3.875+0.0125*(t-10);
%     nelec=376.991-2*pi*.8*(t-10); % pba6
% end
% if(t>15) nelec=376.991*(54/60); end
% if(t>=700)
%     ldc=3.875+0.0125*(min(t,800)-710);
%     %ldc=3.875+0.0125*(min(t,100)-10); 
% end
% ---- entradas externas (identificacion en lazo abierto) -----------------
% P.openLoop = [cbmd cxgg cwsy] logico.  Cuando un elemento es true, esa
% variable de control se toma de P.uFcn(t) en vez del lazo PI de Usoro, y
% el integrador de ese lazo se congela mas abajo.  Por omision es
% [false false false] y el modelo se comporta EXACTAMENTE como antes.
%   y = [tsso; trho; psso]   u = [cbmd; cxgg; cwsy]   (Amin et al., 1984)
uExt = [0;0;0];
if any(P.openLoop)
    uExt = P.uFcn(t);
end
%----------------falta---------------
fc2dv=0;%(c2dv-c2dv0)/tstep;
fcp1st=0;%(cp1st-cp1st0)/tstep;
fctrho=0;%(ctrho-ctrho0)/tstep;
fcxgg=0;%(cxgg-cxgg0)/tstep;
% set controlled input values
card=limchk(card);
avf=xducer(P.kcl,P.kcu,P.kavl,P.kavu,card);
cfld=limchk(cfld);
wfl=xducer(P.kcl,P.kcu,P.kwfll,P.kwflu,cfld);
cfnd=limchk(cfnd);
avi=xducer(P.kcl,P.kcu,P.kavl,P.kavu,cfnd);
cgrd=limchk(cgrd);
kwgr=P.kc2gr*wfl;
kcwgr=xducer(P.kwgrl,P.kwgru,P.kcl,P.kcu,kwgr);
cfld=limchk(cfld);
cgrd=check(cgrd,kcwgr,P.kcl);
wgr=xducer(P.kcl,P.kcu,P.kwgrl,P.kwgru,cgrd);
cftd=limchk(cftd);
wft=xducer(P.kcl,P.kcu,P.kwftl,P.kwftu,cftd);
cfwd=limchk(cfwd);
afv=xducer(P.kcl,P.kcu,P.kavl,P.kavu,cfwd); %afv=0.9;
cdwd=limchk(cdwd);
adv=xducer(P.kcl,P.kcu,P.kavl,P.kavu,cdwd);
cxggd=limchk(cxggd);
cry=P.kc1ry*cxggd; %d
wry=xducer(P.kcryl,P.kcryu,P.kwryl,P.kwryu,cry);
% ---- solo la inclinacion de quemadores (Amin et al., 1984) --------------
% CXGG manda dos actuadores en rango partido: la inclinacion (xgg) y la
% valvula de atemperacion del recalentador (wry), que abre de 0 a 50 lb/s
% cuando cxggd baja de 2 a 1 V.  Amin lo dice explicitamente:
%   «In this study only the burner tilt control is assumed to be active
%    since in most applications it is sufficient to control reheat
%    temperature.»
% Con P.soloTilt = true la valvula se queda cerrada.  APAGADO POR OMISION:
% sin la bandera el modelo es exactamente el de Usoro.
if isfield(P,'soloTilt') && P.soloTilt
    wry=0;
end
xgg=xducer(P.kcl,P.kcu,P.kxggl,P.kxggu,cxggd);
%[dead] zxgg=xgg*57.3;
csyd=limchk(csyd);
csy=csyd*P.kc4sy;
wsy=xducer(P.kcsyl,P.kcsyu,P.kwsyl,P.kwsyu,csy);
agv=xducer(P.kn0,P.kn5,P.kavl,P.kavu,cacvd);
%[dead] atv=1.0;
aiv=1.0;
% state properties
[rdrw,hdrw,hdrs,pdrs,tdrs]=drstat(rdrs);
[rdew,hdew,hdes,pdes,tdes]=destat(rdes);
[ppso,tpso,spso]=shstat(rpso,hpso);
[psso,tsso,ssso]=shstat(rsso,hsso);
[psco,tsco,ssco]=shstat(rsco,hsso);
[prho,trho,srho]=rhstat(rrho,hrho);
[reco,teco]=fwstat(heco,pdrs);
[rdvo,tdvo]=cwstat(hlho,pdes);
% steam flow
ppsd=pdrs-ppso;
[wdrs]=shflow(rdrs,ppsd,P.kfps);
acv=agv;
wtv=P.kcv*acv*sqrt(psso*rsso);
wpsx=P.kn0;
if(wtv<P.kwtv) % 100% wtv=1.1093e+03, kwtv=5.0670e+02
  wpsx=(101.56064-0.39882*wdrs+4.8626e-4*wdrs*wdrs); %.5
end
pssd=ppso-psso;
[wss1]=shflow(rsso,pssd,P.kfss);
wpso=wss1+wpsx-wsy;
whp=P.khp*sqrt(rsco*psco); %whp=1109.2; %para pba
wssx=P.kn0;
if(wtv<P.kwtv); wssx=wft; end
wsso=wtv+wssx; %
[whpaux,w1hhs]=hpext(whp);
whpo=whp-whpaux-w1hhs;
wrh1=whpo+wry;
wiv=P.kip*aiv*sqrt(rrho*prho);
wip=wiv;
% turbine
ehp=0.589+2.317e-4*whp;
phpo=prho+P.kfrh*wip*wip/rrho;
[hhpo,thpo]=hpstat(ssso,phpo,ehp,hsso);
eip=0.814;
[hcro,pcro,tcro]=crstat(srho,rcro,eip,hrho);
wlp=P.klp*sqrt(rcro*pcro);
pcn=P.k0pcn+P.k1pcn*pcro+P.k2pcn*pcro*pcro;
qylpo=P.kqylpo;
[hlpo,rlpo,slpo,tcn,rcno,hcno]=cnstat(pcn,qylpo);
mwhp=whp*(hsso-hhpo)*P.kj;
keip=0.93;
kelp=0.93;
mwip=wip*(hrho-hcro)*P.kj*keip;
mwlp=wlp*(hcro-hlpo)*P.kj*kelp;
mwtro=mwhp+mwip+mwlp;
mwo=mwtro*P.kmwx;
mwgnpu=P.kn2*sin(delta);
mwgn=mwgnpu*P.kmwr;
%[dead] mwtrpu=mwtro/P.kmwr;
[w2hhs,w3hhs,h2hhs1,p2hhs,p3hhso]=...
    ipext(wip,prho,pcro,hrho,hcro);
wipftx=wft;
if(wssx>P.kn0); wipftx=P.kn0; end
wipo=wip-w2hhs-w3hhs-wipftx;
% water side
[wcw,wcp,pcpo,plho,wlhx,wdvo,ecp]=cwflow...
(pcn,rcno,rdvo,pdes,ncp,adv,P.kncp); %
[hcpo,tcpo]=cpstat(rcno,pcpo);
[rlho,tlho]=cwstat(hlho,plho);
[wfp,wfw,wfw2,pbpo,pfpo,pfvo,phho,pfvd,efp]=fwflow...
(wry,wsy,rdew,pdes,pdrs,reco,afv,nfp);
[hfpo,tfpo]=fpstat(rdew,pfpo);
hfvo=hfpo;
[rhho,thho]=fwstat(hhho,phho);
rdc=rdrw;
[wrw,wrp,wwwo,pdco,prpo,erp]=rwflow...
    (P.knrp,rdc,rdrw,nrp,pdrs);
% heat balance in downcomers, superheat and rehet sprays
hdc1=(wfw*heco+hdrw*(wrw-wfw))/wrw;
hss1=((wpso-wpsx)*hpso+wsy*hfpo)/wss1;
hrh1=(whpo*hhpo+wry*hfpo)/wrh1;
[rdc1,tdc1]=fwstat(hdc1,pdrs);
%[dead] [hdco,tdco,sdco]=rwstat(rdc1,pdco);
[hrpo,trco,srpo]=rwstat(rdc1,prpo);
[rss1,tss1,sss1]=systat(hss1,ppso);
[rrh1,trh1rh1,s]=rystat(hrh1,phpo);
% feedwater heater steam
[w1lhs,w2lhs,wdex,wlhst,p1lhs,p2lhs,p3lhs,h1lhs1,h2lhs1,...
    hdex]=lpext(wlp,pcro,pcn,hcro,hlpo);
%[dead] [h1lhso,r1lhso,t1lhso]=lsstat(p1lhs);
[h2lhso,r2lhso,t2lhso]=lwstat(p2lhs);
[h3lhso,r3lhso,t3lhso]=lwstat(p3lhs);
qlh=w1lhs*(h1lhs1-h3lhso)+w2lhs*(h2lhs1-h2lhso);
whhst=w1hhs+w2hhs+w3hhs;
[h3hhso,r3hhso,t3hhso]=lsstat(p3hhso);
qhh=w1hhs*hhpo+w2hhs*h2hhs1+w3hhs*hcro-whhst*h3hhso; %
whhs=whhst;
if(wfw<P.kwfw); whhs=P.kn0; end
% mean flow, temperature, density, and enthalpy
[wpse,rpse,hpse]=averag(wdrs,wpso,rdrs,rpso,hdrs,hpso);
[wsse,rsse,hsse]=averag(wss1,wsso,rss1,rsso,hss1,hsso);
[wrhe,rrhe,hrhe]=averag(wrh1,wip,rrh1,rrho,hrh1,hrho);
[pece,hece,plhe]=averag(phho,pdrs,hhho,heco,pcpo,plho);
[phhe,hhhe,hlhe]=averag(pfvo,phho,hfvo,hhho,hcpo,hlho);
[ppse,tpse,spse]=shstat(rpse,hpse);
[psse,tsse,ssse]=shstat(rsse,hsse);
[prhe,trhe,srhe]=rhstat(rrhe,hrhe);
[rece,tece]=fwstat(hece,pece);
[rhhe,thhe]=fwstat(hhhe,phhe);
[rlhe,tlhe]=cwstat(hlhe,plhe);
% ---- pruebas de emergencia: tension, frecuencia y ventiladores ---------
% Se resuelven aqui, una sola vez por evaluacion, y se usan mas abajo en
% arflow y en torque.  Con los cuatro campos vacios el modelo es identico al
% verificado contra las figuras V.1 a V.4.
velec_ = P.velec;   nelec_ = P.nelec;
knfd_  = P.knfd;    knid_  = P.knid;
if ~isempty(P.velecFcn), velec_ = P.velecFcn(t); end
if ~isempty(P.nelecFcn), nelec_ = P.nelecFcn(t); end
if ~isempty(P.knfdFcn),  knfd_  = P.knfdFcn(t);  end
if ~isempty(P.knidFcn),  knid_  = P.knidFcn(t);  end

% air and gas flow
[war,wwwg,wfd,wgo,wid,pahao,pfdo,pfn,pecgo,papgo,pido,...
    efd,eid]=arflow(knfd_,knid_,nfd,nid,wgr,wfl,avf,avi,P.kfcal);
% air side heat transfer
tahao=P.ktat+P.ktahad;
tapao=tahao+P.ktapad;
%[dead] ward=P.kafr*wfl;
% furnace
% burner tilt correction factor
uxgg=P.k1xgg+P.k2xgg*sin(xgg)/cos(xgg);
% number of operating guns
ngg=P.ng1+P.ng2+P.ng3+P.ng4+P.ng5;
ungg=(P.ng1*P.k1ng+P.ng2*P.k2ng+P.ng3*P.k3ng+P.ng4*P.k4ng+P.ng5*P.k5ng)/...
    (ngg*P.kxwwe);
uwwgm=P.kuwwgm*uxgg*ungg;
tgr=P.k1tgr+P.k2tgr*wfl;
[tfn1,twwge,twwgo,qwwgm,qpsr,swwgo]=fnxfer(twwm,wwwg,war,...
P.sar,tapao,wfl,P.s_fl,P.tfl,P.khfl,P.efl,wgr,P.sgr,tgr,uwwgm,P.ywgr,...
tpse,P.kupsr);
qwwmw=P.kuwwmw*(twwm-tdrs)^3;
% gas side heat transfer
qssr=P.kn0;
qrhr=P.kn0;
qecr=P.kn0;
[tpsgo,qps,tpsme,spsgo]=hxfer...
    (wwwg,wpse,P.kupsgm,P.kupsms,tpse,twwgo,qpsr,P.ywgr);
[tssgo,qss,tssme,sssgo]=hxfer...
    (wwwg,wsse,P.kussgm,P.kussms,tsse,tpsgo,qssr,P.ywgr);
[trhgo,qrh,trhme,srhgo]=hxfer...
    (wwwg,wrhe,P.kurhgm,P.kurhms,trhe,tssgo,qrhr,P.ywgr);
[tecgo,qec,tecme,secgo]=hxfer...
    (wwwg,wfw,P.kuecgm,P.kuecmw,tece,trhgo,qecr,P.ywgr);
tlhme=P.klhm*tlho;
thhme=P.khhm*thho;
% effective masses
mwwme=P.kmwwm+P.kvww*rdrw*hdrw/(P.kswwm*twwm);
mpss=rpse*P.kvps;
mpse=mpss+P.kmpsm*P.kspsm*tpsme/hpse;
msss=rsse*P.kvss;
msse=msss+P.kmssm*P.ksssm*tssme/hsse;
mrhs=rrhe*P.kvrh;
mrhe=mrhs+P.kmrhm*P.ksrhm*trhme/hrhe;
mecw=rece*P.kvec;
mece=mecw+P.kmecm*P.ksecm*tecme/hece;
mlhw=rlhe*P.kvlh;
mlhe=mlhw+P.kmlhm*P.kslhm*tlhme/hlhe;
mhhw=rhhe*P.kvhh;
mhhe=mhhw+P.kmhhm*P.kshhm*thhme/hhhe;
% air and gas densities
rahao=0.0661;
rapgo=0.044;
% drum intermediate variables
% deaerator intermediate variables
%[dead] hdrd=hdrs-hdrw;
hwwo=hrpo+qwwmw/wwwo;
%[dead] qyww=(qwwmw+wrw*(hrpo-hdrw))/(wrw*hdrd);
[wderp,wdewh,wdebd,hderp,hdewh]=destmr(wdrs,whp);
hdebd=hdes;
wdrbd=P.kn2*wdebd;
wdesr=wderp+wdewh+wdebd;
qdesr=wderp*hderp+wdewh*hdewh+wdebd*hdebd;
z206=wfw-wrw+wwwo-wdrs-wdrbd;
z209=wwwo*hwwo-(wrw-wfw)*hdrw-wdrs*hdrs-wdrbd*hdrs;
z226=wdvo+whhs+wdex+wdesr-wfp;
z229=wdvo*hlho+whhs*h3hhso+wdex*hdex+qdesr-wfp*hdew;
[f1dr,f2dr]=drum(P.kvdr,vdrw,rdrs,rdrw,hdrw,hdrs,...
    P.k2,P.k3,P.k5,P.k6,P.k7,P.k9,P.k10,z206,z209);
[f1de,f2de]=drum(P.kvde,vdew,rdes,rdew,hdew,hdes,...
    P.k22,P.k23,P.k25,P.k26,P.k27,P.k29,P.k30,z226,z229);
%[dead] wlpo=wlp-wlhst-wdex;
% pump and fan input torque
[tqrp1,mwrp1]=torque(nelec_,velec_,P.knrpm,nrp,P.krpm,P.srpmax);
[tqcp1,mwcp1]=torque(nelec_,velec_,P.kncpm,ncp,P.kcpm,P.scpmax);
[tqfd1,mwfd1]=torque(nelec_,velec_,P.knfdm,nfd,P.kfdm,P.sfdmax);
[tqid1,mwid1]=torque(nelec_,velec_,P.knidm,nid,P.kidm,P.sidmax);
hft1=hcro;
if(wssx>P.kn0); hft1=hsso; end
[tqfp1,mwfp1]=fpturb(wft,hft1,nfp);
xdew=P.k1xdew+P.k2xdew*vdew+P.k3xdew*vdew*vdew;
xdrw=P.k1xdrw+P.k2xdrw*vdrw+P.k3xdrw*vdrw*vdrw; %xdrw=2.5346e-03;
%[dead] phhd=pfpo-phho;
p1st=P.k1p1st*whp;
% control system
% boiler master demand (#364) dif=130
kpsso=P.k1pss+P.k2pss*ldc; %unused
kpsso=check(kpsso,P.k4pss,P.k3pss); %
kpsso=P.k4pss;
% ---- ruido de medicion -------------------------------------------------
% P.noiseFcn(t) devuelve un vector 3x1 [dtsso; dtrho; dpsso] en unidades
% fisicas que se suma a las tres salidas ANTES de que las lean los
% transductores del control.  Es ruido de MEDICION: no toca la fisica, solo
% lo que los controladores creen medir.
%
% Tiene que ser una funcion DETERMINISTA de t y constante a tramos: los
% cuatro subpasos de RK4 evaluan la derivada en instantes intermedios, y
% sortear un numero aleatorio nuevo en cada uno convertiria el ruido de
% medicion en ruido de proceso y rompería el integrador.  PTE47_NOISE
% construye una funcion asi con retencion de orden cero.
%
% Lo ve por igual el control PI original ---que lee tsso, trho y psso aqui
% dentro--- y el regulador auto-sintonizable, que los lee del log.  La
% comparacion sigue siendo justa.
if isempty(P.noiseFcn)
    vmeas = [0;0;0];
else
    vmeas = P.noiseFcn(t);
end
tsso_m = tsso + vmeas(1);
trho_m = trho + vmeas(2);
psso_m = psso + vmeas(3);
kcpsso=xducer(P.kpssol,P.kpssou,P.kcl,P.kcu,kpsso);
cpsso=xducer(P.kpssol,P.kpssou,P.kcl,P.kcu,psso_m);
c1md=kcpsso-cpsso;
c2md=c1md*P.kc1md;
c3md=limchk(c3md); %23
c4md=c2md+c3md;
c4md=limchk(c4md);
cntr=xducer(P.kntrl,P.kntru,P.kcl,P.kcu,ntr);
kcntr=xducer(P.kntrl,P.kntru,P.kcl,P.kcu,P.kntr);
c5md=P.kc2md*(kcntr-cntr);
cbmd=c4md+c5md;
if P.openLoop(1); cbmd=uExt(1); end     % <-- u1 externa
cbmd=limchk(cbmd);
% air flow control
cwar=xducer(P.kwarl,P.kwaru,P.kcl,P.kcu,war);
cwfl=cfld; %=36
c2ar=cbmd;
if(cwfl>cbmd); c2ar=cwfl; end
if(c2ar<P.kc2arl); c2ar=P.kc2arl; end
c3ar=c2ar-cwar;
c4ar=c3ar*P.kc1ar; %
c5ar=limchk(c5ar); %24
c6ar=c4ar+c5ar;
c6ar=limchk(c6ar); % --> 35 retardo
% fuel flow control
c2fl=cbmd;
if(cwar<cbmd); c2fl=cwar; end
c3fl=c2fl-cwfl;
c4fl=c3fl*P.kc1fl;
c5fl=limchk(c5fl); %25
c6fl=c4fl+c5fl;
c6fl=limchk(c6fl); % --> 35 retardo
% furnace pressure control
cpfn=xducer(P.kpfnl,P.kpfnu,P.kcl,P.kcu,pfn);
kcpfn=xducer(P.kpfnl,P.kpfnu,P.kcl,P.kcu,P.kpfn);
c1fn=kcpfn-cpfn;
c2fn=c1fn*P.kc1fn;
c3fn=limchk(c3fn);
c4fn=c2fn+c3fn;
c4fn=limchk(c4fn);
c5fn=c4fn+P.kc2fn*cwar;
c5fn=limchk(c5fn); % --> 37 retardo
% gas recirculation control
kcgr=P.kn0;
if(abs(xgg)>P.knp087); kcgr=P.kn1; end
c1gr=cxggd-P.kcxgg;
c2gr=limchk(c2gr); %27
% boiler feedpump control
cpfvd=xducer(P.kpfvdl,P.kpfvdu,P.kcl,P.kcu,pfvd);
kcpfvd=xducer(P.kpfvdl,P.kpfvdu,P.kcl,P.kcu,P.kpfvd);
c1ft=P.kc1ft*(kcpfvd-cpfvd);
c2ft=limchk(c2ft); %28
c3ft=c1ft+c2ft;
c3ft=limchk(c3ft);
% feedwater control
zwfw=wfw+wsy;
cwfw=xducer(P.kwfwl,P.kwfwu,P.kcl,P.kcu,zwfw);
cp1st=xducer(P.kp1stl,P.kp1stu,P.kcl,P.kcu,p1st);
cxdrw=xducer(P.kxdrwl,P.kxdrwu,P.kcl,P.kcu,xdrw); %cxdrw=3;
kcxdrw=xducer(P.kxdrwl,P.kxdrwu,P.kcl,P.kcu,P.kxdrw);
cpdrs=xducer(P.kpdrsl,P.kpdrsu,P.kcl,P.kcu,pdrs);
c1fv=cxdrw+P.kc4fv*cpdrs; %kc4fv=0
c2fv=P.kc1fv*(kcxdrw-c1fv);
c3fv=check(c3fv,P.kn5,P.km5); %29
c4fv=c2fv+c3fv;
c4fv=check(c4fv,P.kn5,P.km5);
c5fv=P.kc2fv*(cp1st-cwfw); %kc2fv=1
c6fv=P.kc3fv*(c4fv+c5fv);
c7fv=limchk(c7fv); %30
c8fv=c6fv+c7fv;
c8fv=limchk(c8fv);
% deaerator level control
cprho=xducer(P.kprhol,P.kprhou,P.kcl,P.kcu,prho);
cwcw=xducer(P.kwcwl,P.kwcwu,P.kcl,P.kcu,wcw);
cxdew=xducer(P.kxdewl,P.kxdewu,P.kcl,P.kcu,xdew);
kcxdew=xducer(P.kxdewl,P.kxdewu,P.kcl,P.kcu,P.kxdew); %
c1dv=kcxdew-cxdew;
c2dv=c1dv*P.kc1dv;
c3dv=check(c3dv,P.kn5,P.km5); %31
c4dv=P.ktc2dv*fc2dv;
c5dv=c2dv+c3dv+c4dv;
c5dv=check(c5dv,P.kn5,P.km5);
c6dv=P.kc4dv*cprho-P.kc5dv*cwcw;
c7dv=P.kc2dv*(c5dv+P.kc6dv*c6dv);
c8dv=limchk(c8dv); %32
c9dv=c7dv+c8dv;
c9dv=limchk(c9dv);
% reheat temperature control
ctrho=xducer(P.ktrhol,P.ktrhou,P.kcl,P.kcu,trho_m);
ktrh=P.k1trh+P.k2trh*whp;
ktrh=check(ktrh,P.k4trh,P.k3trh);
kctrh=xducer(P.ktrhol,P.ktrhou,P.kcl,P.kcu,ktrh);
c1rh=kctrh;
c2rh=fcp1st*P.kc3rh;
c3rh=c1rh+c2rh-ctrho;
c4rh=c3rh*P.kc1rh;
c5rh=limchk(c5rh); %33
c6rh=c4rh+c5rh;
c6rh=limchk(c6rh);
c7rh=fctrho*P.kc2rh;
c8rh=c6rh+c7rh;
c8rh=limchk(c8rh);
cxgg=c8rh;
if P.openLoop(2); cxgg=limchk(uExt(2)); end   % <-- u2 externa
% superheat temperature control
ktss=P.k1tss+P.k2tss*whp;
ktss=check(ktss,P.k4tss,P.k3tss);
ctsso=xducer(P.ktssol,P.ktssou,P.kcl,P.kcu,tsso_m);
kctss=xducer(P.ktssol,P.ktssou,P.kcl,P.kcu,ktss);
c2sy=kctss;
c3sy=c2sy-ctsso;
c4sy=c3sy*P.kc1sy;
c5sy=limchk(c5sy);
c6sy=c4sy+c5sy;
c6sy=limchk(c6sy);
c7sy=fcp1st*P.kc2sy;
c8sy=fcxgg*P.kc3sy;
c9sy=c6sy+c7sy+c8sy;
c9sy=limchk(c9sy);
cwsy=c9sy;
if P.openLoop(3); cwsy=limchk(uExt(3)); end   % <-- u3 externa
% turbine control
cmwtro=xducer(P.kmwtrl,P.kmwtru,P.kn0,P.kn6,mwtro);
%[dead] cmwgn=xducer(P.kmwtrl,P.kmwtru,P.kn0,P.kn6,mwgn);
cntre=kcntr-cntr;
c1tr=P.kc1tr*(ldc-cmwtro);
c2tr=check(c2tr,P.kn1,P.km1); %44
c3tr=c1tr+c2tr+ldc;
c3tr=check(c3tr,P.kn5,P.kn0);
c4tr=check(c4tr,P.kn5,P.kn0); %45
c5tr=P.kc2tr*cntre;
c6tr=c5tr/P.kcvreg+c4tr;
c6tr=check(c6tr,P.kn5,P.kn0);
cacvd=check(cacvd,P.kn5,P.kn0); %46
% dynamic equations
% calculate F of Y
xdot(1)=(tqfp1-wfp*(pfpo-pdes)*P.kn144/(nfp*rdew*efp))/P.kjfpe; % un-frozen
xdot(2)=(wfw*(hfvo-hhho)+qhh)/mhhe;
xdot(3)=(wfw*(hhho-heco)+qec)/mece;
xdot(4)=f1dr; % vdrw
xdot(5)=f2dr; % rdrs
xdot(6)=(tqrp1-wrp*(prpo-pdco)*P.kn144/(nrp*rdc*erp))/P.kjrp;
xdot(7)=(qwwgm-qwwmw)/(mwwme*P.kswwm);
xdot(8)=(wdrs-wpso)/P.kvps; % rpso
xdot(9)=(wdrs*hdrs-wpso*hpso+qps)/mpse; % hpso--psso
xdot(10)=(wss1-wsso)/P.kvss;
xdot(11)=(wss1*hss1-wsso*hsso+qss)/msse;
xdot(12)=(wtv-whp)/P.kvsce;
xdot(13)=(wrh1-wiv)/P.kvrh;
xdot(14)=(wrh1*hrh1-wiv*hrho+qrh)/mrhe;
xdot(15)=(wipo-wlp)/P.kvcre;
xdot(16)=(mwtro-mwgn)/(ntr*P.kjtre/32.174); % un-frozen; ntr=376.99 claude
xdot(17)=(tqcp1-wcp*(pcpo-pcn)*P.kn144/(ncp*rcno*ecp))/P.kjcp;
xdot(18)=(wcw*(hcpo-hlho)+qlh+P.kqgc)/mlhe;
xdot(19)=f1de; % vdew
xdot(20)=f2de; % rdes
xdot(21)=(tqfd1-wfd*(pfdo-pahao)*P.kn144/(nfd*rahao*efd))/P.kjfd;
xdot(22)=(tqid1-wid*(pido-papgo)*P.kn144/(nid*rapgo*eid))/P.kjid;
xdot(23)=c2md/P.ktc1md;
if P.openLoop(1); xdot(23)=0; end       % c3md congelado (lazo de presion abierto)
xdot(24)=c4ar/P.ktc1ar;
xdot(25)=c4fl/P.ktc1fl;
xdot(26)=c2fn/P.ktc1fn;
xdot(27)=c1gr*P.kc1gr*kcgr;
xdot(28)=c1ft/P.ktc1ft;
xdot(29)=c2fv/P.ktc1fv;
xdot(30)=c6fv/P.ktc2fv;
xdot(31)=c2dv/P.ktc1dv;
xdot(32)=c7dv/P.ktc3dv;
xdot(33)=c4rh/P.ktc1rh;
if P.openLoop(2); xdot(33)=0; end       % c5rh congelado (lazo de T recalentador abierto)
xdot(34)=c4sy/P.ktc1sy;
if P.openLoop(3); xdot(34)=0; end       % c5sy congelado (lazo de T sobrecalentador abierto)
xdot(35)=(c6ar-card)/P.ktc2ar; %retardos 1er orden =5
xdot(36)=(c6fl-cfld)/P.ktc2fl; %ktc1gr=20
xdot(37)=(c5fn-cfnd)/P.ktc2fn; %estado cfnd
xdot(38)=(c2gr-cgrd)/P.ktc1gr;
if P.grFreeze; xdot(38)=0; end   % recirculacion de gases en manual (V.6, V.7)
xdot(39)=(c3ft-cftd)/P.ktc2ft;
xdot(40)=(c8fv-cfwd)/P.ktc3fv;
xdot(41)=(c9dv-cdwd)/P.ktc4dv;
xdot(42)=(cxgg-cxggd)/P.ktc2rh;
xdot(43)=(cwsy-csyd)/P.ktc2sy;
xdot(44)=c1tr/P.ktc1tr;
xdot(45)=(c3tr-c4tr)/P.ktc2tr; %retardos 1er orden =1
xdot(46)=(c6tr-cacvd)/P.ktc3tr;
% nelec ES LA FRECUENCIA DE LA RED, no solo la alimentacion de los motores
% auxiliares: aqui entra en la ecuacion de oscilacion del generador, donde
% delta integra la diferencia entre la velocidad de turbina y la sincrona.
% Ese es el camino por el que una caida de frecuencia llega al regulador de
% velocidad de la turbina (prueba V.6), y es el dominante: por los
% auxiliares sola, la prueba no se mueve.  P.kntr (377,0) es la CONSIGNA de
% velocidad y no se toca, que es justo lo que hace que el estatismo actue.
xdot(47)=P.kc1gn*(ntr-nelec_);
% ---- limite de velocidad de los servos (estados 35..43) -----------------
% El modelo de Usoro representa cada actuador como un retardo de primer
% orden xdot = (u-x)/tau con tau = 5 s, lo que permite recorridos de hasta
% 4/5 = 0,8 V/s.  Un servo real de inclinacion de quemadores es un conjunto
% mecanico grande y tiene una velocidad maxima muy inferior.  P.rateLim
% (V/s) impone esa cota; se aplica DENTRO del modelo, asi que afecta por
% igual al control original y al regulador auto-sintonizable, y la
% comparacion sigue siendo justa.  Vacio = sin limite (comportamiento
% original verificado).
if ~isempty(P.rateLim)
    rl = P.rateLim;
    if isscalar(rl), rl = rl*ones(9,1); end
    for kk_ = 1:9
        j_ = 34 + kk_;                      % estados 35..43
        if xdot(j_) >  rl(kk_), xdot(j_) =  rl(kk_); end
        if xdot(j_) < -rl(kk_), xdot(j_) = -rl(kk_); end
    end
end
% ---- no linealidades del actuador (zona muerta) -------------------------
% El retardo de primer orden de Usoro, xdot = (u-x)/tau, es un actuador
% IDEAL: responde a cualquier error, por pequeno que sea.  Un servo real no.
% El juego mecanico del varillaje, el umbral del servoamplificador y la
% friccion seca (Coulomb) del conjunto producen todos el mismo efecto
% observable: existe un error minimo por debajo del cual el actuador no se
% mueve, y por encima del cual se mueve como si ese umbral no existiera.
%
%     e = u - x        (error que mueve al actuador)
%     xdot = 0                         si |e| <= dead
%     xdot = (e - sign(e)*dead)/tau    si |e| >  dead
%
% Se aplica DESPUES del limite de velocidad, de modo que ambos efectos se
% pueden activar por separado o juntos.  P.actNL vacio = actuador ideal
% (comportamiento original verificado).
%
% No se modela histeresis con memoria de sentido: exigiria estado adicional
% y ademas los cuatro subpasos de RK4 evaluan la derivada en instantes
% intermedios, donde un biestable de sentido no tiene significado fisico.  La
% zona muerta capta lo que aqui importa ---que el regulador no puede corregir
% errores arbitrariamente pequenos--- que es justo lo que castiga a una ley
% que trabaja a base de correcciones continuas y menudas.
if ~isempty(P.actNL)
    nl = P.actNL;
    if ~isfield(nl,'idx'),  nl.idx  = [36 42 43]; end   % cfld, cxggd, csyd
    if ~isfield(nl,'tau'),  nl.tau  = [P.ktc2fl P.ktc2rh P.ktc2sy]; end
    if ~isfield(nl,'dead'), nl.dead = 0; end
    dd = nl.dead;  if isscalar(dd), dd = dd*ones(1,numel(nl.idx)); end
    for kk_ = 1:numel(nl.idx)
        j_ = nl.idx(kk_);
        e_ = xdot(j_)*nl.tau(kk_);           % reconstruye u - x
        if abs(e_) <= dd(kk_)
            xdot(j_) = 0;
        else
            xdot(j_) = (e_ - sign(e_)*dd(kk_))/nl.tau(kk_);
        end
    end
end
if nargout > 1
    % output row for plotting/logging (matches xx2 in pba1_240814bk.m)
    % Columnas 1..25: identicas al log original (las usa pte47_plot).
    % Columnas 26..31: variables de la identificacion de Amin et al. (1984),
    %   26 tsso  27 trho  28 psso   (salidas y)
    %   29 cbmd  30 cxgg  31 cwsy   (entradas u realmente aplicadas)
    ylog=[t,ntr,mwo,psso,whp,c3md,cacvd,cfld,card,...
        vdrw,vdew,cfwd,cdwd,hsso,hrho,csyd,cxggd,...
        nfp,cgrd,cfnd,twwm,nfd,nid,nrp,ncp,...
        tsso,trho,psso,cbmd,cxgg,cwsy,...
        ktss,ktrh,kpsso,ldc,...
        tsso_m,trho_m,psso_m];
    % Columnas 26..28 son las salidas VERDADERAS: con ellas se evalua el
    % desempeno.  Las 36..38 son las MEDIDAS (con ruido), que es lo que ve
    % el regulador.  Separarlas evita el error de juzgar a un controlador
    % por la senal ruidosa que el mismo esta leyendo.
    %   32 ktss  33 ktrh  34 kpsso  35 ldc  (consignas de Usoro y demanda de
    %   carga; el regulador auto-sintonizable sigue EXACTAMENTE las mismas
    %   el regulador auto-sintonizable sigue EXACTAMENTE las mismas, para que
    %   la comparacion contra los PI originales sea justa)
end
