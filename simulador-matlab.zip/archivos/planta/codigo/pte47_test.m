function [caseName, ramp, descr] = pte47_test(n)
%PTE47_TEST  Definicion de las pruebas V.1 - V.4 de la tesis de Usoro.
%
%   [CASO, RAMP, DESCR] = PTE47_TEST(N),  N = 1..7
%
%   Devuelve el caso de condiciones iniciales y los pares nombre/valor que
%   definen la rampa del Load Demand Computer para esa prueba.  Se usa
%   directamente como  R = pte47_run(N).
%
%   Las cuatro pruebas de carga de la tesis (capitulo V):
%
%     N   prueba              x0        ldc          t rampa    duracion
%     -----------------------------------------------------------------
%     1   100%  -> 77.5%      '100'     5.000->3.875  10..100 s   90 s
%     2   77.5% -> 50%        '775'     3.875->2.500  10..120 s  110 s
%     3   50%   -> 77.5%      '50'      2.500->3.875  10..120 s  110 s
%     4   77.5% -> 100%       '775'     3.875->5.000  10..100 s   90 s
%
%   Todas a 15% por minuto (90 MW/min = 0.0125 V/s en la senal ldc, donde
%   5 V = 100% = 600 MW), 10 s de estado estacionario antes de la rampa y
%   700 s de simulacion (7001 pasos de 0.1 s), igual que las figuras
%   V.1 a V.4 de la tesis.
%
%   OJO: el codigo original tenia la rampa de la prueba 1 escrita a mano
%   dentro de digpte47_100/_775/_50, es decir las cuatro pruebas corrian
%   ldc = 5 - 0.0125*(min(t,100)-10).  Para los casos '775' y '50' eso
%   hacia saltar ldc de 3.875 (o 2.5) a 5.0 en t = 10 s: la planta subia a
%   plena carga y luego bajaba, que es justo lo que no coincidia con Usoro.
%
%   See also PTE47_RUN, PTE47_CASE.

switch n

    case 1      % Figura V.1
        caseName = '100';
        ramp  = {'ldcStart', 5.000, 'ldcRate', -0.0125, ...
                 'ldcT0', 10, 'ldcT1', 100, 'samples', 7001};
        descr = 'Test 1: rampa de carga 100% -> 77.5% a 15%/min';

    case 2      % Figura V.3
        caseName = '775';
        ramp  = {'ldcStart', 3.875, 'ldcRate', -0.0125, ...
                 'ldcT0', 10, 'ldcT1', 120, 'samples', 7001};
        descr = 'Test 2: rampa de carga 77.5% -> 50% a 15%/min';

    case 3      % Figura V.5
        caseName = '50';
        ramp  = {'ldcStart', 2.500, 'ldcRate',  0.0125, ...
                 'ldcT0', 10, 'ldcT1', 120, 'samples', 7001};
        descr = 'Test 3: rampa de carga 50% -> 77.5% a 15%/min';

    case 4      % Figura V.7
        caseName = '775';
        ramp  = {'ldcStart', 3.875, 'ldcRate',  0.0125, ...
                 'ldcT0', 10, 'ldcT1', 100, 'samples', 7001};
        descr = 'Test 4: rampa de carga 77.5% -> 100% a 15%/min';

    % ---------------- pruebas de emergencia, capitulo V ----------------
    % Las cuatro de arriba son rampas de demanda de carga.  Estas tres
    % entran por otro camino ---el sistema electrico auxiliar y el lado del
    % aire--- y la demanda de carga NO se mueve: la prealimentacion del
    % controlador no ve venir nada.  Por eso son un banco de validacion
    % independiente del que se uso para disenar el controlador.

    case 5      % Figura V.9
        % 77,5 % de carga, 10 s en estacionario, y escalon del 30 % en la
        % tension de la barra auxiliar: 4160 -> 2912 V.  El par de una
        % maquina de induccion va con V^2, asi que el par cae al 49 %.
        % Usoro: «la mayoria de las centrales dispararia a este nivel de
        % tension reducida».
        caseName = '775';
        ramp  = {'ldcStart', 3.875, 'ldcRate', 0, ...
                 'ldcT0', 10, 'ldcT1', 10, 'samples', 7001, ...
                 'velecFcn', @(t) 4160.0 - 1248.0*(t >= 10)};
        descr = 'Test 5: escalon del 30% en la tension a 77,5% de carga';

    case 6      % Figura V.10
        % 77,5 % (465 MW), 10 s en estacionario, y caida de frecuencia a
        % 0,8 Hz/s durante 5 s: 60 -> 56 Hz.  nelec es la velocidad
        % sincrona en rad/s, 376,991 = 2*pi*60.
        %
        % OJO: el port traia comentada una linea que sostenia 54/60 despues
        % de t = 15 s.  El texto de Usoro dice 56 Hz, no 54.  Se implementa
        % 56, que es lo que dice el texto y lo que da la rampa de 0,8 Hz/s
        % durante 5 s.
        %
        % Usoro DESACTIVA la recirculacion de gases en esta prueba.
        caseName = '775';
        ramp  = {'ldcStart', 3.875, 'ldcRate', 0, ...
                 'ldcT0', 10, 'ldcT1', 10, 'samples', 7001, ...
                 'nelecFcn', @(t) 2*pi*(60 - 0.8*min(max(t-10,0),5)), ...
                 'grFreeze', true};
        descr = 'Test 6: caida de frecuencia de 60 a 56 Hz en 5 s';

    case 7      % Figura V.11
        % 100 % de carga (no 77,5 %), 10 s en estacionario, y se pierde uno
        % de los dos pares de ventiladores FD e ID: knfd y knid de 2 a 1.
        % La demanda de carga se DEJA al 100 % ---sin run-back forzado---,
        % que es lo que hace dura la prueba.
        %
        % Usoro tambien desactiva aqui la recirculacion de gases.
        caseName = '100';
        ramp  = {'ldcStart', 5.000, 'ldcRate', 0, ...
                 'ldcT0', 10, 'ldcT1', 10, 'samples', 7001, ...
                 'knfdFcn', @(t) 2 - (t >= 10), ...
                 'knidFcn', @(t) 2 - (t >= 10), ...
                 'grFreeze', true};
        descr = 'Test 7: perdida de un par de ventiladores FD e ID a plena carga';

    otherwise
        error('pte47_test:unknownTest', ...
            'Prueba %g no definida.  Usa 1..7.', n);
end

end
