% Prueba 2, Digital Model, Usoro47, MIT, 1977, pba2_rk4.m
% "A drum boiler-turbine power plant under emergency state control", orden 47
%--------------------------------------------------------------------------
% rampa de carga 77.5% -> 50% a 15%/min
% Corresponde a la Figura V.3 de la tesis (700 s, Ts = 0.1 s, RK4 paso fijo).
%
% Wrapper delgado: el trabajo esta en pte47_run (integrador) y pte47_plot
% (figuras); el modelo es digpte47.m, las constantes las arma una sola vez
% pte47_params y la definicion de la prueba esta en pte47_test.
%
% 'clampStates' recorta los estados de control 23..46 despues de cada paso
% con los mismos limchk/check del modelo (ver pte47_clamp).  En el Fortran
% original las variables de control estaban en COMMON y limchk recortaba el
% estado mismo; en el port a MATLAB solo recortaba la copia local, asi que
% los integradores se cargaban (se veia sobre todo en la prueba 4).
% Para reproducir el comportamiento del port anterior: pte47_run(2).
%--------------------------------------------------------------------------
clear
close all
format short e

R = pte47_run(2, 'clampStates', true);
pte47_plot(R);

% Mismos nombres de variables que dejaban los scripts viejos:
xx  = R.xx;
xx2 = R.xx2;
res = R.res;
x0  = R.xx(end,:).';                % estado final (era el x0 que iba corriendo)
