function T = pte47_steptest(caseName, varargin)
%PTE47_STEPTEST  Retardos y amplitudes admisibles de las tres entradas.
%
%   T = PTE47_STEPTEST(NAME)
%   T = PTE47_STEPTEST(NAME, 'delta', [0.3 0.3 0.3], 'tfin', 400, ...)
%
%   Reproduce las dos pruebas que Amin et al. (1984, seccion IV) hacen antes
%   de identificar:
%
%   (1) RETARDO.  Se lleva el sistema al estado estacionario, se abre el lazo
%       y se aplica un escalon en UNA entrada dejando las otras dos en su
%       valor estacionario.  El retardo de cada par entrada-salida es el
%       tiempo que tarda la salida en empezar a moverse.  El articulo obtiene
%       un retardo maximo de 20 s (entre CWSY y TRHO) y de ahi elige Ts.
%
%   (2) AMPLITUD ADMISIBLE.  La amplitud de fluctuacion aceptable de cada
%       entrada es la que NO produce, en ninguna salida, una fluctuacion
%       mayor al 1 % de su valor estacionario.  El articulo reporta
%       +-0.1 V para CBMD, +-0.3 V para CXGG y +-0.6 V para CWSY.
%
%   IMPORTANTE: en lazo abierto la planta se aleja sola de su punto de
%   operacion (sobre todo PSSO, que no tiene autorregulacion sin el lazo
%   maestro).  Por eso la respuesta al escalon se mide SIEMPRE contra una
%   corrida nominal con u = u_ss, no contra el valor estacionario:
%
%       dy(t) = y_escalon(t) - y_nominal(t)
%
%   Opciones (nombre/valor):
%       'delta'   1x3, tamano del escalon de prueba por entrada  [0.3 0.3 0.3]
%       'tfin'    duracion de cada corrida en s                  [400]
%       'tol'     fraccion del cambio total que define "empezo
%                 a moverse", para el retardo                    [0.02]
%       'tolPct'  fluctuacion maxima admisible en la salida, en
%                 % del valor estacionario                       [1.0]
%       'verbose' imprimir las tablas                            [true]
%
%   Devuelve T con
%       T.y_ss, T.u_ss     punto de operacion
%       T.delay   3x3      retardo (s) de la entrada j a la salida i
%       T.gain    3x3      ganancia estatica aproximada dy_i/du_j al final
%       T.ampMax  1x3      amplitud que satura el criterio del 1 %
%       T.pctMax  3x3      fluctuacion maxima (%) de la salida i por el
%                          escalon 'delta' en la entrada j
%
%   See also PTE47_SS, PTE47_IDENT_DATA.

opt = struct('delta',[0.3 0.3 0.3], 'tfin',400, 'tol',0.02, ...
             'tolPct',1.0, 'verbose',true);
for i = 1:2:numel(varargin), opt.(varargin{i}) = varargin{i+1}; end

S    = pte47_ss(caseName);
u_ss = S.u(:);
y_ss = S.y(:);

Ts      = S.P.Ts;
nsteps  = round(opt.tfin/Ts);
stride  = 10;                       % una fila de log por segundo
com = {'samples',nsteps, 'ldcT0',inf, 'logStride',stride, ...
       'openLoop',[true true true]};

uName = {'CBMD','CXGG','CWSY'};
yName = {'TSSO','TRHO','PSSO'};

% ---- corrida nominal (linea base de la deriva) --------------------------
R0 = pte47_run(caseName, com{:}, 'uFcn', @(t) u_ss);
tt = R0.xx2(:,1);
Y0 = R0.xx2(:,26:28);

delay  = nan(3,3);
gain   = nan(3,3);
pctMax = nan(3,3);
DY     = cell(1,3);

tEnd = nan(1,3);
for j = 1:3
    uj = u_ss;  uj(j) = uj(j) + opt.delta(j);
    Rj = pte47_run(caseName, com{:}, 'uFcn', @(t) uj);

    % En lazo abierto una entrada demasiado grande diverge antes de tfin
    % (con CBMD basta +0.3 V para que la presion se dispare hacia t~210 s).
    % pte47_run corta la corrida y devuelve la trayectoria parcial, asi que
    % la comparacion se hace sobre las filas que si existen.
    m = min(size(Rj.xx2,1), size(Y0,1));
    if m < size(Y0,1)
        warning('pte47_steptest:short', ...
            'El escalon de %+.3f V en %s diverge: solo %g s utiles de %g s.', ...
            opt.delta(j), uName{j}, tt(m)-tt(1), opt.tfin);
    end
    dY = Rj.xx2(1:m,26:28) - Y0(1:m,:);   % respuesta al escalon, sin la deriva
    DY{j}   = dY;
    tEnd(j) = tt(m) - tt(1);

    for i = 1:3
        gain(i,j)   = dY(m,i)/opt.delta(j);
        pctMax(i,j) = 100*max(abs(dY(:,i)))/y_ss(i);
        thr = opt.tol*max(abs(dY(:,i)));
        k = find(abs(dY(:,i)) >= thr, 1, 'first');
        if ~isempty(k), delay(i,j) = tt(k) - tt(1); end
    end
end

% ---- amplitud que satura el criterio del 1 % ----------------------------
% Para fluctuaciones pequenas la respuesta es practicamente lineal, asi que
% la amplitud admisible se escala desde el escalon de prueba.
ampMax = zeros(1,3);
for j = 1:3
    ampMax(j) = opt.delta(j) * min(opt.tolPct ./ pctMax(:,j));
end

T = struct('y_ss',y_ss, 'u_ss',u_ss, 'delay',delay, 'gain',gain, ...
           'ampMax',ampMax, 'pctMax',pctMax, 'delta',opt.delta, ...
           't',tt, 'dY',{DY}, 'tEnd',tEnd, 'caseName',char(caseName));

if opt.verbose
    fprintf('\n=== PTE47 pruebas de escalon, caso %s ===\n', char(caseName));
    fprintf('u_ss = [%.4f %.4f %.4f] V\n', u_ss);
    fprintf('y_ss = [%.2f R  %.2f R  %.2f psia]\n\n', y_ss);

    fprintf('RETARDO (s) al %g %% del cambio total\n', 100*opt.tol);
    fprintf('%-8s %10s %10s %10s\n', '', uName{:});
    for i = 1:3
        fprintf('%-8s %10.1f %10.1f %10.1f\n', yName{i}, delay(i,:));
    end
    fprintf('  retardo maximo = %.1f s  ->  Ts sugerido >= %.0f s\n\n', ...
            max(delay(:)), max(delay(:)));

    fprintf('GANANCIA ESTATICA aproximada al final de cada corrida (dy/du)\n');
    fprintf('  ventana util por entrada: %.0f / %.0f / %.0f s\n', tEnd);
    fprintf('%-8s %10s %10s %10s\n', '', uName{:});
    for i = 1:3
        fprintf('%-8s %10.3f %10.3f %10.3f\n', yName{i}, gain(i,:));
    end

    fprintf('\nFLUCTUACION MAXIMA (%% de y_ss) por el escalon de prueba\n');
    fprintf('escalon = [%.2f %.2f %.2f] V\n', opt.delta);
    fprintf('%-8s %10s %10s %10s\n', '', uName{:});
    for i = 1:3
        fprintf('%-8s %9.3f%% %9.3f%% %9.3f%%\n', yName{i}, pctMax(i,:));
    end

    fprintf('\nAMPLITUD ADMISIBLE (criterio: ninguna salida excede %g %%)\n', opt.tolPct);
    fprintf('%-8s %10s %10s %10s\n', '', uName{:});
    fprintf('%-8s %10.3f %10.3f %10.3f   V\n', 'este trabajo', ampMax);
    fprintf('%-8s %10.3f %10.3f %10.3f   V\n', 'Amin 1984', 0.1, 0.3, 0.6);
    fprintf('\n');
end

end
