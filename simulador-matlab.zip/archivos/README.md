# Réplica de Amin, Masada y Womack (1984)

> M. Amin, G. Y. Masada, B. F. Womack, **«Application of a Multivariable
> Self-Tuning Controller to a Power Plant Boiler»**, *1984 American Control
> Conference*, WP3 4:00, pp. 339–346. DOI 10.23919/ACC.1984.4788400.

Esta carpeta reproduce **el trabajo de Amin y nada más**. No contiene ningún
resultado, criterio ni configuración de esta tesis: ni el GPC, ni la entrada
exógena `ldc`, ni el cociente contra el PI como criterio, ni las pruebas
V.1–V.4 de Usoro. Lo que hay aquí es lo que hicieron ellos, con su modelo, su
controlador, sus dos pruebas y sus figuras.

**Una sola excepción, opcional y marcada:** el modelo 3×4, con la demanda de
carga `ldc` como cuarta entrada medida (§8). Se añadió a pedido del tutor para
probar los mismos controladores con él. **No es del artículo.** Por omisión todo
corre con el 3×3, que da resultados idénticos a los de antes de la extensión, y
lo que produce el 3×4 va a archivos con sufijo `_ldc`.

Es **autónoma**: lleva su propia copia del modelo de planta y se puede
comprimir y entregar sola.

**Para verla directamente, sin ningún paso previo:**

```matlab
>> cd 7-replica-amin
>> INICIO                 % abre el simulador: elegir prueba y controlador, «Iniciar»
>> INICIO('figuras')      % figuras 6 a 9 e índices, con los resultados ya calculados
>> INICIO('consola')      % la consola de operación (§5 bis)
```

**Organización de la carpeta:** afuera solo está `INICIO.m`, que es lo único que hace falta para abrir el simulador (ventana «Simulador Planta Termoeléctrica modelo de orden 47»). Todo lo demás (código, copia del modelo de planta, datos, resultados y esta documentación) está en la subcarpeta `archivos/`; los comandos de abajo que no son `INICIO` se corren desde ella.

`INICIO`, `amin_sim` y `amin_hmi` ponen la ruta ellos mismos y usan el modelo y
la tabla ya calculados en `datos/`. La versión para entregar a terceros es
`replica-amin-1984.zip`, en la raíz del repositorio: sólo lo necesario más un
`LEEME.md` corto.

Para trabajar con la réplica completa:

```matlab
>> cd 7-replica-amin/archivos
>> setup_amin
>> verifica_amin          % catorce comprobaciones de integridad
>> OUT = amin_main        % la réplica completa, por lotes
>> amin_sim               % el simulador interactivo (3x3 o 3x4)
>> verifica_ldc           % comprobaciones del modelo 3x4
>> verifica_k             % comprobaciones del retardo k = 2
>> verifica_demanda       % comprobaciones de la prueba con demanda real (§11)
```

---

## 1. Qué replica, exactamente

| | Amin et al. (1984) |
|---|---|
| **Planta** | caldera de 600 MW quemando combustóleo, Combustion Engineering 2400 psig 1000 °F/1000 °F, turbogenerador Westinghouse. Modelo de parámetros concentrados de **47 estados** de Usoro (1977) — **el mismo** que usa esta tesis |
| **Salidas** | y = [TSSO, TRHO, PSSO] — temperatura de vapor sobrecalentado (°R), de vapor recalentado (°R), presión de vapor sobrecalentado (psia) |
| **Entradas** | u = [CBMD, CXGG, CWSY] — demanda maestra de caldera, demanda de inclinación de quemadores, demanda de atemperación del sobrecalentador (1–5 V) |
| **Nota de planta** | «In this study only the burner tilt control is assumed to be active since in most applications it is sufficient to control reheat temperature» |
| **Modelo** | AR (en rigor ARX) multivariable, ec. (16), 3×3, **N = 5**, **k = 1**, **T = 20 s**, incremental respecto del punto de operación |
| **Estimador** | mínimos cuadrados recursivos, ec. (15) |
| **Controlador** | Clarke y Gawthrop (1975) extendido a MIMO por **Koivo (1980)**; criterio (2) con P = 1, R = I, Q′ = √λ·I; ley (12) |
| **Identificación** | 75 % de carga, lazo abierto, **10 corridas de 400 s** con entradas gaussianas, estimador **encadenado** entre corridas |
| **Pruebas** | dos rampas de carga, **90 → 70 %** y **70 → 90 %**, a **10 %/min** |
| **Modificación** | tabla de parámetros cada 5 % de carga, estimador apagado durante el transitorio; y la variante con el mando calculado cada 2 s |

Las dos rampas **no son** ninguna de las cuatro pruebas de Usoro: aquéllas van
a 15 %/min entre 100, 77,5 y 50 %. Ésta es una diferencia de fondo, no de
detalle, y es la razón de que esta carpeta no reutilice `pte47_test`.

---

## 2. Los nueve huecos del artículo

Un artículo de seis páginas de 1984 no basta para reproducir un experimento sin
tomar decisiones. Éstas son **todas** las que ha habido que tomar. Ninguna está
escondida en el código: cada una aparece en la ayuda de la función donde actúa.

### Hueco 1 — el valor de λ

La sección V dice que el coste (2) se usa con `P(q⁻¹) = 1`, `R(q⁻¹) = I` y
`Q′(q⁻¹) = √λ·I`, y la ley reducida lleva `λ(B₀ᵀ)⁻¹`. **El valor numérico de λ
no aparece en ninguna parte del artículo.** Sin él la réplica no está
determinada: λ = 0 es varianza mínima pura y λ grande es un lazo casi abierto.

*Qué se hace:* `amin_lambda` barre λ sobre las dos pruebas del artículo y
reporta la tabla completa. Se elige el valor cuyo error máximo se parece más al
que se lee en sus figuras 6a y 6b, y **se declara que la elección es nuestra**.
La sensibilidad del resultado a λ es en sí misma un dato que conviene enseñar.

### Hueco 2 — el factor de olvido β

La ecuación (15) lleva un β («Where β is a forgetting factor») y su valor no se
da. En la identificación fuera de línea β = 1 es lo único coherente con
encadenar diez corridas del mismo sistema invariante; en línea hace falta β < 1
o el estimador deja de moverse.

*Qué se hace:* β = 1 fuera de línea, β = 0,99 en línea, las dos como opción
visible en `amin_ident` y `amin_stc_init`.

### Hueco 3 — θ(0) y P(0)

«Initial matrices θ(0) and P(0) were chosen **arbitrarily**». Literalmente
arbitrarias.

*Qué se hace:* θ(0) = 0 y P(0) = 10⁴·I fuera de línea (el estimador sin
información previa); en línea, θ(0) = el modelo identificado —que es lo que el
artículo sí especifica— y **P(0) = la covarianza con que termina esa misma
identificación** (`amin_covarianza`).

**Cambio del 2026-10-04.** Hasta esa fecha P(0) en línea era 10²·I. Con ese
valor el STC se alejaba mucho de la figura 6 del artículo: el estimador daba
pasos grandes con la poca excitación de la rampa, B₀ llegaba a un número de
condición de 6311 y los mandos se saturaban el 92–98 % del tiempo. Con la P
heredada el STC se acerca a la figura 6 (errores máximos de 18,9 / 8,1 / 102 y
20,0 / 16,1 / 255 contra unos 23 / 10 / 250 y 20 / 10 / 200 leídos en el
artículo) y la saturación baja al 28–48 %. Ahora es el valor por omisión de
`amin_stc_init`, `amin_run`, `amin_sim` y `amin_hmi`; `'P0',1e2` recupera la
versión anterior. La tabla por carga (`amin_tabla`) y los barridos de λ
(`amin_lambda`, `amin_lambda_todos`) siguen con 10²·I, que es como se
construyeron. Las tablas de resultados de este README marcadas con
«P(0) = 100·I» son de antes del cambio.

### Hueco 4 — una inconsistencia entre (16) y (17b)

La ecuación (16) tiene A₁…A_N, o sea **N** matrices de salida. El regresor
(17b) escribe el bloque de salidas como y(t−k)…y(t−k−N), o sea **N+1**
términos. Las dos cosas no pueden ser ciertas a la vez.

*Qué se hace:* se sigue (16) y (17a), que son consistentes entre sí:

```
x(t−k) = [u(t−k) … u(t−k−N), y(t−1) … y(t−N)]      npar = (N+1)·nu + N·ny = 33
```

El 33 coincide con el conteo que esta tesis venía usando para «la estructura
3×3 de Amin», lo que es una confirmación independiente de la lectura.

### Hueco 5 — cómo se mide el retardo

«The time delays between the inputs and outputs are determined by […]
introducing, in open loop, a step change in one of the inputs», y sale «the
largest time delay of 20 seconds […] between CWSY and TRHO». No dice con qué
criterio se declara que la salida se ha movido.

*Qué se hace:* `amin_retardos` usa el primer instante en que la salida se
separa de su estacionario más de un 2 % de su excursión total, y **declara el
umbral**, porque con otro umbral el número cambia.

### Hueco 6 — el instante de arranque de la rampa

Las figuras van de 0 a 800 s y el transitorio empieza cerca del origen, pero el
artículo no da el instante exacto.

*Qué se hace:* t₀ = 10 s, la convención de Usoro, que es además la que usa el
resto del repositorio. Es una opción de `amin_rampa`.

### Hueco 7 — los puntos de operación de 70, 75, 80, 85 y 90 %

La tesis de Usoro tabula condiciones iniciales de **tres** niveles: 100, 77,5 y
50 %. Amin identifica al **75 %** y construye su tabla a 70, 75, 80, 85 y 90 %.
Ninguno de los cinco está tabulado.

*Qué se hace:* `amin_estacionario` lleva la planta a cada nivel con la demanda
de carga y deja que los PI originales la asienten, comprobando que ‖ẋ‖ cae. Es
lo mismo que haría la planta, y queda cacheado en `datos/`.

### Hueco 8 — sobre qué datos se mide «the best prediction»

Es el que más cambia la elección del orden, y por eso va después de los otros
siete.

> «The order, N, of the AR model (16) is estimated by identifying the model for
> several values of N and **selecting the value which results in the best
> prediction of the outputs of the system**.»

El artículo **no dice sobre qué datos** se mide esa predicción, y la diferencia
lo decide todo:

- medida **sobre los mismos datos de la identificación**, el ajuste a un paso
  crece monótonamente con N —más parámetros siempre ajustan mejor en la propia
  muestra—, así que el criterio degenera y elige **siempre el candidato más
  grande**. Con N = 1…8 sale **N = 8**, no 5. No es un fallo de la réplica: es
  lo que da la lectura literal, y conviene enseñarlo porque explica por qué el
  criterio de Amin, tal como está escrito, no puede haber sido el que usaron.
- medida **sobre corridas que no se usaron para estimar**, el ajuste tiene un
  máximo interior y el criterio decide de verdad.

*Qué se hace:* las últimas tres corridas se apartan, el orden se elige con
ellas, y **el modelo final se reestima encadenando las diez**, que es lo que el
artículo describe. `amin_ident` devuelve la tabla con las tres columnas —dentro
de muestra, fuera de muestra y simulación libre— más `|z|max` y `cond(B₀)`, para
que la elección se pueda discutir.

**Y el orden que se usa para todo lo demás es el 5 del artículo.** `amin_main`
corre el barrido completo —es el material de este hueco— pero impone después
`N = 5`, porque esto es una réplica y el orden es un dato publicado, no algo que
haya que redescubrir. Medido, el barrido lo respalda: el ajuste fuera de muestra
va de 88,29 a 92,24 puntos, dentro de 1 punto del mejor quedan N = 2, 3, 4, 5 y
6, y el 5 está a 0,24 puntos del ganador. Con `amin_main('orden','criterio')` se
deja que el barrido elija, y sale 6; la diferencia con el 5 es ruido de
estimación, y ésa es justamente la conclusión que hay que reportar.

Y hay que recordar lo que el propio artículo admite justo después:

> «It is possible that a lower order AR model is adequate. However, since the
> purpose of this work is to obtain an input-output representation which closely
> represents the system at a constant level, **no attempt was made to verify
> whether a suitable lower order AR model could be found**.»

O sea que **el 5 de Amin no es un óptimo: es un orden que les bastaba**. Eso
cambia cómo hay que presentar la comparación: no «nuestra réplica da otro
orden», sino «el criterio publicado no determina un orden, y los autores lo
dicen».

### Hueco 9 — qué pasa con la turbina en el experimento en lazo abierto

La sección IV dice que la planta se corre «in open loop», pero **no dice qué
se hace con el control de la turbina**. En el modelo de Usoro la válvula de
gobierno tiene su propio lazo de carga: compara la demanda `ldc` con los MW
generados y mueve la válvula (`digpte47`, líneas ~474–485, integrador `c2tr`,
estado 44). Abrir CBMD, CXGG y CWSY no lo abre.

*Qué se hace:* `amin_datos` abre **solo los tres lazos del artículo**; el de
turbina queda cerrado. Es la lectura más literal —el artículo sólo habla de
esas tres entradas— pero tiene una consecuencia que hay que declarar. Sin el
lazo maestro de caldera la planta queda en *boiler following* sin quien regule
la presión:

```
presión baja → bajan los MW → la turbina abre la válvula → sale más vapor → la presión baja más
```

Es una realimentación positiva, y en lazo abierto **la presión es inestable**.
Medido al 75 % (PSSO a los 400 s):

| caso | lazo MW cerrado (réplica) | válvula fija |
|---|---|---|
| corrida 1 de identificación | −606 psia | −112 psia |
| la misma, con la entrada en espejo (−du) | −494 psia | −129 psia |
| escalón CBMD +0,02 / −0,02 V | +176 / −199 psia | +26 / −25 psia |
| escalón CBMD +0,1 V | diverge | +139 psia |

Con la válvula fija la presión se autorregula y la deriva baja unas cinco
veces, al orden de los ±50 psia de la figura 5 del artículo. Lo más probable
es que Amin tuviera la válvula fija, pero el artículo no lo dice.

Queda además una deriva que no depende del signo de la entrada (la corrida y
su espejo bajan la presión casi lo mismo). Cerca de la mitad viene del límite
cruzado aire/combustible de `digpte47` (líneas 368–378): al subir la demanda
el combustible espera al aire y al bajar cae de inmediato, así que en promedio
entra menos combustible del que se pide.

No se cambia porque en las rampas de prueba, en lazo cerrado, la turbina **sí**
tiene su lazo de MW: identificar con la válvula fija daría el modelo de otra
planta. Cambiarlo obligaría además a regenerar datos, modelo, tabla y
resultados. Queda como decisión abierta.

**La figura 5 apunta a la válvula fija (2026-10-04).** Repitiendo la figura 5
a 1400 s (`amin_fig5`, opción `'valvula'`): con el lazo de MW activo la presión
cae por debajo de 2000 psia antes de los 400 s; con la válvula fija la planta
se comporta como la de Amin (temperaturas arriba, presión unos 100–200 psia
abajo y estable). Con entradas constantes, el lazo activo deriva −22 psia en
1400 s y sigue creciendo; la válvula fija se queda en ±0,05 psia. Aun así se
conserva el lazo activo, porque el modelo identificado con la válvula fija
empeora el STC (IAE/PI de presión de 5,8 a 6,3 al bajar y de 15,1 a 22,6 al
subir). Las dos lecturas están disponibles: `amin_datos('valvula',true)` genera
las diez corridas con la válvula fija y **los mismos mandos** que las
originales (`datos/amin_datos_75_valvula.mat`), y `figuras_articulo` deja el
modelo en `datos/amin_modelo_valvula.mat`.

---

## 2 bis. Lo que el artículo dice y no se estaba cumpliendo

Los nueve huecos de arriba son cosas que el artículo **no** dice. Esta sección es
la contraria: cosas que **sí** dice y que la primera versión del código no
respetaba. Salieron de releer el original línea por línea contra el código, y
las cuatro están corregidas.

### a) Sólo actúa la inclinación de quemadores

> «In this study only the burner tilt control is assumed to be active since in
> most applications it is sufficient to control reheat temperature.»

En el modelo de Usoro, **CXGG manda dos actuadores en rango partido**: la
inclinación de quemadores (`xgg`) y la válvula de atemperación del recalentador
(`cry = −cxggd`, `wry = xducer(−2, −1, 0, 50, cry)`). O sea que el rociado está
cerrado mientras CXGG ≥ 2 V y abre hasta 50 lb/s al bajar a 1 V.

En régimen permanente da igual —CXGG vale entre 2,87 y 4,74 V del 70 al 90 % de
carga— pero **en cuanto el auto-sintonizable satura CXGG contra 1 V el rociado
entra**, y ése es justo el régimen en el que se le estaba midiendo. Medido: con
CXGG en 1,5 V durante 60 s, el rociado cambia TRHO en **11,7 °R** (1441,3 con
rociado contra 1453,1 sin él).

Corregido con la bandera `P.soloTilt`, apagada por omisión en la planta —el
resto del repositorio no cambia— y puesta por `amin_planta`, por donde pasa
ahora toda la réplica. `verifica_amin` comprueba las dos cosas (prueba 13).

### b) El orden del modelo es 5

Ver el hueco 8: el barrido se corre, pero la elección la impone el artículo.

### c) La historia inicial del estimador es el estado estable, no un hueco

> «Initial matrices θ(0) and P(0) were chosen arbitrarily and x(0−k) contained
> steady state values of inputs and outputs at the constant load level. […] In
> the second run, x(0−k) again contained steady state values.»

Dos consecuencias que no se estaban cumpliendo:

1. **En la identificación** se saltaban las primeras N+k muestras de cada
   corrida por no tener historia propia. Con 20 muestras por corrida eso tiraba
   el 30 % de los datos del artículo. Ahora la historia se repone a cero
   —estado estable en variables incrementales— al empezar cada corrida, y se
   usan las 20.
2. **En el lazo cerrado** había un calentamiento de N·T segundos en el que
   mandaba el PI. Eso no está en el artículo: las dos pruebas arrancan en un
   estado estable, así que la historia es conocida y vale cero, el primer mando
   sale exactamente igual a u_ss y no hay salto. El controlador manda desde
   t = 0, que es lo que enseña su figura 6. El modo anterior se conserva como
   `amin_stc_init(..., 'arranque','espera')` para poder enseñar la diferencia.

### d) Las amplitudes de identificación son las del artículo

±0,1 para CBMD, ±0,3 para CXGG y ±0,6 para CWSY, como desviación típica de
entradas gaussianas centradas en el estado estable. Son **datos publicados** y
se usan tal cual, aunque en esta planta incumplan el criterio del 1 % con el que
los autores dicen haberlos obtenido. `amin_limites` mide ese desajuste y hay que
reportarlo; lo que no se puede es cambiar las amplitudes, porque entonces ya no
sería su experimento.

---

## 3. Una errata del artículo, y está verificada

La ley de control impresa en la página 344 es

```
u(t) = {B₀ + λ(B₀ᵀ)⁻¹}⁻¹ { [I − A(q⁻¹)] y(t+1) − [B(q⁻¹) − B₀] u(t) + w(t) }
```

Con la convención de (16), `[I − A(q⁻¹)]y(t+1) = −A₁y(t) − … − A_N y(t−N+1)`.
Sustituyendo eso en (16) **no sale y(t+1) = w**: sale

```
y(t+1) = w − 2 Σ Aᵢ y(t+1−i)
```

El despeje correcto de (16) imponiendo y(t+1) = w es el mismo corchete con el
**primer término cambiado de signo**:

```
B₀ u(t) = w(t) + A₁y(t) + … + A_N y(t−N+1) − B₁u(t−1) − … − B_N u(t−N)
```

Es una errata de composición, de las que abundan en los originales de cámara de
1984. **Está comprobada en un renglón**: con λ = 0 y modelo exacto, la versión
corregida deja y(t+1) = w a precisión de máquina y la impresa no
(`verifica_amin`, pruebas 8 y 9).

Se implementa la corregida. Poniendo `'literal',true` en `amin_stc_init` se usa
la impresa, para poder **enseñar** la diferencia en vez de tener que afirmarla.

---

## 4. Lo que el artículo afirma, para contrastarlo

Las tres conclusiones que la réplica tiene que poder confirmar o desmentir, en
sus propias palabras:

1. **El auto-sintonizable no mejora al PI en el transitorio.**
   > «Fluctuations of the outputs while in the transient mode using the
   > self-tuning controller are comparable or sometimes larger than the
   > fluctuations resulting from the PI controllers. […] The estimator […] is
   > unable to track the relatively fast changing parameters using the small
   > amount of information obtained during the transient period.»

   → comparar las filas `pi` y `stc` del resumen.

2. **Con la tabla por carga sí mejora.**
   > «relatively small deviations from the set points are possible if the
   > estimator can track the changing parameters of the system.»

   → comparar `stc` con `mstc20`.

3. **Calcular el mando más a menudo no aporta.**
   > «reducing the time interval between the successive control calculations
   > will not reduce the deviations of the outputs from their set points if the
   > parameters of the controller are known.»

   → comparar `mstc20` con `mstc2`.

   **Corrección del 2026-09-29.** Hasta esa fecha `amin_stc` armaba mal la
   historia de mandos cuando el mando se calcula más a menudo que el periodo
   del modelo (`lag` = Tm/Tc > 1). Tomaba u(t−2 s), u(t−22 s), u(t−42 s)… en
   vez de u(t−20 s), u(t−40 s)…, es decir, no respetaba el «20 seconds
   apart» del artículo. Con el mando cada 20 s (`lag` = 1) las dos fórmulas
   coinciden, así que **solo cambia `mstc2`**; `pi`, `stc`, `mstc20`,
   `tablapura`, la identificación y k = 2 quedan idénticos. La prueba 14 de
   `verifica_amin` lo comprueba: con el código anterior falla.

   Con λ = 0,5, β = 0,99, P(0) = 100·I y 800 s (J = media de IAE/IAE_PI de
   las tres salidas):

   | | 90 → 70 % | 70 → 90 % | J de las dos pruebas | recorrido de CXGG (90 → 70 %) |
   |---|---|---|---|---|
   | `mstc20` | 0,668 | 2,824 | 1,746 | 16,9 V |
   | `mstc2` antes de corregir | 1,602 | 2,507 | 2,054 | 168 V |
   | `mstc2` corregido | 0,717 | 2,268 | **1,492** | 79,5 V |

   Antes de corregir, el mando cada 2 s era peor que el de 20 s y
   castañeteaba. Corregido, es algo mejor en el índice integral (J_ITAE:
   1,610 frente a 2,232), con un pico de presión parecido (31,6 frente a
   23,1 psia al bajar; 118 frente a 125 psia al subir). Eso se acerca a lo
   que dice el artículo: sale más suave, con desviaciones del mismo orden.
   `resultados/amin_replica.mat`, `amin_resumen.txt` y `amin_fig9.png` ya
   están recalculados. **Las columnas `mstc2` de
   `resultados/amin_lambda_todos*.mat` son anteriores a la corrección**: para
   actualizarlas hay que repetir esos barridos.

Y una cuarta, sobre el límite del muestreo, que es la que explica por qué el
artículo no baja de 20 s:

> «for the self-tuning controller considered here, it is not possible to
> decrease the sampling period below 20 seconds. A smaller sampling period will
> cause the coefficient matrix B₀ […] to become singular.»

`amin_stc` registra `cond(B₀)` en cada instante y avisa, de modo que esa
afirmación también se puede comprobar en vez de creerla.

---

## 5. El simulador

`amin_sim` abre una ventana donde se elige una de las dos pruebas del artículo
y uno de sus cuatro controladores, y la planta de 47 estados se simula en vivo.
No reimplementa nada: el instante de control lo calcula `amin_stc`, el mismo
código que usan `amin_lazo` y `amin_run`.

Los mandos se dibujan **en escalones**, como en la figura 8 del artículo: el
mando calculado en un instante de control se mantiene hasta el siguiente. La
pestaña «Resumen» tiene la disposición, las escalas y los colores de las
figuras 6 a 8 del artículo de la reproducción: arriba TSSO, TRHO y PSSO con su
consigna, abajo CBMD, CXGG y CWSY, el PI de Usoro de fondo en gris y el
controlador en naranja. Las entalpías van solo en las pestañas
TSSO y TRHO, y la pestaña «Mandos» tiene un eje por mando y la demanda de
carga.

Sus mandos no son los de los otros simuladores de la tesis, porque lo que aquí
hay que poder mirar es otra cosa:

| mando | por qué está |
|---|---|
| **λ**, cuadro editable | el artículo **no publica su valor** y todo lo que se concluya depende de él. Moverlo en vivo es la forma más rápida de ver cuánto |
| **β**, cuadro editable | tampoco lo publica |
| **Ley de control**: corregida / **impresa** | alterna entre la ley consistente con (16) y la de la página 344 con su errata de signo. La lectura avisa cuál está puesta y el PDF lo marca en el nombre del archivo |
| **Controlador** | PI de Usoro · auto-sintonizable (su figura 6) · modificado con tabla y estimador congelado (figura 7) · modificado con mando cada 2 s (descrito en el artículo, sin figura) |
| **Prueba** | 90 → 70 %, 70 → 90 %, y carga constante al 75 % para ver el régimen permanente |
| **Retardo k**: 1 / 2 | k = 1 es el del artículo. k = 2 es el que da la regla del artículo con el retardo mayor **medido aquí** (CXGG → TSSO, 34,6 s; §9). Mismos datos, otro modelo y otra tabla por carga |
| **Modelo ARX**: 3×3 / 3×4 | 3×3 es el del artículo. 3×4 añade `ldc` como entrada medida y prealimentada (§8) y **no es del artículo**. Cada uno usa su propio modelo y su propia tabla por carga |

**La ventana.** A la izquierda: qué simular (con la explicación de cada opción
al pasar el ratón por su etiqueta), la marcha —con barra de avance y la fase
en color: listo, corriendo, en pausa, terminado, divergió— y el **estado del
controlador** (modelo, λ/β, estimador actualizando o congelado, ‖Δθ‖,
cond(B₀), tr P, nodo de la tabla). A la derecha, las gráficas y, debajo, la
**lectura** en tabla: y, w, y − w, IAE, ITAE y los cocientes IAE/PI,
ITAE/PI e IAE/ref, en verde si son menores que 1 y en rojo si son mayores.
La primera pestaña, **Resumen**, junta las tres salidas y los mandos para
compararlos sin cambiar de pestaña.

Además de «Resumen», ocho pestañas con una gráfica cada una (son las que van al PDF): **TSSO**, **TRHO**, **PSSO**, **Mandos y
demanda**, **‖Δθ‖** (la deriva de los parámetros respecto del modelo inicial),
**cond(B₀)** —la cifra con la que Amin justifica no bajar de T = 20 s— y
**Estimador**, donde se ve el nodo activo de la tabla por carga y cuándo está
congelado. Esa última pestaña es la única forma de comprobar que la conmutación
ocurre en los puntos medios que describe la sección V. La octava, **Covarianza
P**, dibuja la traza de P(t) y sus valores propios extremos en escala
logarítmica, con la línea de tr P(0) = P₀·npar. El estimador usa una sola P para
las tres filas: 33×33 en el 3×3 y 39×39 en el 3×4.

**Entalpías.** Las pestañas **TSSO** y **TRHO** llevan, debajo de la
temperatura, la entalpía del vapor: **HSSO** (estado 11) y **HRHO**
(estado 14), en BTU/lb. Son los estados que integra el modelo de Usoro y las
variables que él grafica en el capítulo V. La temperatura no es un estado:
sale de la densidad y la entalpía con los ajustes de tablas de vapor
`shstat` y `rhstat`. Se dibujan la del PI de Usoro (gris, con la misma casilla
que la línea base), la del controlador que corre y la de la referencia
fijada. En **Resumen** van también, en la fila de en medio, cada una debajo
de su temperatura. En el PDF cada entalpía va en su propia página, detrás de su
temperatura (10 gráficas en total), y la portada añade la fila `h`.

- Si **λ_max** crece como β⁻ᵗ, alguna dirección del espacio de parámetros no
  recibe excitación (*windup* de la covarianza).
- **λ_min** dice cuánto se contrajo la dirección mejor informada.

La lectura da el IAE y el ITAE integrados hasta el instante actual y **su
cociente contra el PI integrado hasta el mismo instante**. No da el error
máximo.

Los ejes verticales arrancan en los del artículo —1440 a 1520 °R, 2200 a
2600 psia y 1 a 5 V en los mandos— **desde antes de correr**, y sólo se
ensanchan si una curva se sale. λ arranca en 0,5, el valor que usa la réplica.

Lleva «Fijar como referencia» para superponer dos configuraciones, y exporta a
PDF con `amin_informe` —una gráfica por página, más un anexo con las matrices
A₁…A_N y B₀…B_N que el controlador está usando en ese instante—.

Necesita `datos/amin_modelo.mat` (lo crea `amin_main`, pasos 4–5, o el botón
«Identificar el modelo ahora» de la propia ventana) y, para las dos
configuraciones modificadas, `datos/amin_tabla.mat` (paso 7). Si falta la
tabla, esas dos opciones desaparecen del desplegable y la barra de estado dice
por qué.

---

## 5 bis. La consola de operación (`amin_hmi`)

```matlab
>> setup_amin
>> amin_hmi
>> amin_hmi_prueba      % pruebas del motor, sin ventana
```

Una interfaz tipo sala de control. La planta corre en vivo y sus tres lazos
los controla el controlador que se elija, que se puede **cambiar en marcha**:
PI de Usoro, auto-sintonizable (fig. 6), modificado con mando cada 20 s
(fig. 7), modificado con mando cada 2 s (sin figura en el artículo) o la tabla con el estimador
apagado. Lo que `amin_sim` no permite y aquí sí:

- mover la **demanda** cuando se quiera y a la velocidad que se quiera; las dos
  rampas del artículo siguen en dos botones;
- cambiar **λ, β y la ley** (corregida o impresa) en vivo;
- **congelar o encender el estimador** a mano y **reiniciar la covarianza**;
- disparar las **emergencias V.5 a V.7** de Usoro con el auto-sintonizable en el
  lazo;
- ver el lazo como **diagrama de bloques en vivo**: consignas, demanda, tabla
  por carga (nodo activo), estimador (actualizando o congelado, ‖Δθ‖, tr P,
  λ(P)), ley (λ, cond(B₀)), mandos con su posición, el PI en reserva o
  mandando, y la planta. Las flechas marcan quién manda;
- medidores de TSSO, TRHO, PSSO, carga y MW; cuatro tendencias (también de
  cond(B₀), ‖Δθ‖, tr P y el nodo); alarmas; registro del operador; IAE e ITAE
  desde el último reinicio de índices, para comparar controladores en vivo.

**Congelación del estimador con demanda libre.** El «modified S.T.C.» apaga
el estimador desde que empieza la rampa hasta 130 s después de que termina.
Con la demanda libre se generaliza igual: se apaga en cuanto la demanda
empieza a moverse y se enciende 130 s después de que se detiene. Con las
rampas del artículo es exactamente la ventana [T0, T1 + 130 s].

**Cambio de controlador en marcha.** De PI a uno de Amin, el controlador
arranca en modo `'espera'`: manda el PI mientras se llena la historia del
regresor con datos reales (N + k periodos), y luego manda la ley. Si se elige
antes de arrancar (t = 0, estado estable), arranca como en el artículo. De
vuelta al PI, se corrigen sus integradores para que no haya salto.

**Verificación (`amin_hmi_prueba`).** Con la rampa 90 → 70 % a 10 %/min, la
consola da **exactamente** las mismas salidas que `amin_lazo` (diferencia
0,000 °R y 0,000 psia), tanto con el modificado de 20 s (y la misma
congelación en cada instante) como con el auto-sintonizable. La demanda se
evalúa como función continua del tiempo, igual que en `amin_rampa`. Con
saltos de 0,1 s la diferencia era de milésimas en el modificado, pero de
decenas de grados con el auto-sintonizable, que amplifica cualquier
diferencia. Además: el paso de PI a controlador de Amin en marcha espera y
luego manda, la vuelta al PI es sin salto, y λ y β cambian en vivo.

La ventana no se pudo probar fuera de MATLAB; el diagrama de bloques sí se
dibujó por separado para revisar su composición.

---

## 6. Qué hay en cada archivo

### La secuencia del artículo

| archivo | sección | qué hace |
|---|---|---|
| `amin_retardos.m` | IV | escalones en lazo abierto → retardo máximo → k |
| `amin_limites.m` | IV, nota 1 | la amplitud de entrada que deja las salidas por debajo del 1 % |
| `amin_espectro.m` | IV | límite superior del período de muestreo |
| `amin_datos.m` | IV | las diez corridas de 400 s al 75 %, lazo abierto |
| `amin_ident.m` | IV | RLS encadenado, elección de N por predicción |
| `amin_lambda.m` | V | barrido del λ que el artículo no publica |
| `amin_tabla.m` | V | los juegos de parámetros por nivel de carga |
| `amin_run.m` | V | las dos rampas con los cuatro controladores |
| `amin_figs.m` | V | las figuras 6, 7 y 8, y la del mando cada 2 s, que ellos no publicaron |
| `amin_main.m` | — | lo corre todo en orden |
| `amin_resumen.m` | — | el informe de texto: artículo contra réplica |
| `amin_sim.m` | — | el simulador interactivo |
| `amin_hmi.m` | — | la consola de operación con los controladores de Amin (§5 bis) |
| `amin_hmi_motor.m` | — | la simulación de la consola, sin ventana |
| `amin_hmi_prueba.m` | — | pruebas de la consola: reproduce `amin_lazo` exactamente |
| `amin_fig_ident.m` | IV | los datos de las diez corridas de identificación (entradas y salidas) |
| `amin_fig5.m` | IV | la figura 5: planta contra modelo AR con las mismas entradas, escala del artículo; opciones `'valvula'`, `'sigma'` y `'Useq'` |
| `amin_fig_windup.m` | — | la prueba 77,5 → 100 % de Usoro con y sin recorte de integradores (Fig. 2 del artículo de la reproducción) |
| `figuras_articulo.m` (raíz) | — | regenera las figuras 2, 3, 5, 6, 7 y 8 y las tablas 4 y 5 del artículo de la reproducción (§10) |
| `amin_lambda_todos.m` | V | barrido de λ y β para los cuatro controladores, con índices integrales |
| `tabla_ss.m` (raíz) | — | estados estacionarios en 8 niveles de carga (`resultados/tabla_estacionarios`) |

### Las piezas

| archivo | qué es |
|---|---|
| `amin_rls.m` | la ecuación (15), sin ninguna protección añadida |
| `amin_covarianza.m` | la P con que termina el RLS encadenado de la identificación: la P(0) del STC en línea (hueco 3) |
| `amin_modelo.m` | empaquetado de θ como (A, B) y el punto de operación |
| `amin_pred.m` | predicción a un paso y simulación libre (la figura 5) |
| `amin_stc_init.m`, `amin_stc.m` | el controlador: el algoritmo de la página 342 |
| `amin_lazo.m` | el bucle RK4 con la planta, con tabla y congelación opcionales |
| `amin_carga.m`, `amin_rampa.m`, `amin_estacionario.m` | el escenario |
| `amin_demanda.m` | la prueba de 24 h con la demanda real del SIN (§11) — **no es del artículo** |
| `amin_tabla_en.m`, `amin_stc_interp.m`, `amin_congela_mov.m` | el STC modificado en esa prueba: tabla interpolada con la carga y congelación por movimiento de la carga (§11) |
| `verifica_demanda.m` | seis comprobaciones de la prueba con demanda real |
| `amin_informe.m` | el PDF del simulador, autónomo |
| `amin_nodo.m` | la regla de conmutación de la tabla (puntos medios) |
| `verifica_amin.m` | quince comprobaciones de integridad (la 15: la P(0) heredada) |
| `amin_stc_nodo.m` | conmutación de nodo de la tabla (re-refiere la historia de `ldc`) |
| `amin_misma_huella.m` | ¿es la tabla guardada del mismo modelo? (tolerancia 1e-12) |
| `amin_sigma_ldc.m` | excitación de `ldc` para identificar el 3×4 — **no es del artículo** |
| `verifica_ldc.m` | siete comprobaciones del bloque D del 3×4 sobre un ARX sintético |
| `amin_sufijo.m` | sufijo de archivo de cada variante: `_ldc`, `_k2`, `_ldc_k2` |
| `verifica_k.m` | cuatro comprobaciones del retardo k = 2 sobre un ARX sintético con retardo de dos periodos |
| `planta/` | copia del modelo de 47 estados de Usoro: solo lo que la réplica usa (`digpte47`, `pte47_params`, `pte47_case`, `pte47_clamp`, `const1..3` y `funciones/`). Las pruebas de Usoro (`pte47_run`, `pte47_test`, `pte47_steptest`, `pte47_plot`, `pba1..4_rk4`) viven en `1-planta/` |

### Dependencias

Ninguna fuera de esta carpeta, y ninguna *toolbox*. Corre en MATLAB y en
Octave. La copia de la planta en `planta/` es byte a byte la de `1-planta/` del
repositorio, y `verifica_amin` lo comprueba cuando encuentra el repositorio al
lado: si alguna vez divergen, la primera prueba lo dice.

---

## 7. Lo que esta carpeta deliberadamente NO hace

- **No usa el criterio de esta tesis.** No hay peor caso sobre V.1–V.4. La
  lectura del simulador da IAE e ITAE y su cociente contra el PI de la misma
  prueba, como índices para comparar, no como criterio de diseño.
- **No añade la entrada exógena `ldc` por omisión.** La réplica es 3×3, como
  la suya. El 3×4 existe sólo como opción (§8), marcado como «no es del
  artículo», y no cambia ni un dígito del 3×3.
- **No añade protecciones al estimador.** Ni zona muerta, ni cota de traza, ni
  límite del paso de θ, ni proyección de B₀. El artículo no las tiene, y su
  ausencia forma parte de lo que se está replicando.
- **No corrige el diseño.** Si algo sale peor que en el artículo, sale peor y
  se reporta. El encargo era reproducir el trabajo, no mejorarlo.

---

## 8. Extensión: modelo 3×4 con `ldc` — NO es del artículo

### Uso

```matlab
>> cd 7-replica-amin/archivos
>> setup_amin
>> amin_sim                          % desplegable «Modelo ARX»: 3x3 o 3x4
>> OUT = amin_main('modelo','3x4')   % la réplica completa con el 3x4 (por lotes)
>> verifica_ldc                      % 7 comprobaciones del bloque D
```

Los modelos y las tablas por carga de los dos casos ya vienen en `datos/`:
no hay que volver a identificar.

### Modelo 3x4 (NO es del artículo)

    A(q⁻¹) y(t) = B(q⁻¹) u(t−k) + D(q⁻¹) ldc(t−k) + e(t)

* La demanda ldc se mide, pero el controlador no la manipula: entra como
  **prealimentación**. El término D(q⁻¹)·ldc pasa al corchete de la ley como
  un dato conocido más. El criterio, λ, β y el estimador no cambian.
* θ = [B₀…B_N, −A₁…−A_N, D₀…D_N]: **39 parámetros por fila** (33 en el 3x3).
  El bloque D va al final, así que los índices del 3x3 no cambian.
* Identificación: 10 corridas de 400 s al 75 %, en lazo abierto, con la
  ldc también excitada, σ = 0,03 V. **Errata:** el `amin_datos_75_ldc.mat`
  de esta carpeta se generó en Octave y el 3x3 en MATLAB; como los dos
  generadores dan secuencias distintas con la misma semilla, **los mandos
  de los dos juegos NO son los mismos**. `amin_datos` ya lee los mandos del
  3x3 guardado para que esto no vuelva a pasar, pero los datos y modelos 3x4
  guardados son los anteriores; toda comparación 3x3 contra 3x4 mezcla la
  ldc con otra realización de las entradas. Ese valor sale del
  mismo criterio del 1 % del artículo (`amin_sigma_ldc`). D₀ sale casi igual
  con 0,01, 0,03 y 0,15 V (PSSO: −212, −230 y −219 psia/V).
* Cada modelo tiene su tabla por carga: `amin_tabla.mat` y `amin_tabla_ldc.mat`.
* Al conmutar de nodo, la historia de ldc se re-refiere al ldc_ss del nodo
  nuevo (`amin_stc_nodo`). Sin esto, cada conmutación mete un escalón
  ficticio de 0,25 V en D(q⁻¹)·ldc. En el 3x3 no cambia nada.

### Pestaña «Covarianza P»

Traza de P, λ_max(P) y λ_min(P) en escala logarítmica, con la línea de
tr P(0) = P₀·npar. El estimador usa una sola P para las tres filas
(33×33 o 39×39).

* **tr P**: la incertidumbre total de los parámetros.
* **λ_max**: si crece como β⁻ᵗ, alguna dirección no recibe excitación
  (*windup* de la covarianza).
* **λ_min**: cuánto se contrajo la dirección mejor informada.

La lectura también muestra tr P y el rango de λ(P). Si fijas una corrida
como referencia, su traza de P se dibuja en verde.

### Otros cambios en el simulador

* La lectura ya no muestra e_max. Muestra **IAE e ITAE, y su cociente
  contra el PI integrado hasta el mismo instante**. La comparación contra la
  referencia fijada también usa el IAE.
* Los parámetros del PDF incluyen P(0) y la estructura del modelo. El
  nombre del PDF lleva `_m34` cuando el modelo es 3x4.

### Resultados (λ = 0,5, β = 0,99, P(0) = 100·I, N = 5, k = 1, T = 20 s, 800 s)

IAE / IAE del PI:

| Controlador | Modelo | 90→70 % TSSO | TRHO | PSSO | 70→90 % TSSO | TRHO | PSSO |
|---|---|---|---|---|---|---|---|
| auto-sintonizable | 3x3 | 4,32 | 1,58 | 38,0 | 6,99 | 3,22 | 69,0 |
| | 3x4 | 7,71 | 2,15 | 105 | 6,03 | 8,72 | 227 |
| modificado (Tc 20 s) | 3x3 | 0,26 | 0,13 | 1,61 | 0,61 | 0,30 | 7,56 |
| | 3x4 | 0,50 | 0,18 | 4,13 | 1,61 | 0,63 | 15,9 |
| modificado (Tc 2 s) | 3x3 | 0,65 | 0,21 | 3,95 | 0,55 | 0,30 | 6,67 |
| | 3x4 | 0,37 | 0,15 | 2,78 | 0,39 | 0,37 | 5,48 |
| tabla, estimador apagado | 3x3 | 0,26 | 0,14 | 1,68 | 0,45 | 0,28 | 6,33 |
| | 3x4 | 0,47 | 0,18 | 3,46 | 0,45 | 0,40 | 7,29 |

**Esta comparación no es justa para el 3x4**: λ = 0,5 se calibró para el 3x3.
En un barrido corto con la tabla y el estimador apagado, la media de los
seis cocientes fue:

| λ | 0,5 | 1 | 2 | 5 |
|---|---|---|---|---|
| 3x3 | 1,52 | **1,35** | 1,41 | 1,96 |
| 3x4 | 2,04 | 1,47 | **1,15** | 1,47 |

Con su propia λ, el 3x4 queda mejor que el 3x3 (1,15 contra 1,35), sobre
todo en la presión de la prueba 70→90 %: 1,71 contra 4,75 veces el PI. Antes
de concluir nada hay que recalibrar λ y β para el 3x4 con
`amin_lambda_todos`, que guarda su barrido en otro archivo.

### Verificación

* **3x3 sin cambios**: el auto-sintonizable y el modificado dan resultados
  idénticos a los de antes, dígito a dígito (diferencia 0 en y, u e IAE).
* `verifica_ldc` pasa las 7 comprobaciones con un ARX 3x4 sintético:
  identificación exacta, predicción, ley con prealimentación exacta,
  convergencia del RLS en línea y re-referencia al conmutar de nodo.
* La lógica del simulador (sin la ventana) da lo mismo que `amin_run` en el
  3x4 (diferencia 0).
* **No se ha probado aquí**:
  * la ventana en sí (uifigure, pestañas y leyendas), porque se probó en
    Octave, que no tiene uifigure. Ábrela una vez en MATLAB para confirmarla;
  * `amin_main('modelo','3x4')` de principio a fin. Sus piezas sí se
    corrieron una por una.

---

## 9. El retardo k: cómo se mide y la opción k = 2

### Cómo se mide el retardo (sección IV, `amin_retardos`)

1. Se parte del estado estable al 75 %, con los tres PI abiertos y sus integradores congelados.
2. Se da un escalón a **una** entrada y las otras dos se dejan en su valor de estado estable: CBMD +0,1 V, CXGG +0,3 V, CWSY +0,6 V (las amplitudes de fluctuación del artículo).
3. Se simulan 200 s con paso de 0,1 s.
4. En cada salida, el retardo es el **primer instante en que |y − y_ss| supera el 2 % de su excursión máxima** en esos 200 s. El artículo no dice qué criterio usó; éste se declara (hueco 5).
5. Regla del artículo: k = el entero igual o inmediatamente mayor que τ_max / T.

Retardos en s con tres umbrales:

| escalón | → TSSO (1 / 2 / 5 %) | → TRHO | → PSSO |
|---|---|---|---|
| CBMD +0,1 V | 8,2 / 12,3 / 22,6 | 5,6 / 8,4 / 16,2 | 17,3 / 24,4 / 40,8 |
| CXGG +0,3 V | **28,2 / 34,6 / 48,9** | 7,7 / 12,6 / 25,1 | 14,9 / 21,6 / 37,4 |
| CWSY +0,6 V | 5,2 / 7,1 / 11,2 | 10,5 / 15,6 / 25,4 | 3,0 / 4,7 / 10,2 |

- El mayor es siempre **CXGG → TSSO**. Con T = 20 s da k = 2 con el umbral del 1 % o del 2 %, y k = 3 con el del 5 %.
- Ese par tiene **respuesta inversa**. TSSO sube unas centésimas (+0,04 °R a los 10 s), cruza el cero hacia los 20 s y luego baja hasta −6,3 °R a los 200 s. Lo que se mide como «retardo» es sobre todo esa zona casi plana, no un tiempo muerto de transporte: la salida se mueve desde el primer segundo.
- Amin reporta 20 s entre CWSY y TRHO y usa k = 1. Aquí ese par da 15,6 s, del mismo orden.

### Cómo se mide el límite del periodo de muestreo (`amin_espectro`)

1. Tres corridas de 400 s en lazo abierto al 75 %, con las entradas aleatorias de la identificación (retenidas 20 s).
2. Las salidas se guardan cada 1 s.
3. A cada salida se le quita la media, se le aplica una ventana de Hann y se promedia el periodograma de las tres corridas.
4. f_max es la frecuencia por debajo de la cual queda el 99 % de la potencia, y **T_max = 1/(2 f_max)** (teorema de muestreo).
5. El límite es el menor de las tres salidas: **28,6 s** (Amin: 75 s). T = 20 s cumple en los dos casos.

Límites de este método:

- El umbral del 99 % es una elección.
- La excitación ya viene retenida a 20 s, así que el propio experimento limita el ancho de banda.

### La opción k = 2

**Forma predictora (la del algoritmo de la p. 342).** Con retardo k se identifica directamente el predictor a k pasos:

    y(t) = θ x(t−k),   x(t−k) = [u(t−k) … u(t−k−N); y(t−k) … y(t−k−N+1); ldc(t−k) …]

- Con k = 1 es el ARX (16) de siempre.
- Con k = 2, los bloques de θ ya no son A y B de (16) sino G y F·B del predictor. La Diofantina I = A F + q⁻ᵏ G queda resuelta dentro de la estimación.
- La ley (12) no cambia: θ·x(t) es y*(t+k|t) y se iguala a w.

**Cambios en el código:**

- El regresor de `amin_ident`, `amin_pred` y `amin_stc`.
- El largo de las historias en `amin_stc_init`.
- La opción `'k'` de `amin_ident`.
- El desplegable «Retardo k» del simulador.

**Archivos y verificación:**

- Los modelos y tablas de k = 2 llevan sufijo `_k2`.
- Con k = 1 todo da resultados idénticos a los de antes (diferencia 0 en y, u e IAE, en 3×3 y en 3×4).
- `verifica_k` comprueba sobre una planta sintética con retardo de dos periodos que la identificación recupera el predictor exacto y que la ley deja y(t+2) = w(t).
- También comprueba que el estimador en línea está alineado, y que con el modelo de k = 1 esa misma planta se va.

**Identificación con k = 2 (mismos datos, N = 5).** El ajuste a dos pasos fuera de muestra es ≈ 51 % (3×3) y ≈ 50 % (3×4). Con k = 1, el ajuste a un paso es ≈ 90 %. Predecir 40 s adelante es más difícil que predecir 20 s, y es lo que la ley tiene que hacer.

**Ceros del polinomio B.** Es lo que decide si la ley de varianza mínima es estable. Tabla: módulo del mayor cero y ceros fuera del círculo unitario.

| modelo | k = 1 | k = 2 |
|---|---|---|
| 3×3 | 1,000 · 1 de 15 | **1,280 · 6 de 15** |
| 3×4 | 0,978 · 0 de 15 | **1,201 · 3 de 15** |

Con k = 2 el predictor es de **fase no mínima**. Una ley de varianza mínima con λ pequeña cancela esos ceros y el mando se vuelve inestable. Para eso sirve el peso λ del criterio generalizado, así que **λ = 0,5, calibrado para k = 1, no tiene por qué servir con k = 2**.

### Resultados con k = 2 (λ = 0,5, β = 0,99, P(0) = 100·I, N = 5, 800 s)

IAE / IAE del PI, **con la misma sintonía que k = 1**:

| controlador | modelo | k | 90→70 % TSSO | TRHO | PSSO | 70→90 % TSSO | TRHO | PSSO |
|---|---|---|---|---|---|---|---|---|
| auto-sintonizable | 3×3 | 1 | 4,32 | 1,58 | 38,0 | 6,99 | 3,22 | 69,0 |
| | 3×3 | 2 | 34,4 | 11,6 | 578 | 8,75 | 6,05 | 206 |
| | 3×4 | 1 | 7,71 | 2,15 | 105 | 6,03 | 8,72 | 227 |
| | 3×4 | 2 | 39,6 | 17,9 | 200 ¹ | 30,7 | 14,9 | 265 |
| modificado (Tc 20 s) | 3×3 | 1 | 0,26 | 0,13 | 1,61 | 0,61 | 0,30 | 7,56 |
| | 3×3 | 2 | 30,5 | 8,64 | 366 | 30,8 | 8,51 | 369 |
| | 3×4 | 1 | 0,50 | 0,18 | 4,13 | 1,61 | 0,63 | 15,9 |
| | 3×4 | 2 | 4,78 | 0,93 | 42,3 | 2,13 | 0,67 | 21,8 |
| tabla, estimador apagado | 3×3 | 1 | 0,26 | 0,14 | 1,68 | 0,45 | 0,28 | 6,33 |
| | 3×3 | 2 | 35,1 | 9,64 | 418 | 80,2 | 22,7 | 459 |
| | 3×4 | 1 | 0,47 | 0,18 | 3,46 | 0,45 | 0,40 | 7,29 |
| | 3×4 | 2 | 1,71 | 0,31 | 3,96 | 1,31 | 0,31 | 9,52 |

¹ La corrida se corta a los 686 s porque el estado sale del rango físico.

- **Con λ = 0,5, k = 2 empeora en todas las configuraciones.**
- La tabla por carga del 3×3 con k = 2 ya sale mal. Al construirla, los nodos de 70, 75 y 90 % se desestabilizan en carga constante: e_max de 350 °R y 1800 psia a 70 %, y 90 % se corta a las 76 actualizaciones.
- La del 3×4 con k = 2 se construye bien, con e_max ≈ 0 en los cinco nodos.
- Es lo que anticipan los ceros de fase no mínima de la tabla anterior.
- **Antes de comparar k = 1 con k = 2 hay que recalibrar λ (y β) para k = 2.** Con la sintonía de k = 1 la comparación mide la sintonía, no el retardo. `amin_lambda_todos` guarda ese barrido en `resultados/amin_lambda_todos_k2.mat` y `…_ldc_k2.mat`.

### Recalibración de λ para k = 2 (β = 0,99)

Para cada λ se reconstruye la tabla por carga y se corren las dos pruebas (`amin_lambda_todos`, archivos `resultados/amin_lambda_todos_k2.mat` y `…_ldc_k2.mat`).

Cada celda es J = media de los seis cocientes IAE / IAE del PI (tres salidas × dos pruebas). Un asterisco (\*) marca que alguna corrida se cortó por estado no físico.

| controlador | modelo | λ = 0,5 | 1 | 2 | 5 | 10 | 20 | 50 | **k = 1, λ = 0,5** |
|---|---|---|---|---|---|---|---|---|---|
| auto-sintonizable | 3×3 | 141 | 127\* | 147 | 154 | 166 | 134 | 130 | **20,5** |
| | 3×4 | 94,6\* | 99,1 | 109\* | 55,8 | 87,4\* | 67,0 | 116 | **59,5** |
| modificado 20 s | 3×3 | 136 | 96,6 | 98,8 | 170 | 88,2 | 56,5\* | 133 | **1,75** |
| | 3×4 | 12,1 | 8,60 | 19,9 | 12,9 | 21,8 | 21,5 | 11,3 | **3,82** |
| modificado 2 s | 3×3 | 200 | 162 | 70,7\* | 45,4\* | 117 | 45,2 | 103 | **2,06** |
| | 3×4 | 15,8 | 16,9 | 18,5 | 23,3 | 22,3 | 15,6 | 10,8 | **1,59** |
| tabla, estim. apagado | 3×3 | 171 | 103\* | 42,9\* | 47,6\* | 105 | 26,5 | 47,9\* | **1,52** |
| | 3×4 | 2,85 | 2,52 | 2,17 | 1,94 | 1,82 | 1,64 | 1,64 | **2,04** |

La columna λ = 0,5 sale de las corridas con la tabla construida a λ = 0,5 (§ anterior).

- **Con ninguna λ, k = 2 alcanza a k = 1** en el 3×3. El mejor k = 2 de cada controlador queda entre 6 y 50 veces por encima.
- La superficie no es suave: J salta de un λ al siguiente, y varios pares se cortan. Es la firma de un lazo que vive saturado o al borde de la inestabilidad, no la de una sintonía fina.
- La única configuración de k = 2 que se acerca es la tabla con el estimador apagado del 3×4: J = 1,64 con λ = 20–50. Con k = 1, esa misma configuración da 2,04 con λ = 0,5 y 1,15 con λ = 2 (barrido corto, §8).
- β no se barrió; en k = 1 no discriminaba.

**Conclusión.** Tratar los 34,6 s como un retardo de dos periodos empeora el controlador:

- El predictor a 40 s ajusta mucho peor (≈ 51 % contra ≈ 90 %).
- Sale de fase no mínima.
- El «retardo» medido es sobre todo la respuesta inversa y lenta de CXGG → TSSO, no un tiempo muerto.

El k = 1 de Amin es la elección correcta para esta planta con T = 20 s.

---

## 10. Las figuras del artículo de la reproducción (`figuras_articulo`)

```matlab
>> cd 7-replica-amin/archivos
>> A = figuras_articulo;                    % todo, con lo que ya haya calculado
>> A = figuras_articulo('rehacer',true);    % desde cero
>> A = figuras_articulo('solo','figuras');  % solo redibuja
```

Deja en `resultados/articulo/` las figuras en PDF y PNG con el número del
artículo (`fig2_windup`, `fig3_entradas`, `fig5_fig5`, `fig6_stc`,
`fig7_salidas`, `fig8_mandos`) y `cifras_articulo.txt` con todas las cifras que
cita el texto: las tablas 4 y 5, la deriva de las corridas, los polos y la
separación del modelo de la figura 5, la saturación de los mandos, el STC con el
modelo de válvula fija y con el modelo congelado.

| bloque | qué corre | archivo |
|---|---|---|
| 1 | prueba 77,5 → 100 % con y sin recorte (2 × 700 s) | `windup.mat` |
| 2 | diez corridas con la válvula fija e identificación (10 × 400 s) | `valvula.mat` |
| 3 | figura 5: lazo activo, válvula fija y seis realizaciones más (8 × 1400 s) | `fig5.mat` |
| 4 | `amin_run` con λ = 0,5, β = 0,99 y P(0) heredada (10 × 800 s) | `run.mat` |
| 5 | STC con P(0) = 10²·I y = I, con el modelo de válvula fija y con el modelo congelado (8 × 800 s) | `extra.mat` |

Cada bloque se guarda en cuanto termina; si se interrumpe, al volver a correrlo
sigue donde se quedó. Las seis realizaciones extra de la figura 5 se leen de
`datos/amin_fig5_realizaciones.mat`, y la principal de
`datos/amin_fig5_entradas.mat`: así salen iguales en MATLAB y en Octave (con la
misma semilla, los dos generan secuencias distintas).

La figura 1 (esquema de la planta) es del libro de Quintero-Mármol (2025) y la
figura 4 es una captura de `amin_sim`: no se generan aquí.

**En el simulador.** `amin_sim` no tiene una pestaña aparte para estas
figuras: su pestaña «Resumen» ya se dibuja con la disposición y los colores de
las figuras 6 a 8, con la corrida que se esté simulando.

---

## 11. Prueba con demanda real del SIN — NO es del artículo

Idea del tutor: en vez de una rampa constante, una prueba con la demanda de
un día real. Se agregó al simulador (`amin_sim`, selector «Prueba») y a
`amin_lazo`; los mismos perfiles están en los simuladores web.

**Datos.** CENACE, «Estimación de la Demanda Real del Sistema por Balance»:
demanda horaria del Sistema Interconectado Nacional del 7/10/2025 al 7/10/2026
(liquidación más reciente de cada día). De cada día se toma una ventana de
24 h desde la hora de menor demanda, se interpola cada minuto (PCHIP) y se
escala para que el mínimo corresponda al 70 % y el máximo al 90 % (el rango de
los estacionarios y de la tabla). Si la carga baja del valle inicial se
recorta en 70 % (mínimo técnico). Los perfiles, 1441 valores por día, están
en `datos/demanda_sin.mat`.

| clave | día | desde | escala |
|---|---|---|---|
| `d1` | jueves 20/08/2026, pico de demanda del año | 6:00 | 41 133 → 52 202 MW |
| `d2` | miércoles 11/03/2026 | 4:00 | 34 378 → 44 228 MW |
| `d3` | domingo 18/01/2026 | 5:00 | 28 486 → 35 226 MW |

La corrida va **en tiempo real** (24 h; también 12 o 6 h) desde el
estacionario al 70 %. La carga cambia a lo sumo 0,11 %/min, unas 100 veces más
despacio que la rampa del artículo.

```matlab
>> [P, info] = amin_demanda('d1');            % 24 h
>> R = amin_lazo([], P, 'guardaX',false);      % PI de Usoro
```

**El STC modificado en esta prueba.** Tal como lo describe la sección V no
sirve con carga lenta: cada conmutación de nodo hace saltar el punto de
operación (CBMD, unos 0,15 V) y da golpes de unos 40 psia que saturan los
mandos (ocho en el día pico). Por eso, solo en esta prueba:

- **tabla interpolada** (`amin_tabla_en`, `amin_stc_interp`): θ, u_ss e y_ss
  se interpolan linealmente con la carga entre los dos nodos vecinos, y la
  historia en desviaciones se re-refiere en cada instante;
- **congelación por movimiento** (`amin_congela_mov`): el estimador se apaga
  si la carga cambió más de 1 %/min desde el instante anterior y sigue
  apagado 130 s después. Congela con rampas como la del artículo, pero no con
  la demanda de un día real. Con un umbral de 0,02 %/min el estimador queda
  congelado casi todo el día y la presión se atrasa 3–4 psia siguiendo la
  rampa, porque la ley no tiene acción integral.

```matlab
>> s = load('datos/amin_tabla.mat');  TB = s.TB;
>> S = amin_stc_init(TB.M(1), 'lambda',0.5, 'beta',0.99, 'adapt',false, 'Tc',20);
>> R = amin_lazo(S, P, 'tabla',TB, 'interp',true, 'umbral',info.umbral, 'guardaX',false);
```

Las pruebas del artículo no cambian: sin estas opciones `amin_lazo` y
`amin_sim` hacen exactamente lo de antes.

**Tiempo de cómputo.** 24 h son 864 000 pasos de RK4. En MATLAB tardan varios
minutos (y la línea base del PI otro tanto, la primera vez); en Octave, horas.

**Resultados (24 h, λ = 0,5, β = 0,99; error máximo TSSO °R / TRHO °R / PSSO psia).**

| día | PI de Usoro | STC | STC modificado |
|---|---|---|---|
| 20/08 | 0,81 / 1,24 / 1,29 | 0,44 / 0,32 / 2,85 | 0,30 / 0,20 / 3,05 |
| 11/03 | 0,87 / 1,30 / 1,32 | 0,54 / 0,31 / 5,98 | 0,19 / 0,22 / 1,13 |
| 18/01 | 0,87 / 1,31 / 1,31 | 2,05 / 1,46 / 20,85 | 0,89 / 0,55 / 9,20 |

- Con los controladores adaptables, perturbaciones mínimas (el redondeo de
  la última cifra) cambian estas cifras en un 10–30 %: el estimador amplifica
  cualquier diferencia. La imagen cualitativa no cambia: el modificado es el
  mejor en temperaturas; en presión, el PI sigue siendo mejor (IAE del
  modificado 1,4–1,6 veces el del PI).
- El domingo, tras unas 9 h de carga casi plana, el STC se desestabiliza al
  subir la carga (*bursting*): la falta de excitación con β = 0,99 infla la
  covarianza. El modificado lo reduce a la mitad, sin eliminarlo.
- Los picos periódicos del PI vienen de la recirculación de gases, que solo
  integra cuando la inclinación de quemadores pasa de ±5° (`knp087`): con
  carga lenta se activa unos segundos cada ~1 % de carga. Es lógica original
  de Usoro.

