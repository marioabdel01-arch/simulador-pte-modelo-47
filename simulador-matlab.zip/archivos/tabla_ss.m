% TABLA_SS  Estados estacionarios de la planta en 8 niveles de carga.
%   50, 77,5 y 100 %: tabulados por Usoro (pte47_case).  70-90 %: los de
%   amin_estacionario (datos/amin_ss_*.mat).  Ademas re-asienta 3000 s los
%   tres puntos de Usoro con el mismo procedimiento, como verificacion.
%   Guarda resultados/tabla_estacionarios.mat (la hoja de calculo
%   resultados/tabla_estacionarios.xlsx se arma a partir de ese archivo).
setup_amin;
niv = [50 70 75 77.5 80 85 90 100];
cas = {'50','','', '775','','','','100'};
X = nan(47,numel(niv)); Y = nan(3,numel(niv)); U = nan(3,numel(niv)); L = nan(1,numel(niv));
XD = nan(1,numel(niv)); fuente = cell(1,numel(niv));
for i = 1:numel(niv)
  if ~isempty(cas{i})
    C = pte47_case(cas{i});
    P = amin_planta(cas{i}); P.x0 = C.x0; P.ldc = C.ldc;
    P.ldcStart = C.ldc; P.ldcRate = 0; P.ldcT0 = 0; P.ldcT1 = 0;
    [xd, yl] = digpte47(0, C.x0(:), P);
    X(:,i) = C.x0(:); Y(:,i) = yl(26:28).'; U(:,i) = yl(29:31).'; L(i) = C.ldc;
    XD(i) = norm(xd); fuente{i} = 'Usoro (tabulado)';
  else
    q = load(sprintf('datos/amin_ss_%d.mat', niv(i))); S = q.S;
    X(:,i) = S.x0(:); Y(:,i) = S.y(:); U(:,i) = S.u(:); L(i) = S.ldc; XD(i) = S.xdot;
    fuente{i} = 'replica (calculado)';
  end
end
% verificacion del procedimiento: asentar los tres puntos de Usoro 3000 s
V = nan(47,3); VY = nan(3,3); VU = nan(3,3); VXD = nan(1,3);
pv = [50 77.5 100];
for j = 1:3
  S = amin_estacionario(pv(j), 'cache',false, 'verbose',false);
  V(:,j) = S.x0(:); VY(:,j) = S.y(:); VU(:,j) = S.u(:); VXD(j) = S.xdot;
end
save('-v7','resultados/tabla_estacionarios.mat','niv','X','Y','U','L','XD','fuente','V','VY','VU','VXD','pv');
disp(XD); disp(VXD);
