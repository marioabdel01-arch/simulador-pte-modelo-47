function setup_amin()
%SETUP_AMIN  Pone en la ruta la replica de Amin et al. (1984).
%
%   Ejecutar UNA VEZ, DESDE ESTA CARPETA:
%
%       >> setup_amin
%       >> OUT = amin_main
%
%   ESTA CARPETA ES AUTONOMA.  No necesita el resto del repositorio: lleva su
%   propia copia del modelo de planta de 47 estados en `planta/`, de modo que
%   se puede comprimir y entregar sola.  El precio de esa autonomia es que
%   hay dos copias del modelo que podrian separarse con el tiempo, y por eso
%   VERIFICA_AMIN compara byte a byte contra la del repositorio cuando la
%   encuentra al lado.
%
%   ESTRUCTURA
%     planta/codigo     digpte47, pte47_params, pte47_case, pte47_clamp,
%                       const1..3 (solo lo que la replica usa: las pruebas
%                       de Usoro ---pte47_run, pte47_test, pba*_rk4...--- se
%                       quedan en 1-planta)
%     planta/funciones  las 34 rutinas del modelo (drum, shstat, limchk, ...)
%     codigo/           la replica: identificacion, controlador, pruebas
%     datos/            estacionarios y corridas de identificacion (cache)
%     resultados/       figuras e informe
%
%   IMPORTANTE: el codigo lee y escribe con rutas relativas (`datos/...`,
%   `resultados/...`), asi que hay que correr DESDE ESTA CARPETA.

here = fileparts(mfilename('fullpath'));
if isempty(here), here = pwd; end

% Si esta carpeta viene del repositorio sin la copia de la planta, se
% rellena desde 1-planta.  La carpeta comprimida que se entrega al tutor ya
% la lleva dentro y esto no hace nada.
rellena_planta_(here);

d = {fullfile(here,'planta','codigo'), ...
     fullfile(here,'planta','funciones'), ...
     fullfile(here,'codigo')};

for i = 1:numel(d)
    if exist(d{i},'dir') ~= 7
        error('setup_amin:falta', 'No encuentro la carpeta %s', d{i});
    end
    addpath(d{i});
end

for c = {'datos','resultados'}
    if exist(fullfile(here,c{1}),'dir') ~= 7, mkdir(fullfile(here,c{1})); end
end

if ~strcmp(pwd, here)
    fprintf('OJO: el directorio de trabajo no es esta carpeta.\n');
    fprintf('     cd(''%s'')\n', here);
end

fprintf('Replica de Amin et al. (1984) lista.\n');
fprintf('  >> OUT = amin_main            la replica completa\n');
fprintf('  >> OUT = amin_main(''rapido'',true)   version corta de comprobacion\n');
fprintf('  >> verifica_amin              comprobaciones de integridad\n');
fprintf('  >> verifica_ldc, verifica_k   las del modelo 3x4 y del retardo k = 2\n');
fprintf('  >> amin_sim                   el simulador interactivo\n');
fprintf('  >> amin_hmi                   la consola de operación (tipo HMI)\n');
fprintf('  >> figuras_articulo           las figuras y cifras del artículo de la reproducción\n');
end

% =========================================================================
function rellena_planta_(here)
%RELLENA_PLANTA_  Copia el modelo de 47 estados desde 1-planta si falta.
%   La carpeta se entrega con su propia copia; esto solo actua cuando se
%   trabaja dentro del repositorio y la copia todavia no se ha hecho.
%   Copia SOLO lo que la replica usa: de planta/codigo, el modelo y sus
%   parametros; de planta/funciones, todo (lo llama digpte47).  Las pruebas
%   de Usoro de 1-planta no hacen falta aqui.
src = fullfile(here, '..', '1-planta');
if exist(src,'dir') ~= 7, return, end
usa = {'digpte47.m','pte47_params.m','pte47_case.m','pte47_clamp.m', ...
       'const1.m','const2.m','const3.m'};
n = 0;
for c = {'codigo','funciones'}
    dst = fullfile(here, 'planta', c{1});
    if exist(dst,'dir') ~= 7, mkdir(dst); end
    A = dir(fullfile(src, c{1}, '*.m'));
    for i = 1:numel(A)
        if strcmp(c{1},'codigo') && ~any(strcmp(A(i).name, usa)), continue, end
        b = fullfile(dst, A(i).name);
        if exist(b,'file') ~= 2
            copyfile(fullfile(src, c{1}, A(i).name), b);
            n = n + 1;
        end
    end
end
if n > 0
    fprintf('Copiados %d archivos del modelo de planta desde 1-planta/.\n', n);
end
end
