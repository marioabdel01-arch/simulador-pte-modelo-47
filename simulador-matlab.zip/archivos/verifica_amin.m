function ok = verifica_amin(varargin)
%VERIFICA_AMIN  Comprobaciones de integridad de la replica.
%
%   ok = VERIFICA_AMIN
%
%   No corre la replica: comprueba que las piezas son las que dicen ser.
%   Catorce pruebas, todas baratas:
%
%     1. la copia de la planta coincide con la del repositorio, si esta al lado
%     2. el modelo de planta arranca y devuelve las 38 columnas esperadas
%     3. el punto de operacion al 77,5 % es el tabulado por Usoro
%     4. la conversion carga <-> ldc es la del transductor lineal
%     5. la velocidad de rampa del articulo son 10 %/min
%     6. el tamano del regresor es (N+1)*nu + N*ny = 33 con N = 5
%     7. el estimador (15) reproduce minimos cuadrados por lotes con beta = 1
%     8. la ley de control devuelve la consigna exacta cuando el modelo es
%        exacto y lambda = 0
%     9. la ley TAL COMO ESTA IMPRESA no lo consigue (la errata de signo)
%    10. el modelo empaquetado y el desempaquetado son consistentes
%    11. nada de lo cacheado en datos/ es complejo ni infinito
%    12. durante el calentamiento manda el PI de Usoro de verdad
%    13. solo actua la inclinacion de quemadores (seccion II)
%    15. la P(0) del STC en linea es, por omision, la covarianza con que
%        termina el RLS encadenado de la identificacion (AMIN_COVARIANZA)
%    14. con el mando cada 2 s la ley usa muestras separadas 20 s: con el
%        modelo exacto y lambda = 0 coloca TODAS las salidas en la consigna
%
%   Las extensiones que NO son del articulo tienen las suyas: VERIFICA_LDC
%   (modelo 3x4) y VERIFICA_K (retardo k = 2).
%
%   La 7 y la 8 son las que de verdad importan: son las unicas que verifican
%   que las ecuaciones (15) y (12) estan bien escritas, y no dependen de la
%   planta ni de ningun dato.
%
%   See also SETUP_AMIN, AMIN_MAIN.

n = 0;  mal = 0;
fprintf('\nVERIFICA_AMIN\n%s\n', repmat('=',1,60));

% --- 1 -------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'copia de la planta identica al repositorio', @() copia_());

% --- 2 -------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'el modelo de planta arranca', @() ...
    arranque_());

% --- 3 -------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'punto de operacion al 77,5 % de Usoro', @() ...
    operacion_());

% --- 4 -------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'conversion carga <-> ldc', @() ...
    abs(amin_carga(100) - 5) < 1e-12 && abs(amin_carga(77.5) - 3.875) < 1e-12 ...
    && abs(amin_carga(50) - 2.5) < 1e-12 && abs(amin_carga(75) - 3.75) < 1e-12);

% --- 5 -------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'rampa de 10 %/min = 1/120 V/s', @() ...
    abs((amin_carga(90) - amin_carga(70))/120*60/0.05 - 10) < 1e-9);

% --- 6 -------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'npar = 33 con N = 5, nu = ny = 3', @() ...
    regresor_());

% --- 7 -------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'el RLS (15) reproduce minimos cuadrados', @() ...
    rls_());

% --- 8 -------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'la ley (12) con lambda = 0 lleva a la consigna', @() ...
    ley_());

% --- 9 -------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'la ley IMPRESA no lleva a la consigna (errata)', @() ...
    ~ley_(true));

% --- 10 ------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'empaquetado y desempaquetado del modelo', @() ...
    paquete_());

% --- 11 ------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'lo guardado en datos/ es real y finito', @() ...
    cache_());

% --- 12 ------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'durante el calentamiento manda el PI de verdad', @() ...
    calentamiento_());

% --- 13 ------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'solo actua la inclinacion de quemadores (sec. II)', @() ...
    soloTilt_());

% --- 14 ------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'mando cada 2 s: muestras a 20 s (ley exacta)', @() ...
    lag_());

% --- 15 ------------------------------------------------------------------
[n, mal] = chk_(n, mal, 'P(0) en linea = covarianza final de la identificacion', @() ...
    pheredada_());

fprintf('%s\n%d de %d bien, %d mal.\n\n', repmat('=',1,60), n-mal, n, mal);
ok = (mal == 0);
end

% =========================================================================
function [n, mal] = chk_(n, mal, nombre, f)
n = n + 1;
try
    r = f();
catch e
    r = false;
    fprintf('  %-52s FALLO\n      %s\n', nombre, e.message);
    mal = mal + 1;
    return
end
if r
    fprintf('  %-52s ok\n', nombre);
else
    fprintf('  %-52s MAL\n', nombre);
    mal = mal + 1;
end
end

% =========================================================================
function r = copia_()
here = fileparts(mfilename('fullpath'));
repo = fullfile(here, '..', '1-planta');
if exist(repo,'dir') ~= 7
    fprintf('      (no hay repositorio al lado: no se compara)\n');
    r = true;  return
end
r = true;
for c = {'codigo','funciones'}
    A = dir(fullfile(here,'planta',c{1},'*.m'));
    for i = 1:numel(A)
        a = fullfile(here,'planta',c{1},A(i).name);
        b = fullfile(repo,c{1},A(i).name);
        if exist(b,'file') ~= 2
            fprintf('      %s no esta en el repositorio\n', A(i).name);
            r = false;  continue
        end
        if ~isequal(leer_(a), leer_(b))
            fprintf('      %s DIFIERE de la del repositorio\n', A(i).name);
            r = false;
        end
    end
end
end

function s = leer_(a)
fid = fopen(a,'r');  s = fread(fid, inf, 'uint8=>uint8');  fclose(fid);
end

% =========================================================================
function r = arranque_()
P = pte47_params('775','samples',11);
[xd, yl] = digpte47(0, P.x0, P);
r = numel(xd) == 47 && numel(yl) >= 38 && all(isfinite(yl(26:35)));
end

% =========================================================================
function r = operacion_()
P = pte47_params('775','samples',11);
[~, yl] = digpte47(0, P.x0, P);
y = yl(26:28);  u = yl(29:31);
r = abs(y(1) - 1459.95) < 0.05 && abs(y(2) - 1459.22) < 0.05 && ...
    abs(y(3) - 2415.15) < 0.10 && abs(u(1) - 3.8177) < 1e-3 && ...
    abs(u(2) - 3.0286) < 1e-3 && abs(u(3) - 1.6607) < 1e-3;
end

% =========================================================================
function r = regresor_()
th = zeros(3, 33);
M  = amin_modelo(th, 5, 3, 3, 1, 20, ones(3,1), ones(3,1));
r  = M.npar == 33 && size(M.B,3) == 6 && size(M.A,3) == 5;
end

% =========================================================================
function r = rls_()
% Sistema lineal exacto: el RLS con beta = 1 y P0 grande tiene que acabar en
% la solucion de minimos cuadrados, y con datos sin ruido, en la exacta.
rand('state', 7); randn('state', 7); %#ok<RAND>
npar = 8;  ny = 3;  nd = 400;
th0 = randn(ny, npar);
X   = randn(npar, nd);
Y   = th0*X;
E = struct('th', zeros(ny,npar), 'P', 1e6*eye(npar), 'beta', 1, 'n', 0);
for i = 1:nd
    E = amin_rls(E, Y(:,i), X(:,i));
end
r = norm(E.th - th0, 'fro')/norm(th0,'fro') < 1e-8 && E.n == nd;
end

% =========================================================================
function r = ley_(literal)
if nargin < 1, literal = false; end
% Con el modelo EXACTO y lambda = 0, la ley (12) es la de varianza minima:
% tiene que colocar la salida del paso siguiente EXACTAMENTE en la consigna.
%
% Se comprueba en el PRIMER instante en que la ley actua, y solo en ese.
% Despues no: con lambda = 0 el mando invierte B(q^-1), y si sus ceros caen
% fuera del circulo unidad ---lo normal en un modelo cualquiera--- el lazo se
% va.  Esa divergencia no es un fallo de esta implementacion: es la razon por
% la que Clarke y Gawthrop introducen la ponderacion Q', por la que Amin usa
% Q' = sqrt(lambda) I con lambda > 0, y por la que Galindo del Valle (2001)
% descarta la varianza minima por «la cancelacion de ceros y la restriccion a
% fase minima».  Verificar la ecuacion y verificar la estabilidad del lazo
% son dos cosas distintas, y esta prueba es la primera.
rand('state', 3); randn('state', 3); %#ok<RAND>
N = 3;  nu = 3;  ny = 3;  T = 20;
B = 0.5*randn(ny,nu,N+1);  B(:,:,1) = eye(ny) + 0.2*randn(ny);
A = 0.2*randn(ny,ny,N);
th = zeros(ny, (N+1)*nu + N*ny);
for i = 0:N,  th(:, i*nu + (1:nu)) = B(:,:,i+1);  end
off = (N+1)*nu;
for i = 1:N,  th(:, off + (i-1)*ny + (1:ny)) = -A(:,:,i);  end

M = amin_modelo(th, N, nu, ny, 1, T, zeros(nu,1), zeros(ny,1));
S = amin_stc_init(M, 'lambda',0, 'adapt',false, 'Tc',T, ...
                  'Umin',-inf, 'Umax',inf, 'literal',literal);

Yb = zeros(ny, 40);  Ub = zeros(nu, 40);
w  = [1; -2; 0.5];
y  = 0.1*randn(ny,1);
r  = false;
for t = 1:30
    [u, S] = amin_stc(S, y, w, zeros(nu,1));
    actua = ~isempty(u);
    if ~actua, u = zeros(nu,1); end
    Ub = [u, Ub(:,1:end-1)];
    Yb = [y, Yb(:,1:end-1)];
    yn = zeros(ny,1);
    for i = 1:N, yn = yn - A(:,:,i)*Yb(:,i); end
    for j = 0:N, yn = yn + B(:,:,j+1)*Ub(:,j+1); end
    y = yn;
    if actua
        r = norm(y - w) < 1e-9;      % el primer instante en que manda la ley
        return
    end
end
end

% =========================================================================
function r = lag_()
% El mando cada 2 s de la seccion V: «the inputs and outputs are sampled
% every 2 seconds, but the samples of inputs and outputs needed to
% calculate the controls are 20 seconds apart».  La planta de prueba es
% EXACTAMENTE ese modelo en la rejilla de 2 s: la salida de cada instante
% depende de las muestras de 20 s en 20 s hacia atras, o sea diez cadenas
% ARX intercaladas, una por fase.  Con lambda = 0 la ley tiene que dejar
% y = w en TODOS los instantes a partir del primer periodo del modelo, y no
% solo en el primero, que es donde la historia todavia es cero y cualquier
% indice da lo mismo (por eso la prueba 8 no lo detecta).  Con el indice de
% mandos corrido un instante ---el error corregido el 2026-09-29--- falla.
rand('state', 5); randn('state', 5); %#ok<RAND>
N = 3;  nu = 3;  ny = 3;  Tm = 20;  Tc = 2;  L = Tm/Tc;
B = 0.1*randn(ny,nu,N+1);  B(:,:,1) = eye(ny) + 0.2*randn(ny);
A = 0.1*randn(ny,ny,N);
th = zeros(ny, (N+1)*nu + N*ny);
for i = 0:N,  th(:, i*nu + (1:nu)) = B(:,:,i+1);  end
off = (N+1)*nu;
for i = 1:N,  th(:, off + (i-1)*ny + (1:ny)) = -A(:,:,i);  end

M = amin_modelo(th, N, nu, ny, 1, Tm, zeros(nu,1), zeros(ny,1));
S = amin_stc_init(M, 'lambda',0, 'adapt',false, 'Tc',Tc, ...
                  'Umin',-inf, 'Umax',inf);

nT = 8*L;  pad = (N+2)*L;             % historia previa en cero
Y = zeros(ny, pad + nT);  U = zeros(nu, pad + nT);
w = [1; -2; 0.5];
err = 0;
for n = pad + (1:nT)
    y = zeros(ny,1);                  % y(n) = sum Bj u(n-(j+1)L) - sum Ai y(n-iL)
    for j = 0:N, y = y + B(:,:,j+1)*U(:, n-(j+1)*L); end
    for i = 1:N, y = y - A(:,:,i)*Y(:, n-i*L); end
    Y(:,n) = y;
    if n > pad + L, err = max(err, norm(y - w)); end
    [u, S] = amin_stc(S, y, w, zeros(nu,1));
    U(:,n) = u;
end
r = err < 1e-8;
end

% =========================================================================
function r = paquete_()
rand('state',11); randn('state',11); %#ok<RAND>
th = randn(3,33);
M  = amin_modelo(th, 5, 3, 3, 1, 20, zeros(3,1), zeros(3,1));
th2 = zeros(3,33);
for i = 0:5,  th2(:, i*3 + (1:3)) = M.B(:,:,i+1);  end
for i = 1:5,  th2(:, 18 + (i-1)*3 + (1:3)) = -M.A(:,:,i);  end
r = norm(th - th2, 'fro') < 1e-12;
end

% =========================================================================
function r = cache_()
%CACHE_  Ningun estacionario, lote ni modelo guardado puede ser complejo.
%
%   Un estado COMPLEJO no lo detecta ISFINITE ---isfinite(1+2i) es true--- y
%   se cuela hasta que algo intenta dibujarlo, momento en el que MATLAB dice
%   «Complex values are not supported for 'Y'» en un sitio que no tiene nada
%   que ver con la causa.  De ahi esta prueba.
here = fileparts(mfilename('fullpath'));
d = dir(fullfile(here,'datos','*.mat'));
r = true;
if isempty(d)
    fprintf('      (datos/ vacio: nada que comprobar)\n');
    return
end
for i = 1:numel(d)
    a = fullfile(here,'datos',d(i).name);
    q = load(a);
    f = fieldnames(q);
    for j = 1:numel(f)
        if ~limpio_(q.(f{j}))
            fprintf('      %s tiene valores complejos o no finitos\n', d(i).name);
            r = false;
        end
    end
end
end

function r = soloTilt_()
%SOLOTILT_  La hipotesis de planta del articulo, comprobada en dos sitios.
%
%   1. AMIN_PLANTA tiene que devolver SIEMPRE P.soloTilt = true, porque es
%      por donde pasa toda la replica.
%   2. La bandera tiene que cambiar algo de verdad cuando CXGG esta por
%      debajo de 2 V, que es donde el rango partido abre la valvula de
%      atemperacion del recalentador.  Si no cambiara nada, la bandera
%      estaria mal cableada y no nos enterariamos.
S = amin_estacionario(75, 'verbose',false);

P = amin_planta(S.base, 'ldcStart',S.ldc, 'ldcRate',0, 'ldcT0',0, ...
                'ldcT1',0, 'samples',11);
r = isfield(P,'soloTilt') && P.soloTilt;
if ~r
    fprintf('      AMIN_PLANTA no pone soloTilt\n');
    return
end

% Mismo estado, mismo mando, CXGG en el rango donde el rociado abre.  OJO:
% el rociado depende de la demanda RETARDADA cxggd, que es el estado 42, no
% del mando que se impone; por eso hay que moverlo en el estado y no solo en
% uFcn, o las dos derivadas salen iguales y la prueba no comprueba nada.
P.x0 = S.x0;  P.ldc = S.ldc;
P.openLoop = [true true true];
u = [S.u(1); 1.5; S.u(3)];
P.uFcn = @(z) u;

x = S.x0(:);  x(42) = 1.5;          % cxggd -> cry = -1.5 -> wry = 25 lb/s
Q = P;  Q.soloTilt = false;
xd1 = digpte47(0, x, P);
xd0 = digpte47(0, x, Q);
d = max(abs(xd1 - xd0));
r = d > 0;
if ~r
    fprintf(['      soloTilt no cambia la derivada con CXGG = 1,5 V: ' ...
             'la bandera no esta llegando a DIGPTE47\n']);
end
end

function r = calentamiento_()
%CALENTAMIENTO_  Mientras la ley no entrega mando, el lazo tiene que seguir
%   con el PI de Usoro CERRADO, no con su ultimo mando congelado.  Congelarlo
%   dejaba los tres mandos clavados en su valor de t = 0 durante los primeros
%   N*T segundos y la planta se iba sola: era el fallo que reventaba las dos
%   pruebas del articulo.  Aqui se corre la misma rampa con y sin controlador
%   y se exige que coincidan mientras dura el calentamiento.
[P, info] = amin_rampa(90, 70, 'dur',60, 'verbose',false);
N = 6;  nu = 3;  ny = 3;
th = zeros(ny, (N+1)*nu + N*ny);   th(:,1:3) = eye(3);
M0 = amin_modelo(th, N, nu, ny, 1, 20, info.ss.u, info.ss.y, 75);
S  = amin_stc_init(M0, 'lambda',1, 'beta',0.99, 'adapt',true, 'Tc',20, ...
                   'arranque','espera');

Rs = amin_lazo(S, P);          % con el STC, pero sin llegar a mandar
Rp = amin_lazo([], P);         % solo los PI

m = min(size(Rs.U,2), size(Rp.U,2));
du = max(max(abs(Rs.U(:,1:m) - Rp.U(:,1:m))));
dy = max(max(abs(Rs.Y(:,1:m) - Rp.Y(:,1:m))));
r  = (du < 1e-9) && (dy < 1e-9);
if ~r
    fprintf('      diferencia con el PI: mando %.3e, salida %.3e\n', du, dy);
end
end

function ok = limpio_(v)
ok = true;
if isnumeric(v)
    ok = isreal(v) && all(isfinite(v(:)));
elseif isstruct(v)
    for k = 1:numel(v)
        f = fieldnames(v(k));
        for j = 1:numel(f)
            ok = ok && limpio_(v(k).(f{j}));
            if ~ok, return, end
        end
    end
elseif iscell(v)
    for k = 1:numel(v)
        ok = ok && limpio_(v{k});
        if ~ok, return, end
    end
end
end

% =========================================================================
function r = pheredada_()
%PHEREDADA_  AMIN_COVARIANZA tiene que dar exactamente la P final del RLS
%   encadenado de AMIN_IDENT con los datos del articulo, y AMIN_STC_INIT
%   tiene que arrancar con ella si no se le pide otra cosa.
q = load(fullfile('datos','amin_datos_75.mat'));  D = q.D;
Mi = amin_ident(D, 'N',5, 'criterio','fijo', 'Nfijo',5, 'verbose',false);
q = load(fullfile('datos','amin_modelo.mat'));    M = q.M;
P = amin_covarianza(M);
S = amin_stc_init(M);
r = ~isempty(P) && max(abs(P(:) - Mi.Pf(:))) <= 1e-9*max(abs(Mi.Pf(:))) ...
    && max(abs(S.E.P(:) - P(:))) == 0 && max(abs(Mi.th(:) - M.th(:))) < 1e-5;
end
