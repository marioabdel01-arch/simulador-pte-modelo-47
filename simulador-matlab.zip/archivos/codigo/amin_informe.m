function arch = amin_informe(nombre, titulo, P, L, axs, varargin)
%AMIN_INFORME  Informe en PDF de una corrida de la replica.
%
%   ARCH = AMIN_INFORME(NOMBRE, TITULO, P, L, AXS)
%   ARCH = AMIN_INFORME(..., 'antes',F, 'anexo',C, 'carpeta',D, 'res',R)
%
%   Version autonoma y reducida del informe que usan los simuladores del
%   repositorio.  Vive aqui, y no se importa de `comun/`, porque esta carpeta
%   tiene que poder entregarse suelta.
%
%     NOMBRE   raiz del archivo, sin extension; se le anade la marca de tiempo
%     TITULO   encabezado de todas las paginas
%     P        cell de lineas con los parametros de la corrida
%     L        cell con la lectura
%     AXS      vector de UIAXES: uno por pagina
%
%   Opciones
%     'antes'   funcion F(k) que se llama antes de exportar la grafica k.  Un
%               UIAXES de una pestana que no se ha mostrado se exporta EN
%               BLANCO, asi que el simulador la usa para traerla al frente.
%     'anexo'   cell de lineas que se imprimen en hojas propias al final
%     'carpeta' destino  ['resultados']
%     'res'     puntos por pulgada de las graficas  [200]
%
%   Necesita EXPORTGRAPHICS con 'Append', o sea MATLAB R2021b o posterior.
%
%   See also AMIN_SIM.

opt = struct('antes',[], 'anexo',{{}}, 'carpeta','resultados', 'res',200);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_informe:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end
if isempty(P), P = {}; end
if isempty(L), L = {}; end
P = P(:);  L = L(:);
axs = axs(isgraphics(axs));
n = numel(axs);

if exist(opt.carpeta,'dir') ~= 7, mkdir(opt.carpeta); end
sello = datestr(now, 'yyyymmdd_HHMMSS'); %#ok<TNOW1,DATST>
arch  = fullfile(opt.carpeta, sprintf('%s_%s.pdf', limpia_(nombre), sello));

% ---- portada -----------------------------------------------------------
f1 = pagina_(21.0, 29.7);
c1 = onCleanup(@() close(f1)); %#ok<NASGU>
portada_(f1, titulo, P, L, arch);
try
    exportgraphics(f1, arch, 'ContentType','vector', 'BackgroundColor','white');
catch err
    error('amin_informe:export', 'No pude escribir el PDF en\n  %s\n%s', ...
          arch, err.message);
end

% ---- graficas, una por pagina ------------------------------------------
if n > 0
    tmp = tempname;  mkdir(tmp);
    c2 = onCleanup(@() rmdir(tmp,'s')); %#ok<NASGU>
    blancas = [];
    for k = 1:n
        png = fullfile(tmp, sprintf('g%02d.png', k));
        if ~isempty(opt.antes), opt.antes(k);  espera_(0.20); end
        exportgraphics(axs(k), png, 'Resolution',opt.res, ...
                       'BackgroundColor','white');
        I = imread(png);
        if enBlanco_(I)
            espera_(0.8);
            exportgraphics(axs(k), png, 'Resolution',opt.res, ...
                           'BackgroundColor','white');
            I = imread(png);
            if enBlanco_(I), blancas(end+1) = k; end %#ok<AGROW>
        end
        hoja_(arch, titulo, I, opt.res, k, n);
    end
    if ~isempty(blancas)
        warning('amin_informe:blanco', ...
            ['Las graficas %s salieron en blanco.  Suele ser una pestana ' ...
             'que MATLAB no habia terminado de dibujar: visitalas a mano ' ...
             'una vez y vuelve a exportar.'], mat2str(blancas));
    end
end

anexo_(arch, titulo, opt.anexo);
end

% =========================================================================
function f = pagina_(w, h)
f = figure('Visible','off', 'Units','centimeters', ...
           'Position',[1 1 w h], 'Color','w', ...
           'PaperUnits','centimeters', 'PaperSize',[w h], ...
           'PaperPosition',[0 0 w h], 'InvertHardcopy','off');
end

% =========================================================================
function portada_(f, titulo, P, L, arch)
mono = get(groot,'FixedWidthFontName');
annotation(f,'textbox',[0.06 0.935 0.88 0.045], 'String',titulo, ...
           'EdgeColor','none','FontSize',13,'FontWeight','bold', ...
           'Interpreter','none','VerticalAlignment','middle');
annotation(f,'textbox',[0.06 0.905 0.88 0.03], ...
           'String',sprintf('%s   ·   %s', datestr(now,'dd/mm/yyyy HH:MM'), arch), ...
           'EdgeColor','none','FontSize',8,'FontAngle','italic', ...
           'Color',[0.38 0.38 0.42],'Interpreter','none'); %#ok<TNOW1,DATST>
ax = axes(f,'Position',[0 0 1 1],'Visible','off'); %#ok<LAXES>
xlim(ax,[0 1]);  ylim(ax,[0 1]);
text(ax, 0.06, 0.875, [{'PARAMETROS DE LA SIMULACION'; ...
                        repmat('-',1,44)}; P], ...
     'FontName',mono,'FontSize',8.5,'Interpreter','none', ...
     'VerticalAlignment','top');
text(ax, 0.54, 0.875, [{'LECTURA'; repmat('-',1,44)}; L], ...
     'FontName',mono,'FontSize',8.5,'Interpreter','none', ...
     'VerticalAlignment','top');
end

% =========================================================================
function hoja_(arch, titulo, I, res, pag, npag)
f = pagina_(29.7, 21.0);
c = onCleanup(@() close(f)); %#ok<NASGU>
annotation(f,'textbox',[0.04 0.962 0.92 0.03], ...
           'String',sprintf('%s   ---   grafica %d de %d', titulo, pag, npag), ...
           'EdgeColor','none','FontSize',9,'FontAngle','italic', ...
           'Color',[0.38 0.38 0.42],'Interpreter','none');
ax = axes(f,'Position',[0.015 0.015 0.97 0.935]); %#ok<LAXES>
imshow(I,'Parent',ax);
try
    exportgraphics(f, arch, 'Append',true, 'Resolution',res, ...
                   'BackgroundColor','white');
catch err
    warning('amin_informe:hoja','No pude anadir una grafica: %s', err.message);
end
end

% =========================================================================
function anexo_(arch, titulo, C)
if isempty(C), return, end
C = C(:);
porHoja = 80;
np = ceil(numel(C)/porHoja);
for g = 1:np
    idx = (g-1)*porHoja + 1 : min(g*porHoja, numel(C));
    f = pagina_(21.0, 29.7);
    c = onCleanup(@() close(f)); %#ok<NASGU>
    enc = titulo;
    if np > 1, enc = sprintf('%s   ---   anexo %d de %d', titulo, g, np); end
    annotation(f,'textbox',[0.06 0.962 0.90 0.03], 'String',enc, ...
               'EdgeColor','none','FontSize',9,'FontAngle','italic', ...
               'Color',[0.38 0.38 0.42],'Interpreter','none');
    ax = axes(f,'Position',[0 0 1 1],'Visible','off'); %#ok<LAXES>
    xlim(ax,[0 1]);  ylim(ax,[0 1]);
    text(ax, 0.06, 0.945, C(idx), ...
         'FontName',get(groot,'FixedWidthFontName'), 'FontSize',8, ...
         'Interpreter','none','VerticalAlignment','top');
    try
        exportgraphics(f, arch, 'Append',true, 'ContentType','vector', ...
                       'BackgroundColor','white');
    catch err
        warning('amin_informe:anexo','No pude anadir el anexo: %s', err.message);
        return
    end
end
end

% =========================================================================
function b = enBlanco_(I)
v = double(I(:));
b = (max(v) - min(v)) < 8;
end

function espera_(t)
drawnow;  pause(t);  drawnow;
end

function s = limpia_(s)
s = regexprep(char(s), '[^A-Za-z0-9_\-]', '_');
end
