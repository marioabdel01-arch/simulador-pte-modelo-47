function E = amin_espectro(D, varargin)
%AMIN_ESPECTRO  El limite superior del periodo de muestreo (seccion IV).
%
%   E = AMIN_ESPECTRO(D)
%   E = AMIN_ESPECTRO(D, 'frac',0.99)
%
%   D sale de AMIN_DATOS.  El articulo justifica asi su eleccion de T:
%
%     «The sampling period was chosen so that no significant amount of
%      information is lost.  The upper limit for the sampling period is given
%      by the Sampling Theorem, see [9].  Using an estimate of the power
%      spectrum for TSSO, TRHO, and PSSO, the upper limit for the sampling
%      period was found to be 1.25 minutes.»
%
%   1,25 min = 75 s.  Por el teorema de muestreo, T <= 1/(2 f_max), luego
%   f_max = 1/150 Hz = 6,67 mHz: una banda de unos 150 s de periodo.
%
%   OJO CON LA CIRCULARIDAD.  Los datos de D ya estan muestreados a 20 s, asi
%   que su Nyquist es 25 mHz y no se puede comprobar un limite de 75 s con
%   ellos sin mas.  Lo que esta funcion hace es lo unico honesto: estima el
%   espectro de las salidas EN LAZO ABIERTO con el paso de integracion
%   (0,1 s) ---remuestreando a 1 s, que deja Nyquist en 500 mHz--- y busca la
%   frecuencia por debajo de la cual esta `frac` de la potencia.  Si de ahi
%   sale un periodo del orden de 75 s, la eleccion de Amin queda reproducida;
%   si no, hay que decirlo.
%
%   Por eso la funcion vuelve a correr la planta en vez de usar D.run: D solo
%   se usa para heredar el punto de operacion y las amplitudes.
%
%   DEVUELVE  E.f, E.S (3 x nf), E.fmax (1 x 3), E.Tmax (1 x 3), E.frac
%
%   See also AMIN_DATOS.

opt = struct('frac',0.99, 'dur',400, 'Tre',1, 'nRun',3, ...
             'semilla',1984, 'verbose',true);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_espectro:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

S = amin_estacionario(D.pct, 'verbose',false);
Ts = 0.1;
strideIn  = round(D.T/Ts);          % la entrada se mantiene 20 s
strideOut = round(opt.Tre/Ts);      % la salida se guarda cada 1 s
nS = floor(opt.dur/D.T);

acum = [];
for r = 1:opt.nRun
    try, rng(opt.semilla+r,'twister'); catch, randn('state',opt.semilla+r); end %#ok<RAND>
    Useq = S.u(:)*ones(1,nS) + diag(D.sigma)*randn(3,nS);
    uNow = Useq(:,1);
    P = amin_planta(S.base, 'ldcStart',S.ldc, 'ldcRate',0, ...
                     'ldcT0',0, 'ldcT1',0, 'samples',nS*strideIn+1);
    P.x0 = S.x0;  P.ldc = S.ldc;
    P.openLoop = [true true true];
    P.uFcn = @(z) uNow;

    x = S.x0(:);  t = 0;  Y = [];  c = 0;
    for s = 1:nS
        uNow = Useq(:,s);  P.uFcn = @(z) uNow;
        for i = 1:strideIn
            if mod(c, strideOut) == 0
                [~, yl] = digpte47(t, x, P);
                Y(:, end+1) = yl(26:28).'; %#ok<AGROW>
            end
            xd1 = digpte47(t,      x,              P);
            xd2 = digpte47(t+Ts/2, x + (Ts/2)*xd1, P);
            xd3 = digpte47(t+Ts/2, x + (Ts/2)*xd2, P);
            xd4 = digpte47(t+Ts,   x +  Ts  *xd3,  P);
            x = x + (Ts/6)*(xd1 + 2*xd2 + 2*xd3 + xd4);
            x = pte47_clamp(x, P);
            t = t + Ts;  c = c + 1;
        end
        if ~all(isfinite(x)) || ~isreal(x), break, end
    end
    acum = cat(3, acum, Y(:,1:min(size(Y,2), floor(opt.dur/opt.Tre))));
end

nY = size(acum,2);
fs = 1/opt.Tre;
f  = (0:floor(nY/2)) * fs / nY;
Sp = zeros(3, numel(f));
for r = 1:size(acum,3)
    for i = 1:3
        z = acum(i,:,r) - mean(acum(i,:,r));
        z = z .* hann_(nY);
        F = fft(z);
        F = F(1:numel(f));
        Sp(i,:) = Sp(i,:) + abs(F).^2;
    end
end
Sp = Sp / size(acum,3);
Sp(:,1) = 0;                                  % fuera la continua

E = struct('f',f, 'S',Sp, 'frac',opt.frac, 'Tre',opt.Tre);
E.fmax = zeros(1,3);  E.Tmax = zeros(1,3);
for i = 1:3
    c = cumsum(Sp(i,:));  c = c/c(end);
    j = find(c >= opt.frac, 1, 'first');
    E.fmax(i) = f(j);
    E.Tmax(i) = 1/(2*E.fmax(i));
end
E.TmaxGlobal = min(E.Tmax);

if opt.verbose
    nom = {'TSSO','TRHO','PSSO'};
    for i = 1:3
        fprintf('%s: %.0f %% de la potencia por debajo de %.4f Hz  ->  T <= %.1f s\n', ...
                nom{i}, 100*opt.frac, E.fmax(i), E.Tmax(i));
    end
    fprintf('\nlimite mas restrictivo: T <= %.1f s\n', E.TmaxGlobal);
    fprintf('Amin: 1,25 min = 75 s, y elige T = 20 s\n');
end
end

% =========================================================================
function w = hann_(n)
%HANN_  Ventana de Hann sin depender de ninguna toolbox.
w = 0.5*(1 - cos(2*pi*(0:n-1)/(n-1)));
end
