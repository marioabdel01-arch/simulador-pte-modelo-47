function [Yh, Ys, aj] = amin_pred(M, U, Y, Ld)
%AMIN_PRED  Prediccion del modelo AR de Amin sobre una corrida.
%
%   [YH, YS, AJ] = AMIN_PRED(M, U, Y)
%   [YH, YS, AJ] = AMIN_PRED(M, U, Y, LD)        modelo 3x4
%
%   U es nu x n e Y es ny x n, en UNIDADES FISICAS y a periodo de muestreo T.
%   LD es nd x n, la demanda de carga ldc medida en la corrida.  Hace falta
%   si y solo si el modelo es 3x4 (M.nd > 0).
%
%   YH  prediccion a UN PASO: usa las salidas medidas pasadas.  Es lo que
%       minimiza el estimador, y es el criterio con el que el articulo elige
%       el orden N ---«the value which results in the best prediction of the
%       outputs of the system»---.
%   YS  SIMULACION LIBRE: reinyecta sus propias salidas.  El articulo no la
%       usa para elegir N, pero su figura 5 es exactamente esto ---compara la
%       respuesta del sistema con la del modelo identificado a lo largo de
%       400 s---, asi que hace falta para reproducirla.
%   AJ  struct con los dos ajustes por salida, en porcentaje:
%
%           aj.un(i)  y  aj.libre(i)      100*(1 - ||y-yhat|| / ||y-mean(y)||)
%
%   Las primeras max(N, k+N) muestras no se predicen (no hay historia) y se
%   devuelven como NaN; los ajustes las excluyen.
%
%   See also AMIN_MODELO, AMIN_IDENT.

N = M.N;  k = M.k;  nu = M.nu;  ny = M.ny;
n = size(Y,2);
if size(U,2) ~= n
    error('amin_pred:tam', 'U tiene %d muestras y Y tiene %d.', size(U,2), n);
end
nd = 0;  if isfield(M,'nd'), nd = M.nd; end
if nd > 0
    if nargin < 4 || size(Ld,2) ~= n || size(Ld,1) ~= nd
        error('amin_pred:ldc', ...
              'El modelo es 3x4: hace falta LD (%d x %d), la ldc medida.', nd, n);
    end
    Dd = Ld - M.d_ss(:)*ones(1,n);
end

Ud = U - M.u_ss(:)*ones(1,n);
Yd = Y - M.y_ss(:)*ones(1,n);

t0 = max(N + k, N) + 1;                 % primera muestra predecible
Yh = nan(ny, n);
Ys = nan(ny, n);

% --- un paso ------------------------------------------------------------
for t = t0:n
    yy = zeros(ny,1);
    for i = 1:N                         % forma predictora: y(t-k-i+1)
        yy = yy - M.A(:,:,i)*Yd(:, t-k-i+1);
    end
    for j = 0:N
        yy = yy + M.B(:,:,j+1)*Ud(:, t-k-j);
    end
    if nd > 0
        for j = 0:N
            yy = yy + M.D(:,:,j+1)*Dd(:, t-k-j);
        end
    end
    Yh(:,t) = yy;
end

% --- simulacion libre ---------------------------------------------------
% Arranca con las N salidas medidas anteriores a t0 y a partir de ahi solo
% usa las suyas.  Es la figura 5 del articulo.
Zs = Yd;
for t = t0:n
    yy = zeros(ny,1);
    for i = 1:N
        yy = yy - M.A(:,:,i)*Zs(:, t-k-i+1);
    end
    for j = 0:N
        yy = yy + M.B(:,:,j+1)*Ud(:, t-k-j);
    end
    if nd > 0
        for j = 0:N
            yy = yy + M.D(:,:,j+1)*Dd(:, t-k-j);
        end
    end
    Zs(:,t) = yy;
    Ys(:,t) = yy;
end

Yh = Yh + M.y_ss(:)*ones(1,n);
Ys = Ys + M.y_ss(:)*ones(1,n);

aj = struct('un', zeros(1,ny), 'libre', zeros(1,ny));
idx = t0:n;
for i = 1:ny
    yv = Y(i,idx);
    d  = norm(yv - mean(yv));
    if d <= 0, d = eps; end
    aj.un(i)    = 100*(1 - norm(yv - Yh(i,idx))/d);
    e2 = Ys(i,idx);
    if all(isfinite(e2))
        aj.libre(i) = 100*(1 - norm(yv - e2)/d);
    else
        aj.libre(i) = -inf;
    end
end
end
