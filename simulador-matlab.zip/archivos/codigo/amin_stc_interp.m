function S = amin_stc_interp(S, TB, ldc)
%AMIN_STC_INTERP  STC modificado en la prueba con demanda real: tabla interpolada.
%
%   S = AMIN_STC_INTERP(S, TB, LDC)
%
%   En cada instante de control:
%     * el punto de operacion (u_ss, y_ss) es siempre el de la tabla
%       interpolada a la carga actual (AMIN_TABLA_EN), y la historia en
%       desviaciones se re-refiere a el (AMIN_STC_NODO con reref 'todo'), de
%       modo que el cambio no mete escalones ficticios;
%     * theta es el de la tabla interpolada mientras el estimador esta
%       congelado; si esta actualizando, se conserva el theta del estimador.
%
%   Se llama DESPUES de decidir S.adapt (AMIN_CONGELA_MOV).
%
%   See also AMIN_TABLA_EN, AMIN_CONGELA_MOV, AMIN_LAZO, AMIN_SIM.

Mi = amin_tabla_en(TB, ldc/0.05);
antes = '';
if isfield(S,'reref'), antes = S.reref; end
S.reref = 'todo';
if S.adapt
    th = S.E.th;
    S = amin_stc_nodo(S, Mi);
    S.E.th = th;
    if isfield(Mi,'nd') && Mi.nd > 0
        S.M = amin_modelo(th, Mi.N, Mi.nu, Mi.ny, Mi.k, Mi.T, Mi.u_ss, Mi.y_ss, Mi.pct, Mi.d_ss);
    else
        S.M = amin_modelo(th, Mi.N, Mi.nu, Mi.ny, Mi.k, Mi.T, Mi.u_ss, Mi.y_ss, Mi.pct);
    end
else
    S = amin_stc_nodo(S, Mi);
end
S.reref = antes;
end
