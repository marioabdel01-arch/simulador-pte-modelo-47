function ok = verifica_ldc()
%VERIFICA_LDC  Comprobaciones del modelo 3x4 (ldc como entrada exogena).
%
%   >> setup_amin
%   >> verifica_ldc
%
%   No usa la planta: sobre un ARX 3x4 SINTETICO, del que se conocen los
%   parametros exactos, comprueba que las cuatro piezas que tocan el bloque
%   D ---el regresor de la identificacion, la prediccion, el regresor del
%   estimador en linea y la ley--- usan la MISMA convencion de indices.  Un
%   desfase de un periodo en ldc no da error: da un modelo peor y una
%   prealimentacion a destiempo, y eso solo se ve asi.
%
%     1. AMIN_IDENT recupera theta exacto de datos sin ruido
%     2. AMIN_PRED con ese theta predice a un paso con error ~ 0
%     3. la ley (AMIN_STC) con lambda = 0 y modelo exacto deja
%        y(t+1) = w(t+1) aunque ldc se mueva: la prealimentacion compensa
%     4. el mismo lazo SIN el termino D (modelo 3x4 con D = 0) no lo
%        consigue: el ldc que se mueve si importa
%     5. el estimador en linea de AMIN_STC parte de un theta falso y
%        converge al verdadero (su regresor esta alineado con el de 1)
%     6. un modelo 3x3 sigue funcionando sin pasarle ldc
%     7. al conmutar de nodo (AMIN_STC_NODO) la historia de ldc se
%        re-refiere al punto nuevo y la de los mandos no se toca
%
%   See also AMIN_MODELO, AMIN_STC, AMIN_IDENT.

rng_(7);
N = 2;  nu = 3;  ny = 3;  nd = 1;  k = 1;  T = 20;
[th, Mv] = sintetico_(N, nu, ny, nd, k, T);

ok = true;

% ---- 1. identificacion ---------------------------------------------------
D = struct('T',T, 'k',k, 'pct',75, 'u_ss',Mv.u_ss, 'y_ss',Mv.y_ss, ...
           'd_ss',Mv.d_ss, 'dur',400);
n = 60;
for r = 1:4
    U = Mv.u_ss*ones(1,n) + 0.1*randn(nu,n);
    L = Mv.d_ss*ones(1,n) + 0.05*randn(nd,n);
    Y = simula_(Mv, U, L);
    D.run(r) = struct('U',U, 'Y',Y, 't',(0:n-1)*T, 'L',L); %#ok<AGROW>
end
M1 = amin_ident(D, 'N',N, 'criterio','fijo', 'Nfijo',N, 'holdout',0, ...
                'P0',1e8, 'verbose',false);
e1 = max(abs(M1.th(:) - th(:)));
ok = informa_(1, 'identificacion recupera theta (max |dtheta|)', e1, 1e-5) && ok;

% ---- 2. prediccion -------------------------------------------------------
[Yh, ~, aj] = amin_pred(Mv, D.run(1).U, D.run(1).Y, D.run(1).L);
i0 = find(all(isfinite(Yh),1), 1);
e2 = max(max(abs(Yh(:,i0:end) - D.run(1).Y(:,i0:end))));
ok = informa_(2, sprintf('prediccion a un paso (ajuste %.4f %%)', min(aj.un)), e2, 1e-9) && ok;

% ---- 3 y 4. la ley con lambda = 0 -----------------------------------------
[e3, e4] = lazo_ley_(Mv);
ok = informa_(3, 'ley 3x4, lambda = 0: |y(t+1) - w| con ldc moviendose', e3, 1e-8) && ok;
fprintf(['   4  la misma ley con D = 0 (sin prealimentacion)            ' ...
         '%10.3g   debe ser >> 0\n'], e4);
if ~(e4 > 1e3*max(e3, 1e-12)), ok = false; fprintf('      FALLA\n'); end

% ---- 5. estimador en linea ----------------------------------------------
e5 = lazo_rls_(Mv);
ok = informa_(5, 'RLS en linea converge al theta verdadero', e5, 1e-4) && ok;

% ---- 6. el 3x3 intacto ---------------------------------------------------
M33 = amin_modelo(th(:, 1:(N+1)*nu + N*ny), N, nu, ny, k, T, Mv.u_ss, Mv.y_ss);
S = amin_stc_init(M33, 'lambda',0, 'adapt',false);
[u, S] = amin_stc(S, Mv.y_ss, Mv.y_ss, Mv.u_ss); %#ok<ASGLU>
e6 = max(abs(u - Mv.u_ss));
ok = informa_(6, '3x3 sin ldc: primer mando = u_ss', e6, 1e-12) && ok;

% ---- 7. conmutar de nodo no cambia la demanda fisica de la historia -----
S = amin_stc_init(Mv, 'lambda',0.1, 'adapt',false);
for t = 1:6
    [~, S] = amin_stc(S, Mv.y_ss, Mv.y_ss, Mv.u_ss, Mv.d_ss + 0.1*t);
end
fis0 = S.Dh + Mv.d_ss;
M2 = amin_modelo(Mv.th, Mv.N, Mv.nu, Mv.ny, Mv.k, Mv.T, Mv.u_ss + 0.2, ...
                 Mv.y_ss, 80, Mv.d_ss + 0.25);
S2 = amin_stc_nodo(S, M2);
e7 = max(abs(S2.Dh(:) + M2.d_ss - fis0(:)));
ok = informa_(7, 'conmutar de nodo conserva ldc fisica en la historia', e7, 1e-12) && ok;
e7b = max(abs(S2.Uh(:) - S.Uh(:)));
ok = informa_(7, '  ...y con reref = ''ldc'' no toca la de los mandos', e7b, 0) && ok;

if ok, fprintf('\nTODO BIEN.\n'); else, fprintf('\nHAY FALLOS.\n'); end
end

% =========================================================================
function [th, M] = sintetico_(N, nu, ny, nd, k, T)
% A estable y diagonal dominante, B0 bien condicionada, D no nulo.
th = zeros(ny, (N+1)*nu + N*ny + (N+1)*nd);
for j = 0:N
    B = 0.3*randn(ny,nu);
    if j == 0, B = B + eye(ny); end
    th(:, j*nu + (1:nu)) = B;
end
off = (N+1)*nu;
for i = 1:N
    A = 0.15/i*randn(ny);  A = A + (0.4/i)*eye(ny);
    th(:, off + (i-1)*ny + (1:ny)) = -A * (-1)^i;
end
off = (N+1)*nu + N*ny;
for j = 0:N
    th(:, off + j*nd + (1:nd)) = 2*randn(ny, nd);
end
u_ss = [3; 3.5; 2.5];  y_ss = [1460; 1460; 2400];  d_ss = 3.75;
M = amin_modelo(th, N, nu, ny, k, T, u_ss, y_ss, 75, d_ss);
end

% =========================================================================
function Y = simula_(M, U, L)
% El ARX exacto, con historia inicial en el punto de operacion.
n = size(U,2);  N = M.N;  k = M.k;  pad = N + k;
Ud = [zeros(M.nu,pad), U - M.u_ss*ones(1,n)];
Ld = [zeros(M.nd,pad), L - M.d_ss*ones(1,n)];
Yd = zeros(M.ny, pad + n);
for t = pad+1 : pad+n
    y = zeros(M.ny,1);
    for i = 1:N, y = y - M.A(:,:,i)*Yd(:,t-i); end
    for j = 0:N, y = y + M.B(:,:,j+1)*Ud(:,t-k-j); end
    for j = 0:N, y = y + M.D(:,:,j+1)*Ld(:,t-k-j); end
    Yd(:,t) = y;
end
Y = Yd(:, pad+1:end) + M.y_ss*ones(1,n);
end

% =========================================================================
function [e3, e4] = lazo_ley_(Mv)
% La planta ES el ARX; el controlador lo conoce exacto.  ldc hace una
% rampa y ruido; w es constante.  Con lambda = 0 la ley (12) coloca y(t+1)
% exactamente en w, pero SOLO si descuenta el D ldc(t) que ya conoce.
n = 40;
L = Mv.d_ss + [zeros(1,5), -0.02*(1:20), -0.4*ones(1,15)] + 0.01*randn(1,n);
w = Mv.y_ss;
e = zeros(1,2);
for caso = 1:2
    M = Mv;
    if caso == 2        % mismo modelo, pero la ley ignora ldc
        th = Mv.th;  th(:, end-(M.N+1)*M.nd+1:end) = 0;
        M = amin_modelo(th, M.N, M.nu, M.ny, M.k, M.T, M.u_ss, M.y_ss, NaN, M.d_ss);
    end
    S = amin_stc_init(M, 'lambda',0, 'adapt',false, 'Umin',-inf, 'Umax',inf);
    U = Mv.u_ss*ones(1,n);  Y = Mv.y_ss*ones(1,n);
    err = 0;
    for t = 1:n-1
        % la planta avanza con lo que ha entrado hasta t-1
        Yt = simula_(Mv, U(:,1:t), L(1:t));
        Y(:,t) = Yt(:,t);
        [u, S] = amin_stc(S, Y(:,t), w, U(:,t), L(t));
        U(:,t) = u;
        if t >= 2
            err = max(err, max(abs(Y(:,t) - w)));
        end
    end
    e(caso) = err;
end
e3 = e(1);  e4 = e(2);
end

% =========================================================================
function e5 = lazo_rls_(Mv)
% Controlador con theta FALSO y estimador encendido; w aleatoria para
% excitar.  Sin ruido, el RLS debe clavar el theta verdadero.
n = 150;
thF = Mv.th + 0.05*randn(size(Mv.th));
thF(:, 1:3) = Mv.th(:, 1:3);            % B0 verdadera: que el lazo no se vaya
MF = amin_modelo(thF, Mv.N, Mv.nu, Mv.ny, Mv.k, Mv.T, Mv.u_ss, Mv.y_ss, NaN, Mv.d_ss);
S = amin_stc_init(MF, 'lambda',0.1, 'beta',1, 'adapt',true, 'P0',1e6, ...
                  'Umin',-inf, 'Umax',inf);
L = Mv.d_ss + 0.05*randn(1,n);
U = Mv.u_ss*ones(1,n);
for t = 1:n-1
    Yt = simula_(Mv, U(:,1:t), L(1:t));
    w = Mv.y_ss + 0.5*randn(3,1);
    [u, S] = amin_stc(S, Yt(:,t), w, U(:,t), L(t));
    U(:,t) = u;
end
e5 = max(abs(S.M.th(:) - Mv.th(:)));
end

% =========================================================================
function ok = informa_(i, txt, v, tol)
ok = v <= tol;
if ok, s = 'bien'; else, s = 'FALLA'; end
fprintf('  %2d  %-58s %10.3g   %s\n', i, txt, v, s);
end

function rng_(s)
try, rng(s,'twister'); catch, randn('state',s); rand('state',s); end %#ok<RAND>
end
