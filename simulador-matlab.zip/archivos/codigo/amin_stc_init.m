function S = amin_stc_init(M, varargin)
%AMIN_STC_INIT  Prepara el controlador auto-sintonizable multivariable.
%
%   S = AMIN_STC_INIT(M)
%   S = AMIN_STC_INIT(M, 'lambda',1, 'beta',0.99, 'adapt',true, 'Tc',20)
%
%   M es el modelo AR identificado (AMIN_MODELO).  El controlador es el de
%   Clarke y Gawthrop (1975) extendido a MIMO por Koivo (1980), tal como lo
%   usa el articulo: seccion III, criterio (2), ley (12).
%
%   EL CRITERIO, ecuacion (2):
%
%       J = E{ |P(q^-1) y(t+k) - R(q^-1) w(t)|^2 + |Q'(q^-1) u(t)|^2 }
%
%   con las elecciones de la seccion V del articulo:
%
%       P(q^-1) = 1        R(q^-1) = I        Q'(q^-1) = sqrt(lambda) I
%
%   LA LEY, ecuacion (12) reducida con k = 1 (pagina 344):
%
%       u(t) = { B0 + lambda (B0')^-1 }^-1 { [I - A(q^-1)] y(t+1)
%                                            - [B(q^-1) - B0] u(t) + w(t) }
%
%   donde los dos corchetes son causales:
%
%       [I - A(q^-1)] y(t+1) = -A1 y(t) - A2 y(t-1) - ... - AN y(t-N+1)
%       [B(q^-1) - B0] u(t)  =  B1 u(t-1) + ... + BN u(t-N)
%
%   EL VALOR DE LAMBDA NO APARECE EN EL ARTICULO.  Es el hueco 1 del README;
%   por eso es una opcion y por eso existe AMIN_LAMBDA.
%
%   EL ESTIMADOR es el mismo de la identificacion, ecuacion (15), porque con
%   k = 1 el articulo demuestra (pagina 344) que
%
%       C~(q^-1) = C(q^-1) = I,   G~(q^-1) = G(q^-1),   F~(q^-1) = F(q^-1) = I
%
%   o sea que los parametros del predictor optimo a un paso SON los del
%   modelo AR.  No hay un segundo juego de incognitas.
%
%   OPCIONES
%     'lambda'  ponderacion del mando.  NO ESTA EN EL ARTICULO        [1]
%     'beta'    factor de olvido de (15).  NO ESTA EN EL ARTICULO  [0.99]
%     'adapt'   estimador encendido                              [true]
%     'P0'      P(0) en linea: 'heredada' = la covarianza con que termina
%               la identificacion (AMIN_COVARIANZA), un escalar (P0*I) o
%               una matriz.  Si no hay datos compatibles con el modelo,
%               'heredada' cae en 1e2*I                      ['heredada']
%     'Tc'      periodo de calculo del mando, s.  El articulo usa 20 s y
%               prueba tambien 2 s (seccion V, final).               [M.T]
%     'Umin','Umax'  rango de los transductores de Usoro          [1, 5]
%     'literal' usar la ley TAL COMO ESTA IMPRESA, con su errata de signo
%               en el bloque de salidas.  Solo para ensenar la diferencia;
%               ver la cabecera de AMIN_STC.                     [false]
%     'reref'   que hacer con la historia al conmutar de nodo en la tabla
%               por carga: 'ldc', 'todo' o 'nada' (ver AMIN_STC_NODO).
%                                                                  ['ldc']
%     'arranque' 'estable' (la del articulo: historia inicial = estado
%               estable, o sea cero incremental, y manda desde t = 0) o
%               'espera' (no manda hasta tener N periodos de historia
%               real, con el PI mientras tanto).            ['estable']
%
%   MODELO 3x4 (M.nd > 0, NO ES DEL ARTICULO).  Si el modelo trae la demanda
%   de carga como entrada exogena, la ley la usa como PREALIMENTACION: el
%   termino D(q^-1) ldc(t) pasa al corchete como algo conocido, igual que
%   las salidas y los mandos pasados (ver AMIN_STC).  Nada mas cambia: ni el
%   criterio, ni lambda, ni el estimador, que simplemente tiene 6 incognitas
%   mas por fila (39 en vez de 33).
%
%   El modelo M se usa TAL CUAL como juego inicial de parametros, que es lo
%   que hace el articulo: «The self-tuning controller was started with the
%   parameters of the 5th order AR model estimated in the previous section as
%   the set of initial parameters.»
%
%   See also AMIN_STC, AMIN_MODELO, AMIN_LAMBDA, AMIN_TABLA.

opt = struct('lambda',1, 'beta',0.99, 'adapt',true, 'P0','heredada', ...
             'Tc',[], 'Umin',1, 'Umax',5, 'literal',false, ...
             'arranque','estable', 'reref','ldc');
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_stc_init:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end
if isempty(opt.Tc), opt.Tc = M.T; end

% Modelos guardados antes de que existiera el 3x4 no traen los campos nd, D
% y d_ss.  Se reempaquetan: son 3x3 por construccion.
if ~isfield(M,'nd')
    M = amin_modelo(M.th, M.N, M.nu, M.ny, M.k, M.T, M.u_ss, M.y_ss, M.pct);
end

r = M.T / opt.Tc;
if abs(r - round(r)) > 1e-9 || r < 1
    error('amin_stc_init:Tc', ...
          ['El periodo del modelo (%g s) tiene que ser un multiplo entero ' ...
           'del periodo de control (%g s).'], M.T, opt.Tc);
end

S = struct();
S.M      = M;
S.lambda = opt.lambda;
S.adapt  = opt.adapt;
S.Tc     = opt.Tc;
S.lag    = round(r);                 % instantes de control por periodo de modelo
S.Umin   = opt.Umin;
S.Umax   = opt.Umax;
S.literal = opt.literal;
S.reref   = opt.reref;

% P(0) EN LINEA.  El articulo no la publica (hueco 3).  Por omision se
% hereda la covarianza con que termina la identificacion: ver
% AMIN_COVARIANZA.  Con 'P0',1e2 se recupera la primera version.
if ischar(opt.P0)
    if ~strcmpi(opt.P0, 'heredada')
        error('amin_stc_init:P0', 'P0 desconocido: %s', opt.P0);
    end
    P0m = amin_covarianza(M);
    S.P0fuente = 'heredada';
    if isempty(P0m)
        P0m = 1e2*eye(M.npar);
        S.P0fuente = '1e2*I (sin datos compatibles para heredar)';
    end
elseif isscalar(opt.P0)
    P0m = opt.P0*eye(M.npar);
    S.P0fuente = sprintf('%g*I', opt.P0);
else
    P0m = opt.P0;
    if ~isequal(size(P0m), [M.npar M.npar])
        error('amin_stc_init:P0', 'P0 tiene que ser de %d x %d.', M.npar, M.npar);
    end
    S.P0fuente = 'matriz';
end
S.E = struct('th', M.th, 'P', P0m, 'beta', opt.beta, 'n', 0);

% Historias en la rejilla de CONTROL.  El regresor toma de ellas una de cada
% `lag` columnas, que es como se implementa la variante de la seccion V:
% «the inputs and outputs are sampled every 2 seconds, but the samples of
% inputs and outputs needed to calculate the controls are 20 seconds apart».
% Con retardo k el regresor llega hasta y(t-k-N+1) y u(t-k-N): las
% historias se alargan k-1 periodos de modelo.  Con k = 1, lo de siempre.
kk = M.k;
nY = (M.N+kk-1)*S.lag + 1;
% Los mandos guardan u(t-Tc) ... u(t-(N+k)Tm): la columna m es u(t - m Tc),
% porque u(t) aun no existe cuando se arma el regresor (ver AMIN_STC).
nU = (M.N+kk)*S.lag;
% La demanda entra en la historia AL PRINCIPIO del instante ---ldc(t) ya se
% conoce cuando se calcula u(t)---, asi que su historia es un periodo de
% modelo mas larga que la de los mandos.
nD = (M.N+kk)*S.lag + 1;

% ARRANQUE.  El articulo no tiene periodo de calentamiento: dice que la
% historia inicial son los valores de estado estable
%
%   «x(0-k) contained steady state values of inputs and outputs at the
%    constant load level»
%
% y en variables incrementales eso es CERO.  Como las dos pruebas empiezan
% justamente en un estado estable, el primer mando sale exactamente igual a
% u_ss y no hay salto: el controlador manda desde t = 0, que es lo que se ve
% en su figura 6.  Esperar N periodos con el PI al mando ---modo 'espera'---
% no esta en el articulo y ademas deja al estimador 100 s de datos en lazo
% cerrado con el PI antes de empezar.  Se conserva como opcion para poder
% ensenar la diferencia, pero NO es la replica.
switch lower(opt.arranque)
  case 'estable'
    S.Yh = zeros(M.ny, nY);
    S.Uh = zeros(M.nu, nU);
    S.Dh = zeros(M.nd, nD);
  case 'espera'
    S.Yh = nan(M.ny, nY);
    S.Uh = nan(M.nu, nU);
    S.Dh = nan(M.nd, nD);
  otherwise
    error('amin_stc_init:arranque', ...
          'arranque desconocido: %s  (''estable'' o ''espera'')', opt.arranque);
end
S.arranque = lower(opt.arranque);
S.nc = 0;                            % instantes de control cumplidos
S.log = struct('upd', [], 'condB0', [], 'nc', 0);
end
