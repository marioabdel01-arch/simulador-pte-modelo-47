function L = amin_resumen(OUT, arch)
%AMIN_RESUMEN  El informe de texto de la replica.
%
%   L = AMIN_RESUMEN(OUT)
%   L = AMIN_RESUMEN(OUT, 'resultados/amin_resumen.txt')
%
%   Pone en una sola pagina lo que el articulo afirma y lo que la replica
%   midio, uno al lado del otro.  Es lo que se le ensena al tutor: la
%   comparacion, no las cifras sueltas.
%
%   See also AMIN_MAIN.

if nargin < 2, arch = ''; end
L = {};
p = @(varargin) sjoin_(varargin{:});

L{end+1} = 'REPLICA DE AMIN, MASADA Y WOMACK (1984)';
L{end+1} = 'Application of a Multivariable Self-Tuning Controller to a Power Plant Boiler';
L{end+1} = 'American Control Conference 1984, WP3 4:00, pp. 339-346';
L{end+1} = '';
L{end+1} = 'Planta: modelo de 47 estados de Usoro (1977), 600 MW, combustoleo.';
L{end+1} = 'Es LA MISMA planta del articulo, no una equivalente.';
L{end+1} = '';
L{end+1} = repmat('=',1,78);
L{end+1} = 'SECCION IV - IDENTIFICACION';
L{end+1} = repmat('=',1,78);
L{end+1} = '';
L{end+1} = 'concepto                          articulo            esta replica';
L{end+1} = repmat('-',1,78);

if isfield(OUT,'retardos')
    L{end+1} = p('retardo maximo                    20 s (CWSY-TRHO)    %.1f s (%s-%s)', ...
                 OUT.retardos.tauMax, nomMax_(OUT.retardos));
    L{end+1} = p('retardo k con T = 20 s            1                   %d', OUT.retardos.k20);
end
if isfield(OUT,'espectro')
    L{end+1} = p('limite del periodo de muestreo    75 s (1,25 min)     %.1f s', ...
                 OUT.espectro.TmaxGlobal);
end
if isfield(OUT,'limites')
    L{end+1} = p('limite de fluctuacion CBMD        0,10                %.2f', OUT.limites.limite(1));
    L{end+1} = p('limite de fluctuacion CXGG        0,30                %.2f', OUT.limites.limite(2));
    L{end+1} = p('limite de fluctuacion CWSY        0,60                %.2f', OUT.limites.limite(3));
end
if isfield(OUT,'datos')
    L{end+1} = p('corridas de identificacion        10 x 400 s          %d x %g s', ...
                 numel(OUT.datos.run), OUT.datos.dur);
    L{end+1} = p('nivel de carga                    75 %%                %g %%', OUT.datos.pct);
end
if isfield(OUT,'M')
    L{end+1} = p('orden del modelo AR               5                   %d', OUT.M.N);
    L{end+1} = p('parametros por fila               33                  %d', OUT.M.npar);
    if isfield(OUT.M,'nd') && OUT.M.nd > 0
        L{end+1} = p('estructura del modelo             3x3 (u -> y)        %s  (+ ldc: NO ES DEL ARTICULO)', ...
                     OUT.M.estructura);
    end
end

if isfield(OUT,'tablaN')
    T = OUT.tablaN;
    L{end+1} = '';
    L{end+1} = 'Eleccion del orden, «the best prediction of the outputs»:';
    L{end+1} = '';
    L{end+1} = p('criterio «%s», %d corridas apartadas para medirlo', ...
                 T.criterio, T.holdout);
    L{end+1} = '';
    L{end+1} = ['   N  npar   1 paso dentro   1 paso fuera   simul. libre   ' ...
                '|z|max   cond(B0)'];
    for q = 1:numel(T.N)
        L{end+1} = p('  %2d  %4d %14.2f %14.2f %14.2f %9.4f %10.3g', ...
                     T.N(q), T.npar(q), mean(T.aj_dentro(q,:)), ...
                     mean(T.aj_fuera(q,:)), mean(T.aj_libre(q,:)), ...
                     T.zmax(q), T.condB0(q));
    end
    if isfield(T,'empatan')
        L{end+1} = '';
        L{end+1} = p('elegido N = %d;  dentro de 1 punto del mejor quedan N = %s', ...
                     T.elegido, mat2str(T.empatan(:).'));
        L{end+1} = p('el criterio separa %.2f puntos en todo el rango de ordenes', ...
                     T.rango);
        if numel(T.empatan) > 1
            L{end+1} = 'EL CRITERIO DEL ARTICULO NO DETERMINA EL ORDEN: varios ordenes';
            L{end+1} = 'quedan empatados dentro del ruido y el N = 5 de Amin esta entre';
            L{end+1} = 'ellos.  La replica no contradice su eleccion: la respalda.';
        end
    end
end

L{end+1} = '';
L{end+1} = repmat('=',1,78);
L{end+1} = 'SECCION V - APLICACION';
L{end+1} = repmat('=',1,78);
L{end+1} = '';
if isfield(OUT,'lambdaUsada')
    L{end+1} = p('lambda del coste (2):  %g', OUT.lambdaUsada);
    L{end+1} = 'EL ARTICULO NO DA ESTE VALOR.  Es una eleccion de la replica.';
end
if isfield(OUT,'lambda')
    Q = OUT.lambda;
    L{end+1} = '';
    L{end+1} = 'CALIBRACION DE lambda Y beta CONTRA LAS FIGURAS 6a/6b.';
    L{end+1} = 'El articulo no da ninguno de los dos.  Lo que sigue es la';
    L{end+1} = 'distancia relativa entre el error maximo simulado y el leido';
    L{end+1} = 'sobre sus graficas impresas; la eleccion es de esta replica.';
    L{end+1} = '';
    L{end+1} = p('objetivo leido  90->70:  %.0f R  %.0f R  %.0f psia', Q.objetivo(1,:));
    L{end+1} = p('objetivo leido  70->90:  %.0f R  %.0f R  %.0f psia', Q.objetivo(2,:));
    L{end+1} = '';
    cab = sprintf('%10s', 'lambda\beta');
    for b = 1:numel(Q.beta), cab = [cab sprintf(' %9.3f', Q.beta(b))]; end %#ok<AGROW>
    L{end+1} = cab;
    for q = 1:numel(Q.lam)
        fila = sprintf('%10.2f', Q.lam(q));
        for b = 1:numel(Q.beta)
            fila = [fila sprintf(' %9.3f', Q.dist(q,b))]; %#ok<AGROW>
        end
        L{end+1} = fila;
    end
    L{end+1} = '';
    L{end+1} = p('elegidos:  lambda = %g,  beta = %g', Q.elegida, Q.elegidaBeta);
    L{end+1} = p('saturacion en ese punto: %.0f %% de los instantes de control', ...
                 100*max(Q.sat(Q.lam == Q.elegida, Q.beta == Q.elegidaBeta, :)));
end

if isfield(OUT,'TB')
    L{end+1} = '';
    L{end+1} = 'Tabla de parametros por nivel de carga (seccion V):';
    L{end+1} = '';
    L{end+1} = '  carga    actualizaciones   |z|max    cond(B0)   |dtheta|/|theta0|';
    for q = 1:numel(OUT.TB.pct)
        if isfield(OUT.TB,'dth'), d = OUT.TB.dth(q); else, d = NaN; end
        L{end+1} = p('  %5.1f %%  %10d %12.4f %11.3g %14.2e', OUT.TB.pct(q), ...
                     OUT.TB.nupd(q), OUT.TB.zmax(q), OUT.TB.condB0(q), d);
    end
    L{end+1} = '';
    L{end+1} = 'A carga constante NO hay excitacion, asi que |dtheta| dice si el';
    L{end+1} = 'procedimiento de la seccion V identifica algo o si solo recoloca el';
    L{end+1} = 'punto de operacion (u_ss, y_ss) del mismo modelo.';
end

if isfield(OUT,'R')
    R = OUT.R;
    L{end+1} = '';
    L{end+1} = 'Error maximo respecto de la consigna (TSSO R, TRHO R, PSSO psia):';
    for q = 1:2
        L{end+1} = '';
        L{end+1} = p('  prueba %s    (10 %%/min)', R.prueba(q).nombre);
        L{end+1} = ['    controlador        TSSO      TRHO      PSSO' ...
                    '        IAE TSSO      TRHO      PSSO'];
        f = fieldnames(R.prueba(q).ctrl);
        for r = 1:numel(f)
            C = R.prueba(q).ctrl.(f{r});
            if isfield(C,'iae'), ia = C.iae; else, ia = nan(1,3); end
            L{end+1} = p('    %-14s %9.2f %9.2f %10.2f %11.3g %9.3g %9.3g', ...
                         f{r}, C.emax, ia);
        end
    end
    L{end+1} = '';
    L{end+1} = 'El IAE no es del articulo ---el solo ensena figuras--- pero hace falta:';
    L{end+1} = 'dos configuraciones pueden empatar en error maximo si el pico ocurre en';
    L{end+1} = 'el transitorio y diferir por completo en lo que pasa despues.';
    L{end+1} = '';
    L{end+1} = 'Las tres afirmaciones del articulo, para contrastarlas:';
    L{end+1} = '';
    L{end+1} = '  1. «Fluctuations of the outputs while in the transient mode using the';
    L{end+1} = '      self-tuning controller are comparable or sometimes larger than the';
    L{end+1} = '      fluctuations resulting from the PI controllers.»';
    L{end+1} = '     -> comparar las filas  pi  y  stc.';
    L{end+1} = '';
    L{end+1} = '  2. «relatively small deviations from the set points are possible if the';
    L{end+1} = '      estimator can track the changing parameters of the system.»';
    L{end+1} = '     -> comparar  stc  con  mstc20.';
    L{end+1} = '';
    L{end+1} = '  3. «reducing the time interval between the successive control';
    L{end+1} = '      calculations will not reduce the deviations of the outputs.»';
    L{end+1} = '     -> comparar  mstc20  con  mstc2.';
end

L{end+1} = '';
L{end+1} = 'Los huecos del articulo que esta replica ha tenido que rellenar estan';
L{end+1} = 'listados en el README de esta carpeta.  Ninguno se ha ocultado.';

if ~isempty(arch)
    d = fileparts(arch);
    if ~isempty(d) && exist(d,'dir') ~= 7, mkdir(d); end
    fid = fopen(arch, 'w');
    if fid > 0
        for i = 1:numel(L), fprintf(fid, '%s\n', L{i}); end
        fclose(fid);
    end
end
end

% =========================================================================
function s = sjoin_(varargin)
s = sprintf(varargin{:});
end

% =========================================================================
function [a, b] = nomMax_(D)
[~, j] = max(D.tau(:));
[r, c] = ind2sub(size(D.tau), j);
a = D.nomU{c};  b = D.nomY{r};
end
