function M = amin_tabla_en(TB, pct)
%AMIN_TABLA_EN  Modelo de la tabla por carga INTERPOLADO a una carga dada.
%
%   M = AMIN_TABLA_EN(TB, PCT)
%
%   Para la prueba con demanda real (AMIN_DEMANDA).  Entre los dos nodos
%   vecinos de la tabla (70, 75, ..., 90 %) se interpolan linealmente con la
%   carga theta, el punto de operacion (u_ss, y_ss) y, en el 3x4, d_ss.
%   Fuera de 70-90 % se usa el nodo extremo.
%
%   POR QUE NO EL NODO MAS CERCANO.  Con la regla de la seccion V (conmutar
%   en los puntos medios) cada cambio de nodo hace saltar u_ss ---la demanda
%   maestra CBMD, unos 0,15 V---.  En las rampas del articulo, a 10 %/min,
%   ese salto queda dentro del transitorio; con la carga lenta de un dia real
%   (0,1 %/min o menos) da golpes de unos 40 psia y satura los mandos en cada
%   conmutacion.  Interpolando, el punto de operacion se mueve con la carga.
%
%   See also AMIN_STC_INTERP, AMIN_DEMANDA, AMIN_NODO.

p = TB.pct(:).';  n = numel(p);
i = 1;
while i < n - 1 && pct > p(i+1), i = i + 1; end
a = min(1, max(0, (pct - p(i))/(p(i+1) - p(i))));
A = TB.M(i);  B = TB.M(i+1);
mez = @(x, y) x + a*(y - x);
th = mez(A.th, B.th);
if isfield(A,'nd') && A.nd > 0
    M = amin_modelo(th, A.N, A.nu, A.ny, A.k, A.T, mez(A.u_ss, B.u_ss), ...
                    mez(A.y_ss, B.y_ss), pct, mez(A.d_ss, B.d_ss));
else
    M = amin_modelo(th, A.N, A.nu, A.ny, A.k, A.T, mez(A.u_ss, B.u_ss), ...
                    mez(A.y_ss, B.y_ss), pct);
end
end
