function ok = amin_misma_huella(h1, h2)
%AMIN_MISMA_HUELLA  ¿Es la tabla por carga H1 del mismo modelo que H2?
%
%   OK = AMIN_MISMA_HUELLA(TB.huella, struct('N',M.N,'npar',M.npar,
%                                            'th',sum(abs(M.th(:)))))
%
%   N y npar tienen que coincidir exactos; la suma de |theta| con tolerancia
%   relativa de 1e-12.  Compararla con ISEQUAL, como se hacia, falla por el
%   ultimo bit cuando la tabla se guardo en MATLAB y se lee en Octave (o al
%   reves): las dos suman en distinto orden.  Medido: 705,36163003010086
%   contra 705,36163003010063, y la tabla buena se descartaba.
%
%   See also AMIN_TABLA, AMIN_SIM.

ok = isstruct(h1) && isstruct(h2) && ...
     all(isfield(h1, {'N','npar','th'})) && all(isfield(h2, {'N','npar','th'})) && ...
     h1.N == h2.N && h1.npar == h2.npar && ...
     abs(h1.th - h2.th) <= 1e-12*max(abs(h2.th), 1);
end
