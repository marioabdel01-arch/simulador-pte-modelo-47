function W = amin_fig_windup(varargin)
%AMIN_FIG_WINDUP  La prueba 77,5 -> 100 % de Usoro con y sin el recorte de
%   integradores (articulo CITCA/TyCAP, Fig. 2).
%
%   W = AMIN_FIG_WINDUP
%
%   En el FORTRAN de Usoro las variables de control vivian en COMMON y la
%   rutina de limites recortaba el estado mismo: el integrador del PI de
%   presion (c3md, estado 23) nunca pasaba de 5 V.  En la primera version en
%   MATLAB el limite solo recortaba una copia local y la derivada seguia
%   integrando.  Aqui se corre la prueba 4 de Usoro (77,5 -> 100 % a
%   15 %/min, 700 s, RK4 a 0,1 s) dos veces: con PTE47_CLAMP despues de
%   cada paso (la planta corregida) y sin el (la version inicial).
%
%   DEVUELVE  W.t, W.c3md (2 x n: con, sin), W.psso (2 x n), mas los
%   resumenes W.c3mdMax (sin recorte), W.pssoFin (con, sin) y W.tDespega
%   (cuando la demanda maestra sale de la saturacion con el recorte).
%
%   See also PTE47_CLAMP, DIGPTE47.

opt = struct('dur',700, 'cada',10);
for i = 1:2:numel(varargin), opt.(varargin{i}) = varargin{i+1}; end

Ts = 0.1;  n = round(opt.dur/Ts);
P = pte47_params('775', 'ldcStart',3.875, 'ldcRate',0.0125, ...
                 'ldcT0',10, 'ldcT1',100, 'samples',n+1);
nl = floor(n/opt.cada) + 1;
W = struct('t',(0:nl-1)*opt.cada*Ts, 'c3md',zeros(2,nl), 'psso',zeros(2,nl));
for caso = 1:2                         % 1 = con recorte, 2 = sin recorte
    x = P.x0(:);  t = 0;  l = 1;
    W.c3md(caso,l) = x(23);  W.psso(caso,l) = shstat(x(10), x(11));
    for i = 1:n
        xd1 = digpte47(t,      x,             P);
        xd2 = digpte47(t+Ts/2, x+(Ts/2)*xd1,  P);
        xd3 = digpte47(t+Ts/2, x+(Ts/2)*xd2,  P);
        xd4 = digpte47(t+Ts,   x+Ts*xd3,      P);
        x = x + (Ts/6)*(xd1 + 2*xd2 + 2*xd3 + xd4);
        if caso == 1, x = pte47_clamp(x, P); end
        t = t + Ts;
        if mod(i, opt.cada) == 0
            l = l + 1;
            W.c3md(caso,l) = x(23);  W.psso(caso,l) = shstat(x(10), x(11));
        end
    end
end
W.c3mdMax  = max(W.c3md(2,:));
W.pssoFin  = W.psso(:,end).';
j = find(W.c3md(1,:) < 4.999 & W.t > 150, 1);
if isempty(j), W.tDespega = NaN; else, W.tDespega = W.t(j); end
end
