function [i, pct] = amin_nodo(TB, ldc)
%AMIN_NODO  El nodo de la tabla por carga que toca para una demanda dada.
%
%   [I, PCT] = AMIN_NODO(TB, LDC)
%
%   Redondear al nodo de 5 % mas cercano es exactamente la regla de la
%   seccion V del articulo:
%
%     «the set of parameters that was obtained for the 70% load was used
%      until the load reached 72.5% after which the controller switched to
%      the set of parameters that was identified for 75% load.  This set of
%      parameters was used until the load reached 77.5% and at this point
%      the set of parameters obtained for 80% load was used until the 82.5%
%      load was reached.»
%
%   O sea: conmutar en los puntos medios entre nodos.
%
%   See also AMIN_TABLA, AMIN_LAZO, AMIN_SIM.

pct = ldc/0.05;
[~, i] = min(abs(TB.pct - pct));
end
