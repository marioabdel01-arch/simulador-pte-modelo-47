function amin_sim()
%AMIN_SIM  Simulador interactivo de la replica de Amin et al. (1984).
%
%   >> INICIO                  desde la carpeta de la replica, o
%   >> amin_sim                desde la carpeta codigo
%
%   No hace falta ningun paso previo (setup_amin, verifica_amin, ...): el
%   simulador pone en la ruta el codigo y el modelo de la planta, y usa el
%   modelo AR y la tabla por carga que ya estan calculados en datos/.
%
%   Abre una ventana donde se elige una de las dos pruebas del articulo y uno
%   de sus cuatro controladores, y la planta de 47 estados se simula EN VIVO.
%
%   POR QUE ESTE SIMULADOR ES DISTINTO DE LOS DEL RESTO DE LA TESIS
%
%   Los simuladores de `2-identificacion`, `3-estimacion-en-linea` y
%   `6-sintesis` ensenan LOS RESULTADOS DE ESTA TESIS.  Este ensena el
%   trabajo de Amin, y por eso sus mandos son otros:
%
%     * LAMBDA es un cuadro editable, porque el articulo NO PUBLICA su valor
%       y todo lo que se concluya depende de el.  Moverlo en vivo es la forma
%       mas rapida de ver cuanto.
%
%     * LA LEY SE PUEDE CORRER EN SUS DOS VERSIONES: la corregida y la que
%       esta IMPRESA en la pagina 344, que lleva una errata de signo.  El
%       desplegable las alterna y la lectura avisa cual esta puesta.
%
%     * cond(B0) SE DIBUJA, porque el articulo justifica con el su negativa a
%       bajar de T = 20 s: «A smaller sampling period will cause the
%       coefficient matrix B0 to become singular».
%
%     * EL NODO ACTIVO DE LA TABLA POR CARGA se ve en su propia pestana, que
%       es la unica forma de comprobar que la conmutacion ocurre en los
%       puntos medios que describe la seccion V.
%
%     * LA COVARIANZA DEL ESTIMADOR P(t) tiene su pestana: traza y valores
%       propios extremos, en escala logaritmica.  Es donde se ve si el
%       estimador se queda sin informacion ---con beta < 1 y poca
%       excitacion P crece como beta^-t («windup» de la covarianza)--- o si
%       la tiene de sobra (P se contrae y el estimador deja de moverse).
%
%     * EL MODELO SE ELIGE: 3x3, el del articulo (u -> y), o 3x4, con la
%       demanda de carga ldc como cuarta entrada medida.  El 3x4 NO ES DEL
%       ARTICULO: la ley usa ldc como prealimentacion (ver AMIN_STC) y el
%       estimador tiene 39 parametros por fila en vez de 33.  Cada modelo
%       tiene su propia tabla por carga.  Todo lo demas ---pruebas,
%       controladores, lambda, beta, la ley--- se elige igual con los dos, y
%       asi la comparacion es de una sola cosa.
%
%   LA VENTANA.  A la izquierda, que simular, la marcha (con barra de avance
%   y la fase en color) y el estado del controlador.  A la derecha, las
%   graficas: la pestana «Resumen» tiene la disposicion de las Figs. 6-8 del
%   articulo (arriba TSSO, TRHO y PSSO con su consigna; abajo CBMD, CXGG y
%   CWSY en escalones; el PI de Usoro de fondo en las seis), con sus escalas
%   y sus colores: PI de Usoro gris, controlador naranja.  La pestana
%   «Planta» muestra el esquema de la unidad de 600 MW con los valores del
%   modelo encima, al estilo del simulador de Galindo (2001): volumen de agua
%   del domo, temperaturas, presion, velocidades, potencia, mandos, demanda
%   y apertura de valvulas (imagen en codigo/esquema_planta.png).  Las otras
%   ocho pestanas detallan cada cosa y son las que van al PDF.  Las
%   pestanas TSSO y TRHO llevan debajo de la temperatura la ENTALPIA del
%   vapor (HSSO, HRHO, en BTU/lb), que es el estado que integra el modelo de
%   Usoro y la variable que el grafica en su capitulo V: la temperatura sale
%   de ella y de la densidad con SHSTAT / RHSTAT.  La pestana «Mandos» tiene
%   un eje por mando y, debajo, la demanda de carga.  Debajo,
%   la LECTURA: una tabla con y, w, y - w, IAE, ITAE y los cocientes contra
%   el PI de Usoro y contra la referencia (verde < 1, rojo > 1).  Las
%   escalas son las del articulo desde antes de correr.  Pasando el raton
%   por las etiquetas se ve la explicacion de cada opcion.
%
%   NO REIMPLEMENTA NADA.  El instante de control lo calcula AMIN_STC, el
%   mismo codigo que usan AMIN_LAZO y AMIN_RUN; el integrador es el mismo
%   Runge-Kutta de paso fijo 0,1 s.  Si una cifra de aqui no coincide con la
%   de AMIN_RUN, el fallo esta en este archivo y no en el lazo.
%
%   QUE HACE FALTA ANTES
%
%     el modelo AR      datos/amin_modelo.mat   lo crea AMIN_MAIN (pasos 4-5)
%     la tabla por carga datos/amin_tabla.mat   lo crea AMIN_MAIN (paso 7)
%
%     y para el 3x4      datos/amin_modelo_ldc.mat, datos/amin_tabla_ldc.mat
%                        AMIN_MAIN('modelo','3x4')
%     con k = 2          los mismos nombres con sufijo _k2 (AMIN_SUFIJO)
%
%   EL RETARDO k SE ELIGE: 1, el del articulo (su retardo mayor, 20 s, cabe
%   en un periodo de 20 s), o 2, el que sale con la regla del articulo del
%   retardo mayor MEDIDO en esta replica (CXGG -> TSSO, 34,6 s; ver
%   AMIN_RETARDOS).  El modelo se identifica en forma predictora,
%   y(t) = theta x(t-k), sobre LOS MISMOS datos, y la ley no cambia: pone
%   y*(t+k|t) = w (ver AMIN_IDENT).  Cada combinacion modelo x k tiene su
%   modelo y su tabla por carga.
%
%   Si falta el modelo, el simulador ofrece identificarlo ahi mismo.  Si falta
%   la tabla, las dos configuraciones «modificadas» quedan deshabilitadas y se
%   dice por que.
%
%   See also AMIN_MAIN, AMIN_RUN, AMIN_LAZO, AMIN_STC.

raiz_ = fileparts(fileparts(mfilename('fullpath')));
if isempty(raiz_), raiz_ = pwd; end
if exist(fullfile(pwd,'codigo','amin_stc.m'),'file') == 2, raiz_ = pwd; end
if exist(fullfile(raiz_,'datos'),'dir') ~= 7, mkdir(fullfile(raiz_,'datos')); end
% El simulador trabaja con rutas relativas (datos/, resultados/) y por eso
% se coloca en la raiz de la replica mientras lee o escribe; al terminar
% cada operacion vuelve a la carpeta desde la que se llamo (ENRAIZ_), para
% que quien lo abre con INICIO siga viendo su carpeta.
origen_ = pwd;
if ~strcmp(pwd, raiz_), cd(raiz_); end
% La ruta la pone el propio simulador: se puede abrir sin SETUP_AMIN.
addpath(fullfile(raiz_,'codigo'), fullfile(raiz_,'planta','codigo'), ...
        fullfile(raiz_,'planta','funciones'));

st = struct();
st.raiz = raiz_;
st.pruebaNom = { ...
    '90 → 70 %', ...
    '70 → 90 %', ...
    '75 %', ...
    'Demanda SIN: jueves 20/08/2026 (pico)', ...
    'Demanda SIN: miércoles 11/03/2026', ...
    'Demanda SIN: domingo 18/01/2026'};
st.pruebaPct = {[90 70], [70 90], [75 75], [70 70], [70 70], [70 70]};
% Prueba con demanda real del SIN (CENACE): 24 h en tiempo real, escalada de
% 70 a 90 % (AMIN_DEMANDA).  Vacio = rampas del articulo.
st.pruebaDia = {'', '', '', 'd1', 'd2', 'd3'};
st.ctrlNom = { ...
    'PI de Usoro', ...
    'Autosintonizable', ...
    'Modificado, mando 20 s', ...
    'Modificado, mando 2 s', ...
    'Tabla, estimador apagado  (**)'};
st.ctrlAyuda = ['Modificado: tabla por carga + estimador congelado durante el ' ...
    'transitorio y 130 s más (sección V).  * El artículo describe este caso ' ...
    'pero no publica sus figuras.  ** No es del artículo: la tabla sin reidentificar nunca.'];
% Renglones de la Tabla 4: los controladores 2 y 3 de CTRLNOM, los del
% articulo.  El de 2 s y la tabla pura no entran.
st.compNom = {'STC','STC modificado'};
st.modNom = { ...
    '3×3', ...
    '3×4'};
st.kNom = { ...
    'k = 1', ...
    'k = 2'};
st.leyNom = { ...
    'corregida', ...
    'impresa'};

st.M = [];  st.TB = [];
st.dia = '';  st.interp = false;  st.gmov = [];
st.Mm = cell(2,2);  st.TBm = cell(2,2);    % {3x3 | 3x4,  k = 1 | 2}
st.baseAll = struct();
st.running = false;  st.armed = false;  st.stopReq = false;
st.ref = [];  st.k = 0;
st.comp = comp_vacia_();          % la Tabla 4: ver COMP_GUARDA_

st = construye_ui_(st);
pinta_comp_(st);
st = carga_modelo_(st, false);
guardar_(st.fig, st);
cd(origen_);
end

% =========================================================================
function c = enraiz_(st)
%ENRAIZ_  Se coloca en la raiz de la replica.  Devuelve un objeto que, al
%   salir de la funcion que lo llamo, devuelve a la carpeta anterior.
antes = pwd;
if ~strcmp(antes, st.raiz), cd(st.raiz); end
c = onCleanup(@() cd(antes));
end

% =========================================================================
function st = construye_ui_(st)
C = paleta_();
st.C = C;

% La ventana se ajusta a la pantalla: en una laptop de 1366 x 768 cabe
% entera y en una de 1920 x 1080 aprovecha el espacio.
scr = get(groot,'ScreenSize');
W = max(1100, min(1480, scr(3) - 60));
H = max(680,  min(920,  scr(4) - 90));
x0 = max(10, round((scr(3) - W)/2));
y0 = max(40, round((scr(4) - H)/2));
st.fig = uifigure('Name', ...
    'Simulador Planta Termoeléctrica modelo de orden 47', ...
    'Position',[x0 y0 W H], 'Color',C.fondo);
st.fig.CloseRequestFcn = @(s,e) cerrar_(s);

G = uigridlayout(st.fig, [1 2]);
G.ColumnWidth = {335, '1x'};
G.RowHeight   = {'1x'};
G.Padding = [10 10 10 10];
G.ColumnSpacing = 10;

% ---------------------------------------------------------------------------
% COLUMNA IZQUIERDA: que simular, marcha y estado del controlador.  Es
% desplazable por si la pantalla es baja.
L = uigridlayout(G, [3 1]);
L.RowHeight = {'fit','fit','1x'};
L.Padding = [0 0 0 0];  L.RowSpacing = 10;
try L.Scrollable = 'on'; catch, end

% ---------------------------------------------------- que simular --------
p1 = uipanel(L,'Title','Qué simular','FontWeight','bold', ...
             'BackgroundColor',C.panel);
g1 = uigridlayout(p1,[11 2]);
g1.RowHeight   = repmat({'fit'},1,11);
g1.ColumnWidth = {78,'1x'};
g1.Padding = [10 8 10 8];  g1.RowSpacing = 6;  g1.ColumnSpacing = 8;

et_(g1,'Prueba', ['Las dos rampas del artículo, al 10 %/min, el 75 % constante y tres ' ...
    'días de demanda real del SIN (CENACE), 24 h en tiempo real, escalados de 70 a 90 %.']);
st.ddPrueba = uidropdown(g1,'Items',st.pruebaNom,'Value',st.pruebaNom{1}, ...
                         'ValueChangedFcn',@(s,e) cambio_(s));

et_(g1,'Controlador', st.ctrlAyuda);
st.ddCtrl = uidropdown(g1,'Items',st.ctrlNom,'Value',st.ctrlNom{2}, ...
                       'ValueChangedFcn',@(s,e) cambio_(s));
tip_(st.ddCtrl, st.ctrlAyuda);

% EL MODELO.  3x3 es el del articulo; 3x4 mete la demanda de carga medida
% como cuarta entrada.  Cambiarlo cambia el modelo Y la tabla por carga.
et_(g1,'Modelo ARX', ['3×3: u → y, el del artículo.  3×4: ldc como cuarta ' ...
    'entrada medida y prealimentada (NO es del artículo).']);
st.ddMod = uidropdown(g1,'Items',st.modNom,'Value',st.modNom{1}, ...
                      'ValueChangedFcn',@(s,e) cambioModelo_(s));

% EL RETARDO.  k = 1 es el del articulo; k = 2 el de la regla del articulo
% aplicada al retardo mayor medido en la replica.  Mismos datos, otro modelo.
et_(g1,'Retardo k', ['Periodos de 20 s.  k = 1: el del artículo (retardo máx. ' ...
    '20 s).  k = 2: el retardo máx. medido en esta réplica (34,6 s).']);
st.ddK = uidropdown(g1,'Items',st.kNom,'Value',st.kNom{1}, ...
                    'ValueChangedFcn',@(s,e) cambioModelo_(s));

% LAMBDA.  El articulo dice Q'(q^-1) = sqrt(lambda) I y NO da el valor.  Por
% eso esta aqui arriba y editable: es el grado de libertad que decide el
% resultado y que hay que declarar al reportarlo.
et_(g1,'λ', 'Ponderación del mando, Q'' = √λ·I.  EL ARTÍCULO NO DA SU VALOR.');
st.efLam = uieditfield(g1,'numeric','Value',0.5,'Limits',[0 inf], ...
                       'ValueChangedFcn',@(s,e) cambio_(s));
tip_(st.efLam, 'El artículo no da su valor.  La réplica usa 0,5.');

et_(g1,'β', 'Factor de olvido del estimador (15).  Tampoco lo da el artículo.');
st.efBeta = uieditfield(g1,'numeric','Value',0.99,'Limits',[0.5 1], ...
                        'ValueChangedFcn',@(s,e) cambio_(s));

et_(g1,'Ley', ['Corregida: consistente con la ec. (16).  Impresa: la de la ' ...
    'p. 344, con la errata de signo en el bloque de salidas.']);
st.ddLey = uidropdown(g1,'Items',st.leyNom,'Value',st.leyNom{1}, ...
                      'ValueChangedFcn',@(s,e) cambio_(s));

et_(g1,'Duración', '800 s es la duración de las figuras del artículo.');
st.ddDur = uidropdown(g1, ...
    'Items',{'800 s  (artículo)','1600 s','2400 s'}, ...
    'ItemsData',[800 1600 2400], 'Value',800, ...
    'ValueChangedFcn',@(s,e) cambio_(s));

st.chkBase = uicheckbox(g1,'Text','Dibujar el PI de Usoro de fondo', ...
                        'Value',true,'FontColor',C.tenue);
st.chkBase.Layout.Column = [1 2];

st.lblMod = uilabel(g1,'Text','modelo: —','FontColor',C.tenue, ...
                    'WordWrap','on','FontSize',11);
st.lblMod.Layout.Column = [1 2];

st.btMod = uibutton(g1,'Text','Identificar el modelo ahora…', ...
                    'ButtonPushedFcn',@(s,e) identificar_(s));
st.btMod.Layout.Column = [1 2];

% ---------------------------------------------------------- marcha -------
p2 = uipanel(L,'Title','Marcha','FontWeight','bold', ...
             'BackgroundColor',C.panel);
g2 = uigridlayout(p2,[7 2]);
g2.RowHeight   = {'fit','fit','fit','fit',8,'fit','fit'};
g2.ColumnWidth = {'1x','1x'};
g2.Padding = [10 8 10 8];  g2.RowSpacing = 6;  g2.ColumnSpacing = 8;

uilabel(g2,'Text','Velocidad','FontColor',C.tenue);
st.ddVel = uidropdown(g2, ...
    'Items',{'1x  (tiempo real)','5x','20x','200x','2000x','máxima'}, ...
    'ItemsData',[1 5 20 200 2000 inf], 'Value',20);

st.btIni = uibutton(g2,'Text','Iniciar','FontWeight','bold', ...
                    'BackgroundColor',C.acento,'FontColor','w', ...
                    'ButtonPushedFcn',@(s,e) alternar_(s));
st.btLim = uibutton(g2,'Text','Limpiar', ...
                    'ButtonPushedFcn',@(s,e) limpiar_(s));

st.btEnc = uibutton(g2,'Text','Encuadrar', ...
                    'ButtonPushedFcn',@(s,e) encuadrar_(s));
tip_(st.btEnc, 'Vuelve a las escalas del artículo, ensanchadas si alguna curva se sale.');
st.btFij = uibutton(g2,'Text','Fijar referencia', ...
                    'ButtonPushedFcn',@(s,e) fijar_(s));
tip_(st.btFij, 'Guarda esta corrida en verde para compararla con la siguiente.');

st.btPdf = uibutton(g2,'Text','Exportar PDF', ...
                    'ButtonPushedFcn',@(s,e) pdf_(s));
st.chkPdf = uicheckbox(g2,'Text','PDF al terminar','Value',false, ...
                       'FontColor',C.tenue);

% Barra de avance: dos paneles en una rejilla cuyos anchos relativos se
% cambian con el tiempo simulado (ver PROGRESO_).
st.gBar = uigridlayout(g2,[1 2]);
st.gBar.Layout.Column = [1 2];
st.gBar.Padding = [0 0 0 0];  st.gBar.ColumnSpacing = 0;  st.gBar.RowSpacing = 0;
st.gBar.RowHeight = {'1x'};
st.gBar.ColumnWidth = {0,'1x'};
uipanel(st.gBar,'BackgroundColor',C.acento,'BorderType','none');
uipanel(st.gBar,'BackgroundColor',C.riel,'BorderType','none');

st.lblFase = uilabel(g2,'Text','listo','FontWeight','bold','FontColor','w', ...
                     'BackgroundColor',C.listo,'HorizontalAlignment','center');
st.lblFase.Layout.Column = [1 2];

st.lblEstado = uilabel(g2,'Text','','FontColor',C.tenue,'WordWrap','on', ...
                       'FontSize',11);
st.lblEstado.Layout.Column = [1 2];

% ------------------------------------------- estado del controlador -----
p3 = uipanel(L,'Title','Estado del controlador','FontWeight','bold', ...
             'BackgroundColor',C.panel);
g3 = uigridlayout(p3,[1 1]);
g3.Padding = [6 6 6 6];
st.tabE = uitable(g3, 'ColumnName',{}, 'RowName',{}, ...
                  'Data',estado_vacio_(), 'ColumnWidth',{118,'auto'}, ...
                  'FontSize',11);

% ---------------------------------------------------------------------------
% COLUMNA DERECHA: las graficas y, debajo, la lectura de salidas e indices.
R = uigridlayout(G, [2 1]);
R.RowHeight = {'1x', 150};
R.Padding = [0 0 0 0];  R.RowSpacing = 10;

st.grupo = uitabgroup(R);

% RESUMEN, CON LA DISPOSICION DEL ARTICULO (Figs. 6-8): arriba las tres
% salidas con su consigna, abajo los tres mandos en escalones, y en las seis
% el PI de Usoro de fondo.  Mismas escalas, mismos colores (PI gris,
% controlador naranja, consigna negra discontinua) y una leyenda
% comun arriba.  Las pestanas individuales siguen: ocupan la ventana entera,
% llevan lo que el resumen no (entalpias, demanda de carga) y van al PDF.
st.tabRes = uitab(st.grupo,'Title','Resumen');
gr = uigridlayout(st.tabRes,[3 3]);
gr.RowHeight = {'fit','1x','1x'};
gr.ColumnWidth = {'1x','1x','1x'};
gr.Padding = [6 6 6 6];  gr.RowSpacing = 4;  gr.ColumnSpacing = 6;
st.lblLeyR = uilabel(gr,'Text','','HorizontalAlignment','center','FontSize',12);
st.lblLeyR.Layout.Row = 1;  st.lblLeyR.Layout.Column = [1 3];
try st.lblLeyR.Interpreter = 'html'; catch, end
tr = {'TSSO','TRHO','PSSO'};          yr = {'°R','°R','psia'};
tu = {'CBMD','CXGG','CWSY'};
st.axR  = gobjects(1,3);
st.axRU = gobjects(1,3);
for k = 1:3
    st.axR(k) = eje_(gr, tr{k}, yr{k}, 11);
    st.axR(k).Layout.Row = 2;  st.axR(k).Layout.Column = k;
    st.axRU(k) = eje_(gr, tu{k}, 'V', 11);
    st.axRU(k).Layout.Row = 3;  st.axRU(k).Layout.Column = k;
end

% LA PLANTA.  El esquema de la unidad de 600 MW con los valores del modelo de
% 47 estados encima, en el instante actual, al estilo del simulador de
% Galindo (2001).  Ver PLANTA_CONSTRUYE_ y PLANTA_ACTUALIZA_.
st.tabPl = uitab(st.grupo,'Title','Planta');
st = planta_construye_(st);

% LA TABLA 4 DEL ARTICULO.  La lectura de abajo solo ve la corrida actual;
% esta pestana guarda el IAE de cada corrida terminada de las dos rampas y
% arma con ellas la Tabla 4: un renglon por controlador, las dos pruebas y
% J, con la misma regla de colores que la lectura (verde < 1, rojo > 1).
% «Exportar a LaTeX» la escribe como tabla4.tex para el articulo.
st.tabT4 = uitab(st.grupo,'Title','Índices');
gt = uigridlayout(st.tabT4,[7 3]);
gt.RowHeight = {'fit', 'fit', 100, 'fit', 100, 'fit', 'fit'};
gt.ColumnWidth = {'fit','fit','1x'};
gt.Padding = [10 10 10 10];  gt.RowSpacing = 8;  gt.ColumnSpacing = 8;
u = uilabel(gt, 'WordWrap','on', 'FontSize',12, 'Text', ...
    ['Índices normalizados contra el PI de Usoro.  Cada corrida que termina ' ...
     'en una de las dos rampas llena su mitad del renglón de su controlador; ' ...
     'J es la media de los seis cocientes.  Verde: mejora al PI (< 1); ' ...
     'rojo: empeora (> 1).']);
u.Layout.Row = 1;  u.Layout.Column = [1 3];
colC = {'TSSO  90→70','TRHO  90→70','PSSO  90→70', ...
        'TSSO  70→90','TRHO  70→90','PSSO  70→90','J'};
nr = numel(st.compNom);
u = uilabel(gt,'Text','IAE / IAE del PI', ...
            'FontWeight','bold','FontSize',12);
u.Layout.Row = 2;  u.Layout.Column = [1 3];
st.tabC = uitable(gt, 'ColumnName',colC, 'RowName',st.compNom, ...
    'Data',repmat({'—'},nr,7), 'ColumnWidth','auto', 'FontSize',13);
st.tabC.Layout.Row = 3;  st.tabC.Layout.Column = [1 3];
u = uilabel(gt,'Text','ITAE / ITAE del PI', ...
            'FontWeight','bold','FontSize',12);
u.Layout.Row = 4;  u.Layout.Column = [1 3];
st.tabCi = uitable(gt, 'ColumnName',colC, 'RowName',st.compNom, ...
    'Data',repmat({'—'},nr,7), 'ColumnWidth','auto', 'FontSize',13);
st.tabCi.Layout.Row = 5;  st.tabCi.Layout.Column = [1 3];
ayuda = ['Los cocientes se toman al final de la corrida, con el PI ' ...
         'integrado sobre los mismos instantes.'];
tip_(st.tabC, ayuda);  tip_(st.tabCi, ayuda);
st.btTex = uibutton(gt,'Text','Exportar a LaTeX…', ...
                    'ButtonPushedFcn',@(s,e) exportaTabla_(s));
st.btTex.Layout.Row = 6;  st.btTex.Layout.Column = 1;
tip_(st.btTex, ['Escribe tabla4.tex con las dos tablas (IAE arriba, ITAE ' ...
    'abajo) y los renglones completos.  En el artículo: \input{tabla4}.']);
st.btVac = uibutton(gt,'Text','Vaciar', ...
                    'ButtonPushedFcn',@(s,e) vaciaTabla_(s));
st.btVac.Layout.Row = 6;  st.btVac.Layout.Column = 2;
st.lblComp = uilabel(gt,'Text','','FontColor',C.tenue,'WordWrap','on', ...
                     'FontSize',11);
st.lblComp.Layout.Row = 7;  st.lblComp.Layout.Column = [1 3];

et = {'TSSO  sobrecalentador', ...
      'TRHO  recalentador', ...
      'PSSO  presión de vapor', ...
      'ldc  demanda de carga', ...
      '‖Δθ‖  deriva de los parámetros respecto del modelo inicial', ...
      'cond(B_0)  —  la cifra con la que Amin justifica T = 20 s', ...
      'Estimador y nodo de la tabla por carga', ...
      'Covarianza del estimador P(t)  —  traza y valores propios extremos'};
ye = {'TSSO (°R)','TRHO (°R)','PSSO (psia)','ldc (V)', ...
      '‖θ(t) − θ(0)‖_F','cond(B_0)','','P(t)'};
nom = {'TSSO','TRHO','PSSO','Mandos','Δθ','cond(B0)','Estimador','Covarianza P'};
eu = {'CBMD  demanda maestra de caldera', ...
      'CXGG  inclinación de quemadores', ...
      'CWSY  atemperación del sobrecalentador'};

% LAS ENTALPIAS.  El modelo de Usoro no integra temperaturas: integra la
% densidad y la ENTALPIA del vapor (estados 10-11 en el sobrecalentador y
% 13-14 en el recalentador), y TSSO y TRHO salen de ellas con los ajustes de
% tablas de vapor SHSTAT y RHSTAT.  Las figuras del capitulo V de Usoro
% muestran HSSO y HRHO; por eso van en la pestana de su temperatura.
eh = {'HSSO  entalpía del vapor sobrecalentado  (estado 11)', ...
      'HRHO  entalpía del vapor recalentado  (estado 14)'};
st.tabs = gobjects(1,8);
st.ax   = gobjects(1,8);
st.axH  = gobjects(1,2);
st.axU  = gobjects(1,3);
for k = 1:8
    st.tabs(k) = uitab(st.grupo,'Title',nom{k});
    if k <= 2
        gq = uigridlayout(st.tabs(k),[2 1]);
        gq.RowHeight = {'3x','2x'};  gq.RowSpacing = 4;
        gq.Padding = [8 8 8 8];
        st.ax(k)  = eje_(gq, et{k}, ye{k}, 12);
        st.axH(k) = eje_(gq, eh{k}, 'h (BTU/lb)', 11);
    elseif k == 4
        % MANDOS: uno por eje, como la Fig. 8 del articulo, y debajo la
        % demanda de carga (st.ax(4)), que es la que mueve la prueba.
        gq = uigridlayout(st.tabs(k),[4 1]);
        gq.RowHeight = {'1x','1x','1x','0.7x'};  gq.RowSpacing = 4;
        gq.Padding = [8 8 8 8];
        for m = 1:3
            st.axU(m) = eje_(gq, eu{m}, 'mando (V)', 11);
        end
        st.ax(k) = eje_(gq, et{k}, ye{k}, 11);
    else
        gq = uigridlayout(st.tabs(k),[1 1]);
        gq.Padding = [8 8 8 8];
        st.ax(k) = eje_(gq, et{k}, ye{k}, 12);
    end
end

st.grupo.SelectedTab = st.tabRes;

% ------------------------------------------------------------- lectura ---
p4 = uipanel(R,'Title','Lectura  —  salidas e índices integrados hasta t', ...
             'FontWeight','bold','BackgroundColor',C.panel);
g4 = uigridlayout(p4,[1 1]);
g4.Padding = [6 6 6 6];
st.tabY = uitable(g4, ...
    'ColumnName',{'y','consigna w','y − w','IAE','ITAE','IAE / PI', ...
                  'ITAE / PI','IAE / ref'}, ...
    'RowName',{'TSSO (°R)','TRHO (°R)','PSSO (psia)'}, ...
    'Data',repmat({'—'},3,8), 'ColumnWidth','auto', 'FontSize',12);
tip_(st.tabY, ['IAE e ITAE integrados desde t = 0.  «/ PI»: cociente contra ' ...
    'el PI de Usoro en el mismo instante (< 1 lo mejora, en verde).  ' ...
    '«/ ref»: contra la corrida fijada como referencia.']);

st = limpia_ejes_(st);
end

% =========================================================================
function a = eje_(padre, titulo, ylab, fs)
%EJE_  Un UIAXES con el estilo comun del simulador.
a = uiaxes(padre);
a.Title.String = titulo;
a.Title.FontSize = fs;
a.Title.FontWeight = 'normal';
a.XGrid = 'on';  a.YGrid = 'on';
a.GridColor = [0.85 0.85 0.85];  a.GridAlpha = 1;
a.Box = 'off';
a.XLim = [0 800];
a.XLabel.String = 'tiempo (s)';
if ~isempty(ylab), a.YLabel.String = ylab; end
a.FontSize = fs - 1;
end

% =========================================================================
function et_(g, s, ayuda)
u = uilabel(g,'Text',s,'FontColor',[0.30 0.30 0.34]);
if nargin > 2, tip_(u, ayuda); end
end

function tip_(h, s)
% Tooltip existe desde R2021a; el PDF ya exige R2021b, pero por si acaso.
try h.Tooltip = s; catch, end
end

% =========================================================================
function C = paleta_()
C.fondo  = [0.96 0.96 0.97];
C.panel  = [1.00 1.00 1.00];
C.tenue  = [0.38 0.38 0.42];
C.acento = [0.25 0.45 0.80];
C.s1 = [0.251 0.451 0.800];
C.s2 = [0.851 0.451 0.149];
C.s3 = [0.557 0.294 0.659];
C.ref  = [0.45 0.45 0.45];
C.base = [82 81 78]/255;           % PI de Usoro, gris del articulo
C.stc  = [42 120 214]/255;         % STC, azul del articulo
C.mod  = [235 104 52]/255;         % STC modificado, naranja del articulo
C.fija = [0.129 0.549 0.451];
C.aviso = [0.800 0.220 0.310];
C.riel  = [0.88 0.90 0.93];
C.listo = [0.52 0.54 0.60];
C.pausa = [0.86 0.54 0.13];
C.bien  = [0.86 0.95 0.89];
C.mal   = [0.99 0.88 0.88];
end

% =========================================================================
function st = limpia_ejes_(st)
%LIMPIA_EJES_  Crea las lineas de todas las graficas.  Las de las salidas y
%   los mandos van DOBLES: fila 1 en su pestana, fila 2 en «Resumen», y se
%   actualizan juntas con SET sobre la columna entera.  Los colores son los
%   del articulo; el del controlador lo pone COLOREA_ segun cual se elija.
C = st.C;
ejes = [st.ax(1:3); st.axR(1:3)];            % 2 x 3: salidas
st.hBase = gobjects(2,3);  st.hRef = gobjects(2,3);
st.hFij  = gobjects(2,3);  st.hOut = gobjects(2,3);
for r = 1:2
    for k = 1:3
        a = ejes(r,k);  cla(a);  hold(a,'on');
        st.hBase(r,k) = plot(a, nan, nan, '-',  'Color',C.base, 'LineWidth',1.3);
        st.hRef(r,k)  = plot(a, nan, nan, '--', 'Color',[0 0 0], 'LineWidth',0.8);
        st.hFij(r,k)  = plot(a, nan, nan, '-',  'Color',C.fija, 'LineWidth',1.4);
        st.hOut(r,k)  = plot(a, nan, nan, '-',  'Color',C.stc,  'LineWidth',1.6);
        hold(a,'off');
    end
end

% Entalpias: solo en la pestana de su temperatura.  PI de Usoro, referencia
% fijada y controlador.  Sin consigna: Usoro no fija ninguna para h.
st.hBaseH = gobjects(1,2);  st.hFijH = gobjects(1,2);  st.hH = gobjects(1,2);
for k = 1:2
    a = st.axH(k);  cla(a);  hold(a,'on');
    st.hBaseH(k) = plot(a, nan, nan, '-', 'Color',C.base, 'LineWidth',1.3);
    st.hFijH(k)  = plot(a, nan, nan, '-', 'Color',C.fija, 'LineWidth',1.4);
    st.hH(k)     = plot(a, nan, nan, '-', 'Color',C.stc,  'LineWidth',1.6);
    hold(a,'off');
end

% Mandos, en escalones: uno por eje, en su pestana (fila 1) y en el resumen
% (fila 2), con el PI de Usoro de fondo como en la Fig. 8 del articulo.
ejesU = [st.axU(1:3); st.axRU(1:3)];         % 2 x 3
st.hBaseU = gobjects(2,3);  st.hFijU = gobjects(2,3);  st.hU = gobjects(2,3);
for r = 1:2
    for k = 1:3
        a = ejesU(r,k);  cla(a);  hold(a,'on');
        st.hBaseU(r,k) = plot(a, nan, nan, '-', 'Color',C.base, 'LineWidth',1.3);
        st.hFijU(r,k)  = plot(a, nan, nan, '-', 'Color',C.fija, 'LineWidth',1.2);
        st.hU(r,k)     = plot(a, nan, nan, '-', 'Color',C.stc,  'LineWidth',1.4);
        hold(a,'off');
    end
end
a = st.ax(4);  cla(a);  hold(a,'on');
st.hLdc = plot(a, nan, nan, '-', 'Color',[0.15 0.15 0.15], 'LineWidth',1.6);
hold(a,'off');

a = st.ax(5);  cla(a);  hold(a,'on');
st.hTh = plot(a, nan, nan, '-', 'Color',C.s1, 'LineWidth',1.8);
hold(a,'off');

a = st.ax(6);  cla(a);  hold(a,'on');
st.hCond = plot(a, nan, nan, '-', 'Color',C.s2, 'LineWidth',1.8);
st.hCondL = plot(a, nan, nan, 'k--', 'LineWidth',1.0);
hold(a,'off');
a.YScale = 'log';

a = st.ax(7);  cla(a);  hold(a,'on');
st.hUpd  = plot(a, nan, nan, '-', 'Color',C.s1, 'LineWidth',1.8);
st.hNodo = plot(a, nan, nan, '-', 'Color',C.s3, 'LineWidth',1.8);
st.hFrz  = plot(a, nan, nan, '-', 'Color',C.aviso, 'LineWidth',1.4);
hold(a,'off');
leyenda_(a, [st.hUpd st.hNodo st.hFrz], ...
         {'actualizaciones acumuladas','nodo de la tabla (% de carga)', ...
          'estimador congelado (0/1, ×10)'});

% LA COVARIANZA.  El estimador tiene UNA sola P para las tres filas de
% theta (el regresor es el mismo), de npar x npar: 33 x 33 en el 3x3 y
% 39 x 39 en el 3x4.  Se dibujan su traza ---la «incertidumbre total»--- y
% sus valores propios extremos: lambda_max dice si alguna direccion del
% espacio de parametros se esta quedando sin excitacion (crece como
% beta^-t), lambda_min cuanto se ha contraido la mejor informada.
a = st.ax(8);  cla(a);  hold(a,'on');
st.hTr0  = plot(a, nan, nan, '--', 'Color',C.ref,  'LineWidth',1.0);
st.hFijP = plot(a, nan, nan, '-',  'Color',C.fija, 'LineWidth',1.4);
st.hLmax = plot(a, nan, nan, '-',  'Color',C.s2,   'LineWidth',1.2);
st.hLmin = plot(a, nan, nan, '-',  'Color',C.s3,   'LineWidth',1.2);
st.hTr   = plot(a, nan, nan, '-',  'Color',C.s1,   'LineWidth',2.0);
hold(a,'off');
a.YScale = 'log';
leyenda_(a, [st.hTr st.hLmax st.hLmin st.hTr0], ...
         {'tr P(t)','λ_{max}(P)','λ_{min}(P)','tr P(0) = P_0·npar'});

st = leyendas_(st);
ejes_iniciales_(st);
end

% =========================================================================
function [c, n] = colorCtrl_(st)
%COLORCTRL_  Color y nombre corto del controlador elegido, como en las
%   Figs. 6 y 7 del articulo: PI de Usoro en gris y el controlador en
%   naranja (sea el STC o cualquier variante con tabla).
kc = find(strcmp(st.ddCtrl.Value, st.ctrlNom), 1);
if isempty(kc), kc = 2; end
nombres = {'PI de Usoro','STC','STC modificado','STC modificado, mando 2 s', ...
           'Tabla, estimador apagado'};
n = nombres{min(kc, numel(nombres))};
if kc == 1, c = st.C.base; else, c = st.C.mod; end
end

% =========================================================================
function st = leyendas_(st)
%LEYENDAS_  Colores del controlador y leyendas.  En el resumen la leyenda es
%   una sola, arriba, como en el articulo; en las pestanas va debajo de la
%   grafica, en una fila, sin tapar ninguna curva.
[c, nc] = colorCtrl_(st);
set([st.hOut(:); st.hH(:); st.hU(:)], 'Color',c);
hayRef = ~isempty(st.ref);
% Resumen: etiqueta HTML con una muestra de color por curva.
muestra = @(col, m, txt) sprintf(['<span style="color:#%02X%02X%02X"><b>%s</b></span>' ...
    '&nbsp;%s'], round(255*col), m, txt);
partes = {muestra([0 0 0], '&#8211; &#8211;', 'consigna')};
if st.chkBase.Value
    partes{end+1} = muestra(st.C.base, '&#9473;&#9473;', 'PI de Usoro');
end
if hayRef
    partes{end+1} = muestra(st.C.fija, '&#9473;&#9473;', ['ref: ' corta_(st.ref.ctrl)]);
end
partes{end+1} = muestra(c, '&#9473;&#9473;', nc);
try
    st.lblLeyR.Text = strjoin(partes, '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;');
catch
end
% Pestanas: salidas y entalpias.
for k = 1:3
    h = [st.hBase(1,k) st.hRef(1,k)];  n = {'PI de Usoro','consigna'};
    if hayRef
        h(end+1) = st.hFij(1,k);  n{end+1} = ['ref: ' corta_(st.ref.ctrl)]; %#ok<AGROW>
    end
    h(end+1) = st.hOut(1,k);  n{end+1} = nc; %#ok<AGROW>
    leyenda_(st.ax(k), h, n);
end
for k = 1:2
    h = st.hBaseH(k);  n = {'PI de Usoro'};
    if hayRef
        h(end+1) = st.hFijH(k);  n{end+1} = ['ref: ' corta_(st.ref.ctrl)]; %#ok<AGROW>
    end
    h(end+1) = st.hH(k);  n{end+1} = nc; %#ok<AGROW>
    leyenda_(st.axH(k), h, n);
end
% Pestana de mandos: una leyenda, en el primero.
h = st.hBaseU(1,1);  n = {'PI de Usoro'};
if hayRef
    h(end+1) = st.hFijU(1,1);  n{end+1} = ['ref: ' corta_(st.ref.ctrl)];
end
h(end+1) = st.hU(1,1);  n{end+1} = nc;
leyenda_(st.axU(1), h, n);
end

function leyenda_(a, h, n)
try
    legend(a, h, n, 'Location','southoutside', 'Orientation','horizontal', ...
           'Box','off', 'FontSize',9);
catch
end
end

% =========================================================================
function ejes_iniciales_(st)
%EJES_INICIALES_  Las escalas del articulo (Figs. 6-8) desde antes de correr:
%   1420 a 1500 R en las temperaturas, 2200 a 2600 psia en la presion y el
%   rango de 1 a 5 V de los transductores en los mandos.
if isfield(st,'dur') && ~isempty(st.dur), xl = [0 st.dur]; else, xl = [0 800]; end
lim = {[1420 1500], [1420 1500], [2200 2600]};
for k = 1:3
    set([st.ax(k) st.axR(k)], 'XLim',xl, 'YLim',lim{k});
end
set([st.axU st.axRU], 'XLim',xl, 'YLim',[1 5]);
st.ax(4).XLim = xl;  st.ax(4).YLimMode = 'auto';
for k = 5:8
    st.ax(k).XLim = xl;
    st.ax(k).YLimMode = 'auto';
end
% Entalpias: el rango que recorre el PI de Usoro en las dos rampas del
% articulo (HSSO 1458-1466, HRHO 1515-1532 BTU/lb), con holgura.
limH = {[1450 1475], [1505 1540]};
for k = 1:2
    set(st.axH(k), 'XLim',xl, 'YLim',limH{k});
end
ejeTiempo_(st, xl(2));
end

% =========================================================================
function ejeTiempo_(st, dur)
%EJETIEMPO_  En las pruebas largas (demanda de 24 h) el eje del tiempo se
%   marca en horas; en las del articulo, en segundos como siempre.
ejes = [st.ax(:); st.axR(:); st.axRU(:); st.axU(:); st.axH(:)];
if dur >= 3*3600
    p = 3600*4;  if dur <= 12*3600, p = 3600*2; end
    if dur <= 6*3600, p = 3600; end
    tk = 0:p:dur;
    set(ejes, 'XTick',tk, 'XTickLabel', arrayfun(@(v) sprintf('%g h', v/3600), tk, 'UniformOutput',false));
else
    set(ejes, 'XTickMode','auto', 'XTickLabelMode','auto');
end
end

% =========================================================================
function ajustaDur_(st)
%AJUSTADUR_  Duraciones segun la prueba: las del articulo o las de 24 h.
kp = find(strcmp(st.ddPrueba.Value, st.pruebaNom), 1);
if ~isempty(st.pruebaDia{kp})
    it = {'24 h  (día completo)','12 h','6 h'};  dat = [86400 43200 21600];
else
    it = {'800 s  (artículo)','1600 s','2400 s'};  dat = [800 1600 2400];
end
if ~isequal(st.ddDur.ItemsData, dat)
    set(st.ddDur, 'Items',it, 'ItemsData',dat, 'Value',dat(1));
end
end

% =========================================================================
function st = carga_modelo_(st, forzar)
%CARGA_MODELO_  Trae los cuatro modelos AR (3x3 y 3x4, k = 1 y 2) y sus
%   tablas por carga.  Se cargan todos al abrir, y los desplegables «Modelo
%   ARX» y «Retardo k» solo eligen cual se usa (ELIGE_MODELO_): cambiar de
%   modelo no lee nada del disco.
vuelve = enraiz_(st); %#ok<NASGU>
st.Mm = cell(2,2);  st.TBm = cell(2,2);
for m = 1:4
    arM = ['amin_modelo' sufijo_(m) '.mat'];
    arT = ['amin_tabla'  sufijo_(m) '.mat'];
    f = fullfile('datos', arM);
    if exist(f,'file') == 2 && ~forzar
        q = load(f);  M = q.M;
        if ~isfield(M,'nd')          % guardado antes del 3x4: es 3x3
            M = amin_modelo(M.th, M.N, M.nu, M.ny, M.k, M.T, M.u_ss, M.y_ss, M.pct);
        end
        st.Mm{m} = M;
    end
    g = fullfile('datos', arT);
    if exist(g,'file') == 2
        q = load(g);  TB = q.TB;
        % La tabla se construye A PARTIR del modelo.  Si la guardada es de
        % otro modelo (otro N, otro theta) mezclarlas es un error silencioso:
        % se descarta y se avisa.
        if ~isempty(st.Mm{m}) && isfield(TB,'huella')
            M = st.Mm{m};
            h = struct('N',M.N, 'npar',M.npar, 'th',sum(abs(M.th(:))));
            if ~amin_misma_huella(TB.huella, h)
                TB = [];
                aviso_(st, sprintf(['datos/%s es de OTRO modelo (N o theta ' ...
                        'distintos).  Vuelve a correr AMIN_MAIN paso 7.'], arT));
            end
        end
        st.TBm{m} = TB;
    end
end
st = elige_modelo_(st);
end

% =========================================================================
function m = kmod_(st)
%KMOD_  Indice lineal en st.Mm: modelo (1 = 3x3, 2 = 3x4) y retardo
%   (k = 1 o 2).  1 = 3x3 k1, 2 = 3x4 k1, 3 = 3x3 k2, 4 = 3x4 k2.
m = find(strcmp(st.ddMod.Value, st.modNom), 1);
if isempty(m), m = 1; end
kk = 1;
if isfield(st,'ddK')
    kk = find(strcmp(st.ddK.Value, st.kNom), 1);
    if isempty(kk), kk = 1; end
end
m = m + 2*(kk-1);
end

function s = sufijo_(m)
%SUFIJO_  Sufijo de archivo del modelo m (ver KMOD_ y AMIN_SUFIJO).
e = {'', '_ldc', '_k2', '_ldc_k2'};
s = e{m};
end

% =========================================================================
function st = elige_modelo_(st)
%ELIGE_MODELO_  Pone en st.M y st.TB el modelo del desplegable.
m = kmod_(st);
st.M  = st.Mm{m};
st.TB = st.TBm{m};
arT = ['amin_tabla' sufijo_(m) '.mat'];
cual = {'3x3, k = 1', '3x4, k = 1', '3x3, k = 2', '3x4, k = 2'};

if isempty(st.M)
    st.lblMod.Text = sprintf(['modelo %s: NO identificado todavia.  Pulsa ' ...
                      '«Identificar el modelo ahora».'], cual{m});
    st.lblMod.FontColor = st.C.aviso;
    st.btMod.Enable = 'on';
else
    st.lblMod.Text = sprintf(['modelo %s: N = %d, %d par./fila, k = %d, ' ...
                              'T = %g s,  identificado al %s'], ...
                             st.M.estructura, st.M.N, st.M.npar, st.M.k, ...
                             st.M.T, pctStr_(st.M));
    st.lblMod.FontColor = st.C.tenue;
    st.btMod.Enable = 'on';
end

it = st.ctrlNom;
if isempty(st.TB)
    it = st.ctrlNom(1:2);
    if ~any(strcmp(st.ddCtrl.Value, it)), st.ddCtrl.Value = it{2}; end
    aviso_(st, sprintf(['falta datos/%s: las configuraciones con tabla ' ...
                'necesitan la tabla por carga del modelo %s (AMIN_TABLA).'], ...
                arT, cual{m}));
end
st.ddCtrl.Items = it;
end

% =========================================================================
function cambioModelo_(h)
st = cargar_(h);
if st.running, return, end
st = elige_modelo_(st);
guardar_(st.fig, st);
cambio_(h);
end

function s = pctStr_(M)
if isfield(M,'pct'), s = sprintf('%g %%', M.pct); else, s = '75 %'; end
end

% =========================================================================
function identificar_(h)
%IDENTIFICAR_  Corre los pasos 4 y 5 del articulo desde la ventana, para el
%   modelo que este elegido en el desplegable.  El orden es el del articulo,
%   N = 5, igual que AMIN_MAIN por omision: con el criterio libre el orden
%   del 3x3 y el del 3x4 podrian salir distintos y la comparacion ya no
%   seria de una sola cosa.
st = cargar_(h);  vuelve = enraiz_(st); %#ok<NASGU>
m = kmod_(st);
kk = 1 + (m > 2);
arch = ['amin_modelo' sufijo_(m) '.mat'];
if mod(m-1,2) == 1
    msg = 'diez corridas de 400 s al 75 %, lazo abierto, con ldc excitada...';
    sig = amin_sigma_ldc();
else
    msg = 'diez corridas de 400 s al 75 %, lazo abierto...';
    sig = [];
end
d = uiprogressdlg(st.fig,'Title','Identificación (sección IV)', ...
                  'Message',msg, 'Indeterminate','on');
try
    D = amin_datos('verbose',false, 'sigmaLdc',sig);
    d.Message = 'estimando el modelo AR (N = 5, el del artículo)...';
    M = amin_ident(D, 'N',1:8, 'criterio','fijo', 'Nfijo',5, 'verbose',false, ...
                   'k',kk);
    M.pct = D.pct; %#ok<STRNU>
    save(fullfile('datos',arch), 'M', '-v7');
    close(d);
    st = carga_modelo_(st, false);
    aviso_(st, sprintf(['modelo %s, k = %d identificado: N = %d, %d par./fila.  ' ...
                        'Falta su tabla por carga (AMIN_TABLA) para las ' ...
                        'configuraciones modificadas.'], ...
                       st.M.estructura, st.M.k, st.M.N, st.M.npar));
catch err
    close(d);
    aviso_(st, ['ERROR al identificar: ' err.message]);
end
guardar_(st.fig, st);
end

% =========================================================================
function st = prepara_(st)
%PREPARA_  Monta la corrida.  No integra nada todavia.
vuelve = enraiz_(st); %#ok<NASGU>

kp = find(strcmp(st.ddPrueba.Value, st.pruebaNom), 1);
kc = find(strcmp(st.ddCtrl.Value,  st.ctrlNom), 1);
st.kp = kp;  st.kc = kc;
st.dur = st.ddDur.Value;
st.esPI = (kc == 1);
st.literal = strcmp(st.ddLey.Value, st.leyNom{2});

pct = st.pruebaPct{kp};
st.dia = st.pruebaDia{kp};
if ~isempty(st.dia)
    [P, info] = amin_demanda(st.dia, 'dur',st.dur);
elseif pct(1) == pct(2)
    S0 = amin_estacionario(pct(1), 'verbose',false);
    P = amin_planta(S0.base, 'ldcStart',S0.ldc, 'ldcRate',0, ...
                     'ldcT0',0, 'ldcT1',0, ...
                     'samples', round(st.dur/0.1)+1);
    P.x0 = S0.x0;  P.ldc = S0.ldc;
    info = struct('T0',0, 'T1',0, 'ss',S0, 'pctIni',pct(1), 'pctFin',pct(2));
else
    [P, info] = amin_rampa(pct(1), pct(2), 'dur',st.dur, 'verbose',false);
end
st.P = P;  st.info = info;

if ~st.esPI
    if isempty(st.M)
        error('amin_sim:modelo', ...
              'No hay modelo identificado.  Pulsa «Identificar el modelo ahora».');
    end
    Tc = st.M.T;
    tabla = [];  congelar = [];
    if kc >= 3
        if isempty(st.TB)
            error('amin_sim:tabla', 'Falta datos/amin_tabla.mat (AMIN_TABLA).');
        end
        tabla = st.TB;
        congelar = [info.T0, info.T1 + 130];   % los 130 s de la seccion V
        % DEMANDA REAL: tabla interpolada con la carga y estimador congelado
        % solo mientras la carga se mueve mas de 1 %/min (AMIN_CONGELA_MOV).
        if ~isempty(st.dia), congelar = []; end
        M0 = st.TB.M(amin_nodo(st.TB, info.ss.ldc));
        adapt = false;
    else
        d0 = [];  if st.M.nd > 0, d0 = info.ss.ldc; end
        M0 = amin_modelo(st.M.th, st.M.N, st.M.nu, st.M.ny, st.M.k, st.M.T, ...
                         info.ss.u, info.ss.y, NaN, d0);
        adapt = true;
    end
    % Con el mando cada 2 s el estimador se queda apagado TODA la corrida:
    % «the estimator is off at the beginning of the transient period and is
    %  kept off while the control is calculated every 2 seconds».
    if kc == 4, Tc = 2;  congelar = [0 inf]; end
    % La quinta configuracion NO es del articulo: es la tabla por carga con
    % el estimador apagado de principio a fin.  Separa lo que el «modified
    % S.T.C.» mezcla: recolocar el punto de operacion y seguir adaptando.
    if kc == 5, congelar = [0 inf]; end

    st.S = amin_stc_init(M0, 'lambda',st.efLam.Value, 'beta',st.efBeta.Value, ...
                         'adapt',adapt, 'Tc',Tc, 'literal',st.literal);
    st.tabla = tabla;  st.congelar = congelar;
    st.interp = ~isempty(st.dia) && ~isempty(tabla);
    st.gmov = [];
    if st.interp && isempty(congelar)
        st.gmov = struct('umbral',info.umbral, 'reten',info.reten, 'ult',-inf, 'lPrev',NaN);
    end
    st.th0 = M0.th;
    % Se arranca EN LAZO CERRADO: el PI manda hasta que la ley entregue su
    % primer mando (ver INSTANTE_).
    st.P.openLoop = [false false false];
    st.P.uFcn = [];
else
    st.S = [];  st.tabla = [];  st.congelar = [];  st.th0 = [];
    st.interp = false;  st.gmov = [];
    Tc = 20;
end
st.Tc = Tc;

st.Ts = P.Ts;
st.stride = round(Tc/P.Ts);
st.n = P.samples - 1;
st.x = P.x0(:);
st.t = 0;  st.i = 1;  st.k = 0;
st.uNow = [];
st.nodoActual = NaN;

nc = floor(st.n/st.stride) + 2;
st.tc = nan(1,nc);   st.Yh = nan(3,nc);  st.Wh = nan(3,nc);
st.Uh = nan(3,nc);   st.Dh = nan(1,nc);  st.Th = nan(1,nc);
st.Ch = nan(1,nc);   st.Nh = nan(1,nc);  st.Fh = nan(1,nc);
st.Uc = nan(1,nc);   st.Ph = nan(3,nc);           % [tr P; lambda_max; lambda_min]
st.Hh = nan(2,nc);                                % [hsso; hrho], BTU/lb
st.trP0 = NaN;
if ~st.esPI, st.trP0 = trace(st.S.E.P); end
st.iae = zeros(1,3);  st.itae = zeros(1,3);
st.nUpd = 0;  st.condMax = 0;  st.diverge = false;

set([st.ax st.axR st.axRU st.axU st.axH], 'XLim',[0 st.dur]);
ejeTiempo_(st, st.dur);
st = pinta_base_(st);
st = planta_actualiza_(st);
st.armed = true;
end

% =========================================================================
function st = pinta_base_(st)
%PINTA_BASE_  La corrida del PI de Usoro, que es la linea base del articulo.
clave = sprintf('p%d_d%d', st.kp, st.dur);
if ~isfield(st.baseAll, clave)
    msj = 'corriendo los PI originales de Usoro...';
    if st.dur > 3600, msj = sprintf('%s  (%g h simuladas: puede tardar varios minutos)', msj, st.dur/3600); end
    d = uiprogressdlg(st.fig,'Title','Línea base', 'Message',msj, 'Indeterminate','on');
    try
        % P LIMPIO: st.P puede venir preparado para el STC (openLoop y uFcn
        % puestos).  La base tiene que correr con los PI de Usoro.
        Pb = st.P;  Pb.openLoop = [false false false];  Pb.uFcn = [];
        R = amin_lazo([], Pb, 'guardaX',false);   % x solo en los instantes de control
    catch err
        close(d);  rethrow(err);
    end
    close(d);
    B = struct('t',R.tc, 'Y',R.Y, 'W',R.W, 'D',R.ldc, 'U',R.U);
    % Entalpias en los mismos instantes que las salidas: R.x va con el paso
    % de integracion, asi que se toma la fila de cada instante de control.
    B.H = R.x(:, [11 14]).';
    dtb = R.tc(2) - R.tc(1);
    B.iaeC  = cumsum(abs(R.Y - R.W), 2) * dtb;
    B.itaeC = cumsum(abs(R.Y - R.W) .* (ones(3,1)*R.tc), 2) * dtb;
    st.baseAll.(clave) = B;
end
B = st.baseAll.(clave);
for k = 1:3
    if st.chkBase.Value
        set(st.hBase(:,k), 'XData',B.t, 'YData',B.Y(k,:));
    else
        set(st.hBase(:,k), 'XData',nan, 'YData',nan);
    end
end
for k = 1:2
    if st.chkBase.Value && isfield(B,'H')
        set(st.hBaseH(:,k), 'XData',B.t, 'YData',B.H(k,:));
    else
        set(st.hBaseH(:,k), 'XData',nan, 'YData',nan);
    end
end
% Los mandos del PI, en escalones como en la Fig. 8 del articulo.
for k = 1:3
    if st.chkBase.Value && isfield(B,'U')
        [xs, ys] = escalon_(B.t, B.U(k,:), B.t(end));
        set(st.hBaseU(:,k), 'XData',xs, 'YData',ys);
    else
        set(st.hBaseU(:,k), 'XData',nan, 'YData',nan);
    end
end
end

% =========================================================================
function alternar_(h)
st = cargar_(h);
if st.running
    st.stopReq = true;  st.running = false;
    fase_(st, 'pausa');
    guardar_(st.fig, st);
    return
end
if ~st.armed || st.k == 0
    try
        st = prepara_(st);
    catch err
        aviso_(st, ['ERROR: ' err.message]);
        guardar_(st.fig, st);  return
    end
    st = limpia_trazas_(st);
end
st.running = true;  st.stopReq = false;
fase_(st, 'corriendo');
aviso_(st, '');
bloquea_(st, 'off');
guardar_(st.fig, st);
bucle_(st.fig);
end

% =========================================================================
function bloquea_(st, s)
st.ddPrueba.Enable = s;  st.ddCtrl.Enable = s;  st.ddLey.Enable = s;
st.ddDur.Enable = s;     st.efLam.Enable = s;   st.efBeta.Enable = s;
st.chkBase.Enable = s;   st.btMod.Enable = s;   st.ddMod.Enable = s;
st.ddK.Enable = s;
st.btTex.Enable = s;   st.btVac.Enable = s;
end

% =========================================================================
function bucle_(fig)
st = getappdata(fig,'st');
tWall = tic;  tSim0 = st.t;

while st.i <= st.n && ~getappdata(fig,'stopReq')
    if mod(st.i-1, st.stride) == 0
        st = instante_(st);
        if st.diverge, break, end
        st = dibuja_(st);
        st = actualiza_lectura_(st);
        st = planta_actualiza_(st);
        drawnow limitrate
        vel = st.ddVel.Value;
        if isfinite(vel)
            esperar = (st.t - tSim0)/vel - toc(tWall);
            if esperar > 0, pause(esperar); end
        end
        if getappdata(fig,'stopReq'), break, end
    end

    Ts = st.Ts;  t = st.t;  P = st.P;  x = st.x;
    xd1 = digpte47(t,        x,              P);
    xd2 = digpte47(t+Ts/2,   x + (Ts/2)*xd1, P);
    xd3 = digpte47(t+Ts/2,   x + (Ts/2)*xd2, P);
    xd4 = digpte47(t+Ts,     x +  Ts  *xd3,  P);
    st.x = x + (Ts/6)*(xd1 + 2*xd2 + 2*xd3 + xd4);
    st.x = pte47_clamp(st.x, P);
    st.t = t + Ts;
    st.i = st.i + 1;

    if ~all(isfinite(st.x)) || ~isreal(st.x)
        st.diverge = true;
        if ~isreal(st.x)
            aviso_(st, sprintf(['ESTADO COMPLEJO en t = %.1f s: la planta ' ...
                'salió del rango físico (sqrt de argumento negativo).'], st.t));
        else
            aviso_(st, sprintf('DIVERGIÓ en t = %.1f s', st.t));
        end
        break
    end
end

fin = (st.i > st.n) || st.diverge;
st.running = false;
bloquea_(st, 'on');
st = dibuja_(st);
st = actualiza_lectura_(st);
st = planta_actualiza_(st);
if st.diverge
    fase_(st, 'divergio');
elseif fin
    fase_(st, 'terminado');
else
    fase_(st, 'pausa');
end
if fin
    st.armed = false;
    if ~st.diverge, st = comp_guarda_(st); end
end
guardar_(fig, st);

if fin && st.chkPdf.Value
    try
        aviso_(st,'escribiendo el PDF...');  drawnow;
        aviso_(st, ['PDF: ' exporta_(st)]);
    catch err
        aviso_(st, ['ERROR al exportar: ' err.message]);
    end
end
end

% =========================================================================
function st = instante_(st)
%INSTANTE_  Un instante de control.  Llama a AMIN_STC, no reimplementa nada.
P = st.P;
% Mientras manda el PI, P esta en lazo cerrado y yl(29:31) trae su mando de
% verdad; cuando manda el STC, P esta en lazo abierto y trae lo que se le
% impone a la planta, que es lo que el estimador tiene que registrar.
[~, yl] = digpte47(st.t, st.x, P);
y = yl(26:28).';  w = yl(32:34).';  uPI = yl(29:31).';  ldc = yl(35);

nodo = NaN;  frz = 0;
if ~st.esPI
    if ~isempty(st.tabla)
        nodo = amin_nodo(st.tabla, ldc);
        if ~st.interp && (isnan(st.nodoActual) || st.nodoActual ~= nodo)
            st.S = amin_stc_nodo(st.S, st.tabla.M(nodo));
        end
        st.nodoActual = nodo;
    end
    if ~isempty(st.congelar)
        st.S.adapt = ~(st.t >= st.congelar(1) && st.t <= st.congelar(2));
    end
    % Demanda real (igual que AMIN_LAZO): congelacion por movimiento de la
    % carga y tabla interpolada.
    if ~isempty(st.gmov)
        [st.S, st.gmov] = amin_congela_mov(st.S, st.gmov, st.t, ldc, st.stride*st.Ts);
    end
    if st.interp
        st.S = amin_stc_interp(st.S, st.tabla, ldc);
    end
    frz = double(~st.S.adapt);

    [u, st.S] = amin_stc(st.S, y, w, uPI, ldc);    % ldc: solo la usa el 3x4
    if isempty(u)
        % CALENTAMIENTO: manda el PI de Usoro y manda de verdad, con el lazo
        % cerrado y sus integradores vivos.  Congelarlos aqui dejaba los tres
        % mandos clavados en su valor de t = 0 durante los 120 s que tarda el
        % estimador en tener historia, y la planta se iba sola.
        st.uNow = uPI;
        st.P.openLoop = [false false false];
        st.P.uFcn = [];
    else
        st.uNow = u;
        st.P.openLoop = [true true true];
        st.P.uFcn = @(z) st.uNow;
    end
else
    st.uNow = uPI;
end

st.k = st.k + 1;  k = st.k;
st.tc(k) = st.t;  st.Yh(:,k) = y;  st.Wh(:,k) = w;
st.Uh(:,k) = st.uNow;  st.Dh(k) = ldc;
st.Hh(:,k) = st.x([11 14]);       % hsso y hrho: estados del modelo
st.Nh(k) = NaN;  if ~isnan(nodo), st.Nh(k) = st.tabla.pct(nodo); end
if st.interp, st.Nh(k) = ldc/0.05; end         % tabla interpolada: la carga
st.Fh(k) = frz;

if ~st.esPI
    st.Th(k) = norm(st.S.M.th - st.th0, 'fro');
    if ~isempty(st.S.log.condB0)
        st.Ch(k) = st.S.log.condB0(end);
        st.condMax = max(st.condMax, st.Ch(k));
    end
    st.nUpd = st.S.E.n;
    ev = eig((st.S.E.P + st.S.E.P.')/2);
    st.Ph(:,k) = [sum(ev); max(ev); min(ev)];
end
st.Uc(k) = st.nUpd;

e = abs(y - w);
dt = st.Tc;
st.iae  = st.iae  + e.'*dt;
st.itae = st.itae + e.'*st.t*dt;
end

% =========================================================================
function st = dibuja_(st)
if st.k < 1, return, end
j = 1:st.k;
% LOS EJES DEL ARTICULO (Figs. 6-7) son fijos: 1420..1500 R y 2200..2600
% psia.  Se ensanchan solo cuando una curva se sale.
limY = {[1420 1500], [1420 1500], [2200 2600]};
for k = 1:3
    set(st.hOut(:,k), 'XData',st.tc(j), 'YData',st.Yh(k,j));
    set(st.hRef(:,k), 'XData',st.tc(j), 'YData',st.Wh(k,j));
    v = [st.Yh(k,j), st.Wh(k,j)];
    if st.chkBase.Value
        B = st.baseAll.(sprintf('p%d_d%d', st.kp, st.dur));
        v = [v, B.Y(k,:)]; %#ok<AGROW>
    end
    if ~isempty(st.ref), v = [v, st.ref.Yh(k,:)]; end %#ok<AGROW>
    v = v(isfinite(v));
    L = limY{k};
    if ~isempty(v)
        L = [min(L(1), min(v)), max(L(2), max(v))];
    end
    set([st.ax(k) st.axR(k)], 'YLim', L + [-1 1]*0.02*(L(2)-L(1)));
end

% Entalpias.  Mismo criterio que las temperaturas: escala de partida fija,
% que solo se ensancha si alguna curva se sale.
limH = {[1450 1475], [1505 1540]};
for k = 1:2
    set(st.hH(:,k), 'XData',st.tc(j), 'YData',st.Hh(k,j));
    v = st.Hh(k,j);
    if st.chkBase.Value
        B = st.baseAll.(sprintf('p%d_d%d', st.kp, st.dur));
        if isfield(B,'H'), v = [v, B.H(k,:)]; end %#ok<AGROW>
    end
    if ~isempty(st.ref) && isfield(st.ref,'Hh'), v = [v, st.ref.Hh(k,:)]; end %#ok<AGROW>
    v = v(isfinite(v));
    L = limH{k};
    if ~isempty(v), L = [min(L(1), min(v)), max(L(2), max(v))]; end
    set(st.axH(k), 'YLim', L + [-1 1]*0.02*(L(2)-L(1)));
end

% LOS MANDOS VAN EN ESCALONES, como en la Fig. 8 del articulo: el mando
% calculado en t_k se mantiene constante hasta t_k + Tc (retenedor de orden
% cero).  Unir los puntos con rectas dibujaria rampas que la planta nunca
% recibio.
for k = 1:3
    [xs, ys] = escalon_(st.tc(j), st.Uh(k,j), st.t);
    set(st.hU(:,k), 'XData',xs, 'YData',ys);
end
set(st.hLdc, 'XData',st.tc(j), 'YData',st.Dh(j));
set([st.axU st.axRU], 'YLim',[1 5]);
v = st.Dh(j);  v = v(isfinite(v));
if ~isempty(v), st.ax(4).YLim = [min(v) - 0.1, max(v) + 0.1]; end

set(st.hTh,   'XData',st.tc(j), 'YData',st.Th(j));
auto_(st.ax(5), st.Th(j), 0);

set(st.hCond, 'XData',st.tc(j), 'YData',st.Ch(j));
set(st.hCondL,'XData',[0 st.dur], 'YData',[1e12 1e12]);
c = st.Ch(j);  c = c(isfinite(c));
if ~isempty(c)
    st.ax(6).YLim = [max(1, min(c)/2), max(10, max(c)*2)];
end

set(st.hUpd,  'XData',st.tc(j), 'YData',st.Uc(j));
set(st.hNodo, 'XData',st.tc(j), 'YData',st.Nh(j));
set(st.hFrz,  'XData',st.tc(j), 'YData',10*st.Fh(j));
v = [st.Uc(j), st.Nh(j), 10*st.Fh(j)];  v = v(isfinite(v));
if ~isempty(v), st.ax(7).YLim = [min(0,min(v))-2, max(v)+5]; end

set(st.hTr,   'XData',st.tc(j), 'YData',st.Ph(1,j));
set(st.hLmax, 'XData',st.tc(j), 'YData',st.Ph(2,j));
set(st.hLmin, 'XData',st.tc(j), 'YData',st.Ph(3,j));
set(st.hTr0,  'XData',[0 st.dur], 'YData',st.trP0*[1 1]);
v = [st.Ph(:,j); st.trP0*ones(1,numel(j))];
if ~isempty(st.ref) && isfield(st.ref,'Ph'), v = [v(:); st.ref.Ph(1,:).']; end
v = v(isfinite(v) & v > 0);
if ~isempty(v)
    st.ax(8).YLim = [10^floor(log10(min(v))), 10^ceil(log10(max(v)))];
end
end

function auto_(a, v, lo)
v = v(isfinite(v));
if isempty(v), return, end
hi = max(v);
if hi <= lo, hi = lo + 1; end
a.YLim = [lo, hi*1.1 + eps];
end

% =========================================================================
function st = limpia_trazas_(st)
for k = 1:3
    set(st.hOut(:,k),'XData',nan,'YData',nan);
    set(st.hRef(:,k),'XData',nan,'YData',nan);
    set(st.hU(:,k),  'XData',nan,'YData',nan);
end
set(st.hLdc,'XData',nan,'YData',nan);
set(st.hH,  'XData',nan,'YData',nan);
set(st.hTh, 'XData',nan,'YData',nan);
set(st.hCond,'XData',nan,'YData',nan);
set(st.hUpd,'XData',nan,'YData',nan);
set(st.hNodo,'XData',nan,'YData',nan);
set(st.hFrz,'XData',nan,'YData',nan);
set(st.hTr,'XData',nan,'YData',nan);
set(st.hLmax,'XData',nan,'YData',nan);
set(st.hLmin,'XData',nan,'YData',nan);
set(st.hTr0,'XData',nan,'YData',nan);
end

% =========================================================================
function limpiar_(h)
st = cargar_(h);
st.stopReq = true;  st.running = false;  st.armed = false;
bloquea_(st,'on');
st = limpia_trazas_(st);
st.k = 0;  st.ref = [];  st.t = 0;
for k = 1:3
    set(st.hFij(:,k),'XData',nan,'YData',nan);
    set(st.hFijU(:,k),'XData',nan,'YData',nan);
end
set(st.hFijP,'XData',nan,'YData',nan);
set(st.hFijH,'XData',nan,'YData',nan);
st = leyendas_(st);
ejes_iniciales_(st);
st.tabY.Data = repmat({'—'},3,8);
try removeStyle(st.tabY); catch, end
st.tabE.Data = estado_vacio_();
planta_vacia_(st);
progreso_(st);
fase_(st,'listo');
aviso_(st,'');
guardar_(st.fig, st);
end

% =========================================================================
function encuadrar_(h)
st = cargar_(h);
if isfield(st,'dur') && ~isempty(st.dur), xl = [0 st.dur]; else, xl = [0 800]; end
set([st.ax st.axR st.axRU st.axU st.axH], 'XLim',xl);
ejeTiempo_(st, xl(2));
if isfield(st,'k') && st.k >= 1
    st = dibuja_(st);
    aviso_(st, sprintf('encuadrado a t = 0-%g s', xl(2)));
else
    ejes_iniciales_(st);
    aviso_(st, sprintf('escalas del artículo, t = 0-%g s', xl(2)));
end
guardar_(st.fig, st);
end

% =========================================================================
function fijar_(h)
st = cargar_(h);
if ~isfield(st,'k') || st.k < 1
    aviso_(st,'no hay corrida que fijar');  return
end
if st.running, aviso_(st,'pausa antes de fijar');  return, end
j = 1:st.k;
R = struct('tc',st.tc(j), 'Yh',st.Yh(:,j), 'Uh',st.Uh(:,j), 'Ph',st.Ph(:,j), ...
           'Hh',st.Hh(:,j), ...
           'iae',st.iae, 'itae',st.itae, 'ctrl',st.ddCtrl.Value, 'prueba',st.ddPrueba.Value, ...
           'lam',st.efLam.Value, 'ley',st.ddLey.Value, 'dur',st.dur, ...
           'modelo',estr_(st));
st.ref = R;
for k = 1:3
    set(st.hFij(:,k), 'XData',R.tc,'YData',R.Yh(k,:));
    [xs, ys] = escalon_(R.tc, R.Uh(k,:), R.tc(end) + st.Tc);
    set(st.hFijU(:,k),'XData',xs,'YData',ys);
end
set(st.hFijP,'XData',R.tc,'YData',R.Ph(1,:));
for k = 1:2
    set(st.hFijH(:,k),'XData',R.tc,'YData',R.Hh(k,:));
end
st = dibuja_(st);
st = leyendas_(st);
st = actualiza_lectura_(st);
aviso_(st, ['referencia: ' R.ctrl]);
guardar_(st.fig, st);
end

function s = corta_(s)
if numel(s) > 24, s = [s(1:21) '...']; end
end

% =========================================================================
function cambio_(h)
st = cargar_(h);
if st.running, return, end
if h == st.ddPrueba, ajustaDur_(st); end
st.armed = false;
st = limpia_trazas_(st);
st = leyendas_(st);                 % color y nombre del controlador elegido
st.k = 0;  st.t = 0;
if isfield(st,'tabY')
    st.tabY.Data = repmat({'—'},3,8);
    try removeStyle(st.tabY); catch, end
    st.tabE.Data = estado_vacio_();
    progreso_(st);
    fase_(st,'listo');
end
aviso_(st,'');
guardar_(st.fig, st);
end

% =========================================================================
function L = lectura_(st)
L = {sprintf('t = %7.1f s   de %g', st.t, st.dur), ...
     sprintf('control n%s %d   (Tc = %g s)', char(186), st.k, st.Tc), ...
     ''};
if st.literal && ~st.esPI
    L{end+1} = '*** LEY IMPRESA (con la errata) ***';
    L{end+1} = '';
end
if st.k < 1, return, end
j = st.k;

L{end+1} = '             TSSO     TRHO     PSSO';
L{end+1} = sprintf('y     %9.2f%9.2f%9.2f', st.Yh(:,j));
L{end+1} = sprintf('w     %9.2f%9.2f%9.2f', st.Wh(:,j));
L{end+1} = sprintf('h     %9.2f%9.2f   (BTU/lb)', st.Hh(:,j));
L{end+1} = '';
L{end+1} = 'ÍNDICES  (integrados hasta t)';
L{end+1} = sprintf('IAE   %9.3g%9.3g%9.3g', st.iae);
L{end+1} = sprintf('ITAE  %9.3g%9.3g%9.3g', st.itae);
B = st.baseAll.(sprintf('p%d_d%d', st.kp, st.dur));
if isfield(B,'iaeC')
    ib = find(B.t <= st.t + 1e-9, 1, 'last');
    if ~isempty(ib) && all(B.iaeC(:,ib) > 0)
        L{end+1} = sprintf('IAE/PI %8.2f%9.2f%9.2f', st.iae(:)./B.iaeC(:,ib));
        L{end+1} = sprintf('ITAE/PI%8.2f%9.2f%9.2f', st.itae(:)./B.itaeC(:,ib));
    end
end
L{end+1} = '';

if st.esPI
    L{end+1} = 'controlador: PI original de Usoro';
else
    L{end+1} = sprintf('λ = %g    β = %g', st.efLam.Value, st.efBeta.Value);
    if st.S.M.nd > 0
        L{end+1} = sprintf('modelo 3x4, k = %d: %d par./fila, ldc prealimentada', st.S.M.k, st.S.M.npar);
    else
        L{end+1} = sprintf('modelo 3x3, k = %d: %d par./fila', st.S.M.k, st.S.M.npar);
    end
    if st.S.adapt, e0 = 'ACTUALIZANDO'; else, e0 = 'CONGELADO'; end
    L{end+1} = sprintf('estimador: %s', e0);
    L{end+1} = sprintf('  %d actualizaciones de %d instantes', st.nUpd, st.k);
    if ~isnan(st.Th(j))
        L{end+1} = sprintf('  ‖Δθ‖ = %.4f', st.Th(j));
    end
    if ~isnan(st.Ch(j))
        L{end+1} = sprintf('cond(B0) = %.4g   (máx %.4g)', st.Ch(j), st.condMax);
    end
    if ~isnan(st.Ph(1,j))
        L{end+1} = sprintf('tr P = %.4g   (P(0): %.4g)', st.Ph(1,j), st.trP0);
        L{end+1} = sprintf('  λ(P) de %.3g a %.3g', st.Ph(3,j), st.Ph(2,j));
    end
    if ~isnan(st.Nh(j))
        L{end+1} = sprintf('nodo de la tabla: %g %% de carga', st.Nh(j));
    end
end

if ~isempty(st.ref)
    R = st.ref;
    L{end+1} = '';
    L{end+1} = repmat('=',1,36);
    L{end+1} = 'CONTRA LA REFERENCIA (verde)';
    L{end+1} = ['  ' corta_(R.ctrl)];
    L{end+1} = sprintf('  λ = %g    modelo %s', R.lam, R.modelo);
    if ~strcmp(R.prueba, st.ddPrueba.Value) || R.dur ~= st.dur
        L{end+1} = '  OJO: otra prueba o duración.';
    end
    L{end+1} = sprintf('IAE ref %8.3g%9.3g%9.3g', R.iae);
    L{end+1} = sprintf('act/ref %8.2f%9.2f%9.2f', st.iae./R.iae);
end

if st.diverge
    L{end+1} = '';
    L{end+1} = '*** DIVERGIÓ ***';
end
L = L(:);
end

% =========================================================================
function pdf_(h)
st = cargar_(h);  vuelve = enraiz_(st); %#ok<NASGU>
if st.running, aviso_(st,'pausa antes de exportar');  return, end
if ~isfield(st,'k') || st.k < 1
    aviso_(st,'no hay nada que exportar');  return
end
st.btIni.Enable = 'off';  st.btPdf.Enable = 'off';
try
    aviso_(st,'escribiendo el PDF...');  drawnow;
    aviso_(st, ['PDF: ' exporta_(st)]);
catch err
    aviso_(st, ['ERROR al exportar: ' err.message]);
end
st.btIni.Enable = 'on';  st.btPdf.Enable = 'on';
guardar_(st.fig, st);
end

% =========================================================================
function arch = exporta_(st)
vuelve = enraiz_(st); %#ok<NASGU>
tabAnterior = st.grupo.SelectedTab;
% Pagina por eje: TSSO, HSSO, TRHO, HRHO, PSSO, los tres mandos, la
% demanda y luego las demas.  PESTANA dice en que pestana esta cada eje,
% para traerla al frente antes de exportarlo.
ejes    = [st.ax(1) st.axH(1) st.ax(2) st.axH(2) st.ax(3) st.axU st.ax(4:8)];
pestana = [1 1 2 2 3 4 4 4 4 5:8];
arch = amin_informe(nombre_pdf_(st), ...
    'Réplica de Amin et al. (1984) — caldera de 600 MW de Usoro', ...
    params_(st), lectura_(st), ejes, ...
    'antes', @(k) alFrente_(st, pestana(k)), ...
    'anexo', anexo_(st));
st.grupo.SelectedTab = tabAnterior;
end

function alFrente_(st, k)
st.grupo.SelectedTab = st.tabs(k);
end

function n = nombre_pdf_(st)
n = sprintf('amin_sim_p%d_c%d_lam%g_t%.0f', st.kp, st.kc, st.efLam.Value, st.t);
if ~st.esPI && st.S.M.nd > 0, n = [n '_m34']; end
if ~st.esPI && st.S.M.k ~= 1,  n = sprintf('%s_k%d', n, st.S.M.k); end
if st.literal, n = [n '_LEYIMPRESA']; end
end

% =========================================================================
function P = params_(st)
P = {};
P{end+1} = 'Amin, Masada y Womack (1984), ACC, pp. 339-346';
P{end+1} = 'planta: modelo de 47 estados de Usoro (1977)';
P{end+1} = '';
P{end+1} = sprintf('prueba        : %s', st.ddPrueba.Value);
P{end+1} = sprintf('controlador   : %s', st.ddCtrl.Value);
P{end+1} = sprintf('duración      : %g s', st.dur);
if isfield(st,'dia') && ~isempty(st.dia)
    P{end+1} = sprintf('demanda       : SIN (%s), %s, %s', st.info.fuente, ...
                       st.info.dia.nombre, st.info.dia.nota);
    P{end+1} = sprintf('                %g MW -> 70 %%, %g MW -> 90 %%; t = 0 a las %s h', ...
                       st.info.dia.dmin, st.info.dia.dmax, st.info.dia.inicio);
end
P{end+1} = sprintf('instante      : t = %.1f s  (control nº %d)', st.t, st.k);
P{end+1} = '';
if st.esPI
    P{end+1} = 'control: los tres PI originales de Usoro';
else
    P{end+1} = sprintf('modelo AR : %s, N = %d, k = %d, T = %g s, %d par./fila', ...
                       st.S.M.estructura, st.S.M.N, st.S.M.k, st.S.M.T, st.S.M.npar);
    if st.S.M.nd > 0
        P{end+1} = '  3x4: ldc como entrada medida y prealimentada.';
        P{end+1} = '  NO ES DEL ARTÍCULO.';
    end
    if st.S.M.k ~= 1
        P{end+1} = sprintf('  k = %d: predictor a %d pasos, y*(t+%d|t) = w.', ...
                           st.S.M.k, st.S.M.k, st.S.M.k);
        P{end+1} = '  El artículo usa k = 1.';
    end
    P{end+1} = sprintf('Tc        : %g s', st.Tc);
    P{end+1} = sprintf('λ         : %g      (EL ARTÍCULO NO DA ESTE VALOR)', ...
                       st.efLam.Value);
    P{end+1} = sprintf('β         : %g      (TAMPOCO)', st.efBeta.Value);
    fuenteP = '';
    if isfield(st.S,'P0fuente'), fuenteP = st.S.P0fuente; end
    P{end+1} = sprintf('P(0)      : %s, tr P(0) = %.4g  (%d x %d)', fuenteP, ...
                       st.trP0, st.S.M.npar, st.S.M.npar);
    P{end+1} = sprintf('ley       : %s', st.ddLey.Value);
    if st.literal
        P{end+1} = '  OJO: es la ley tal como está impresa, con la errata';
        P{end+1} = '  de signo del bloque de salidas.  Ver AMIN_STC.';
    end
    if ~isempty(st.tabla)
        P{end+1} = sprintf('tabla     : %s', mat2str(st.tabla.pct));
        if st.interp, P{end+1} = '  interpolada con la carga (demanda real)'; end
        if isempty(st.congelar) && ~isempty(st.gmov)
            P{end+1} = sprintf('congelado : si la carga se mueve > %g %%/min y %g s después', ...
                               st.gmov.umbral, st.gmov.reten);
        elseif isinf(st.congelar(2))
            P{end+1} = 'congelado : toda la corrida (sin reidentificar)';
        else
            P{end+1} = sprintf('congelado : t = %g .. %g s', st.congelar);
        end
    else
        P{end+1} = 'tabla     : ninguna (modelo fijo)';
    end
end
P{end+1} = '';
P{end+1} = sprintf('línea base del PI dibujada : %s', sino_(st.chkBase.Value));
end

function s = estr_(st)
if st.esPI, s = '—'; else, s = sprintf('%s k%d', st.S.M.estructura, st.S.M.k); end
end

function s = sino_(b)
if b, s = 'sí'; else, s = 'no'; end
end

% =========================================================================
function C = anexo_(st)
%ANEXO_  La estructura numerica del modelo que el controlador esta usando.
C = {};
C{end+1} = 'ANEXO: EL MODELO AR QUE USA EL CONTROLADOR';
C{end+1} = repmat('=',1,66);
if st.esPI
    C{end+1} = 'No aplica: esta corrida es el PI original de Usoro.';
    return
end
M = st.S.M;
C{end+1} = '';
if M.k == 1
    C{end+1} = '  y(t) + A1 y(t-1) + ... + AN y(t-N)';
    C{end+1} = '        = B0 u(t-1) + B1 u(t-2) + ... + BN u(t-1-N) + e(t)';
    if M.nd > 0
        C{end+1} = '          + D0 ldc(t-1) + ... + DN ldc(t-1-N)        (modelo 3x4)';
    end
else
    C{end+1} = sprintf('  FORMA PREDICTORA a k = %d pasos:  y(t) = theta x(t-%d)', M.k, M.k);
    C{end+1} = sprintf('  y(t) + A1 y(t-%d) + ... + AN y(t-%d-N+1)', M.k, M.k);
    C{end+1} = sprintf('        = B0 u(t-%d) + ... + BN u(t-%d-N) + e(t)', M.k, M.k);
    if M.nd > 0
        C{end+1} = sprintf('          + D0 ldc(t-%d) + ... + DN ldc(t-%d-N)   (modelo 3x4)', M.k, M.k);
    end
    C{end+1} = '  Aqui «A» y «B» son G y F·B del predictor (Diofantina resuelta';
    C{end+1} = '  dentro de la estimacion), no las A y B de la ecuacion (16).';
end
C{end+1} = '';
C{end+1} = sprintf('%s   N = %d   k = %d   T = %g s   %d parámetros por fila', ...
                   M.estructura, M.N, M.k, M.T, M.npar);
C{end+1} = sprintf('y = [TSSO; TRHO; PSSO]     u = [CBMD; CXGG; CWSY]');
if M.nd > 0, C{end+1} = 'ldc = demanda de carga (medida, no manipulada)'; end
C{end+1} = '';
C{end+1} = ['punto de operación  u_ss = ' fila_(M.u_ss.')];
C{end+1} = ['                    y_ss = ' fila_(M.y_ss.')];
if M.nd > 0, C{end+1} = ['                    ldc_ss = ' fila_(M.d_ss.')]; end
C{end+1} = '';
C{end+1} = sprintf('cond(B0) = %.6g', cond(M.B(:,:,1)));
C{end+1} = sprintf('|z|max de det A(q^-1) = %.6f', zmax_(M));
C{end+1} = '';
for i = 0:M.N
    C{end+1} = sprintf('B%d =', i); %#ok<AGROW>
    C = mat_(C, M.B(:,:,i+1));
end
for i = 1:M.N
    C{end+1} = sprintf('A%d =', i); %#ok<AGROW>
    C = mat_(C, M.A(:,:,i));
end
if M.nd > 0
    for i = 0:M.N
        C{end+1} = sprintf('D%d =', i); %#ok<AGROW>
        C = mat_(C, M.D(:,:,i+1));
    end
end
C{end+1} = '';
C{end+1} = 'OJO CON EL SIGNO.  theta guarda [B0 ... BN  -A1 ... -AN]; aqui se';
C{end+1} = 'imprimen los Ai CON EL SIGNO DE LA ECUACION (16), o sea los de';
C{end+1} = 'arriba.  Confundir los dos convenios cambia el resultado.';
end

function C = mat_(C, X)
for r = 1:size(X,1)
    C{end+1} = ['   ' fila_(X(r,:))]; %#ok<AGROW>
end
C{end+1} = ''; %#ok<AGROW>
end

function s = fila_(v)
s = sprintf('%12.6g', v);
end

function z = zmax_(M)
N = M.N;  ny = M.ny;
Cm = zeros(ny*N);
for i = 1:N
    Cm(1:ny, (i-1)*ny + (1:ny)) = -M.A(:,:,i);
end
if N > 1, Cm(ny+1:end, 1:ny*(N-1)) = eye(ny*(N-1)); end
z = max(abs(eig(Cm)));
end

% =========================================================================
function st = actualiza_lectura_(st)
%ACTUALIZA_LECTURA_  Llena las dos tablas (salidas e indices; estado del
%   controlador) y la barra de avance.  El texto de LECTURA_ sigue
%   existiendo: es el que va a la portada del PDF.
progreso_(st);
if st.k < 1, return, end
j = st.k;
D = repmat({'—'}, 3, 8);
for r = 1:3
    D{r,1} = n_(st.Yh(r,j), '%.2f');
    D{r,2} = n_(st.Wh(r,j), '%.2f');
    D{r,3} = n_(st.Yh(r,j) - st.Wh(r,j), '%+.2f');
    D{r,4} = n_(st.iae(r), '%.4g');
    D{r,5} = n_(st.itae(r), '%.4g');
end
rel = nan(3,3);                        % IAE/PI, ITAE/PI, IAE/ref
B = st.baseAll.(sprintf('p%d_d%d', st.kp, st.dur));
if isfield(B,'iaeC')
    ib = find(B.t <= st.t + 1e-9, 1, 'last');
    if ~isempty(ib) && all(B.iaeC(:,ib) > 0)
        rel(:,1) = st.iae(:)  ./ B.iaeC(:,ib);
        rel(:,2) = st.itae(:) ./ B.itaeC(:,ib);
    end
end
if ~isempty(st.ref), rel(:,3) = st.iae(:) ./ st.ref.iae(:); end
for r = 1:3
    for c = 1:3
        if isfinite(rel(r,c)), D{r,5+c} = n_(rel(r,c), '%.2f'); end
    end
end
st.tabY.Data = D;

% Verde si mejora (< 1), rojo si empeora.  UISTYLE es de R2019b.
try
    removeStyle(st.tabY);
    [ib, jb] = find(rel < 1);
    if ~isempty(ib)
        addStyle(st.tabY, uistyle('BackgroundColor',st.C.bien), 'cell', [ib, jb+5]);
    end
    [im, jm] = find(rel > 1);
    if ~isempty(im)
        addStyle(st.tabY, uistyle('BackgroundColor',st.C.mal), 'cell', [im, jm+5]);
    end
catch
end

st.tabE.Data = estado_(st);
end

% =========================================================================
function E = estado_vacio_()
E = {'controlador','—'; 'estimador','—'; '‖Δθ‖','—'; 'cond(B₀)','—'; ...
     'tr P','—'; 'nodo de la tabla','—'};
end

function E = estado_(st)
E = {};
if st.esPI
    E(end+1,:) = {'controlador', 'PI de Usoro'};
    E(end+1,:) = {'mando', 'los tres PI originales'};
else
    j = st.k;
    E(end+1,:) = {'modelo', sprintf('%s, k = %d, %d par./fila', ...
                  st.S.M.estructura, st.S.M.k, st.S.M.npar)};
    E(end+1,:) = {'λ  /  β', [n_(st.efLam.Value,'%g') '  /  ' n_(st.efBeta.Value,'%g')]};
    E(end+1,:) = {'Tc', [n_(st.Tc,'%g') ' s']};
    if st.literal, E(end+1,:) = {'ley', 'IMPRESA (con la errata)'}; end
    if st.S.adapt, e0 = 'ACTUALIZANDO'; else, e0 = 'congelado'; end
    E(end+1,:) = {'estimador', e0};
    E(end+1,:) = {'actualizaciones', sprintf('%d de %d instantes', st.nUpd, st.k)};
    if ~isnan(st.Th(j)), E(end+1,:) = {'‖Δθ‖', n_(st.Th(j),'%.4f')}; end
    if ~isnan(st.Ch(j))
        E(end+1,:) = {'cond(B₀)', [n_(st.Ch(j),'%.4g') '  (máx ' n_(st.condMax,'%.4g') ')']};
    end
    if ~isnan(st.Ph(1,j))
        E(end+1,:) = {'tr P', [n_(st.Ph(1,j),'%.4g') '  (P(0): ' n_(st.trP0,'%.4g') ')']};
        E(end+1,:) = {'λ(P)', [n_(st.Ph(3,j),'%.3g') '  a  ' n_(st.Ph(2,j),'%.3g')]};
    end
    if ~isnan(st.Nh(j))
        if st.interp
            E(end+1,:) = {'tabla', ['interpolada a ' n_(st.Nh(j),'%.1f') ' %']};
        else
            E(end+1,:) = {'nodo de la tabla', [n_(st.Nh(j),'%g') ' % de carga']};
        end
    end
end
if isfield(st,'dia') && ~isempty(st.dia) && isfield(st,'info')
    hm = sscanf(st.info.dia.inicio, '%d:%d');
    m = mod(round((hm(1)*3600 + hm(2)*60 + st.t)/60), 1440);
    E(end+1,:) = {'hora del día', sprintf('%d:%02d  (%s)', floor(m/60), mod(m,60), st.info.dia.nombre)};
end
if ~isempty(st.ref)
    E(end+1,:) = {'referencia', corta_(st.ref.ctrl)};
    if ~strcmp(st.ref.prueba, st.ddPrueba.Value) || st.ref.dur ~= st.dur
        E(end+1,:) = {'', 'OJO: otra prueba o duración'};
    end
end
if st.diverge, E(end+1,:) = {'', '*** DIVERGIÓ ***'}; end
end

function s = n_(v, fmt)
%N_  Numero con coma decimal.
s = strrep(sprintf(fmt, v), '.', ',');
end

% =========================================================================
function progreso_(st)
%PROGRESO_  Barra de avance y etiqueta de fase.
f = 0;
if isfield(st,'dur') && ~isempty(st.dur) && st.dur > 0 && isfield(st,'t')
    f = min(max(st.t/st.dur, 0), 1);
end
if f <= 0
    st.gBar.ColumnWidth = {0, '1x'};
elseif f >= 1
    st.gBar.ColumnWidth = {'1x', 0};
else
    st.gBar.ColumnWidth = {sprintf('%.4fx', f), sprintf('%.4fx', 1-f)};
end
if st.running
    st.lblFase.Text = sprintf('corriendo  ·  t = %.0f de %g s', st.t, st.dur);
end
end

function fase_(st, s)
%FASE_  Etiqueta de color con la fase de la corrida y el boton de marcha.
C = st.C;
switch s
    case 'listo',     c = C.listo;  txt = 'listo';
    case 'corriendo', c = C.acento; txt = 'corriendo';
    case 'pausa',     c = C.pausa;  txt = sprintf('en pausa  ·  t = %.0f de %g s', st.t, st.dur);
    case 'terminado', c = C.fija;   txt = sprintf('terminado  ·  %g s', st.dur);
    case 'divergio',  c = C.aviso;  txt = sprintf('divergió en t = %.0f s', st.t);
    otherwise,        c = C.listo;  txt = s;
end
st.lblFase.BackgroundColor = c;
st.lblFase.Text = txt;
if strcmp(s,'corriendo')
    st.btIni.Text = 'Pausar';     st.btIni.BackgroundColor = C.pausa;
elseif strcmp(s,'pausa')
    st.btIni.Text = 'Continuar';  st.btIni.BackgroundColor = C.acento;
else
    st.btIni.Text = 'Iniciar';    st.btIni.BackgroundColor = C.acento;
end
end

% =========================================================================
function [x, y] = escalon_(t, v, tfin)
%ESCALON_  Coordenadas de una grafica en escalones (retenedor de orden cero):
%   el valor v(i) se mantiene de t(i) a t(i+1), y el ultimo hasta TFIN.
t = t(:).';  v = v(:).';
n = numel(t);
if n == 0, x = nan;  y = nan;  return, end
if nargin < 3 || isempty(tfin) || tfin <= t(end), tfin = t(end); end
x = reshape([t; [t(2:end) tfin]], 1, []);
y = reshape([v; v], 1, []);
end

% =========================================================================
% LA TABLA 4
% =========================================================================
function T = comp_vacia_()
%COMP_VACIA_  IAE e ITAE de cada controlador (renglon) y prueba (columnas
%   1-3: 90->70, 4-6: 70->90; renglones: STC y STC modificado), los del PI con que se normalizan y la
%   configuracion con que se corrieron.
T = struct('cfg','', 'iae',nan(2,6), 'itae',nan(2,6), ...
           'piIAE',nan(1,6), 'piITAE',nan(1,6));
end

function s = cfg_(st)
%CFG_  Lo que tiene que ser igual en todas las corridas de la tabla.
s = sprintf('modelo %s, k = %s, lambda = %g, beta = %g, ley %s, %g s', ...
    strtrim(strtok(st.ddMod.Value,'(')), strtrim(strrep(strtok(st.ddK.Value,'('),'k =','')), ...
    st.efLam.Value, st.efBeta.Value, strtrim(strtok(st.ddLey.Value,'(')), st.dur);
end

function st = comp_guarda_(st)
%COMP_GUARDA_  Al terminar una corrida de las rampas, guarda sus indices en
%   la Tabla 4.  El PI no lleva renglon (su cociente es 1); el mando cada
%   2 s, la tabla pura y el 75 % constante no son de la tabla.  Si la
%   configuracion cambio (lambda, beta, modelo, k, ley o duracion), la tabla
%   empieza de nuevo: no se mezclan.
if st.esPI || st.kc > 3 || st.kp > 2 || st.k < 1, return, end
B = st.baseAll.(sprintf('p%d_d%d', st.kp, st.dur));
ib = find(B.t <= st.t + 1e-9, 1, 'last');
if isempty(ib), return, end
cfg = cfg_(st);
nota = '';
if ~strcmp(st.comp.cfg, cfg)
    if any(isfinite(st.comp.iae(:)))
        nota = '  La configuración cambió: la tabla empezó de nuevo.';
    end
    st.comp = comp_vacia_();
    st.comp.cfg = cfg;
end
r = st.kc - 1;
c = 3*(st.kp - 1) + (1:3);
st.comp.iae(r,c)    = st.iae;
st.comp.itae(r,c)   = st.itae;
st.comp.piIAE(c)    = B.iaeC(:,ib).';
st.comp.piITAE(c)   = B.itaeC(:,ib).';
pinta_comp_(st);
aviso_(st, ['Tabla 4: guardado ' st.compNom{r} ', ' ...
            strtrim(strtok(st.ddPrueba.Value,'(')) '.' nota]);
end

function [R, Ri] = comp_cocientes_(T)
n  = size(T.iae, 1);
R  = T.iae  ./ (ones(n,1)*T.piIAE);
Ri = T.itae ./ (ones(n,1)*T.piITAE);
end

function pinta_comp_(st)
%PINTA_COMP_  Llena las dos tablas de la pestana (IAE e ITAE contra el PI)
%   y las colorea como la lectura: verde < 1, rojo > 1.
[R, Ri] = comp_cocientes_(st.comp);
llena_comp_(st.tabC,  R,  st.C);
llena_comp_(st.tabCi, Ri, st.C);
if isempty(st.comp.cfg)
    st.lblComp.Text = ['Vacía.  Corre el STC y el modificado en las dos ' ...
        'rampas (velocidad «máxima» basta); cada corrida terminada se agrega aquí.'];
else
    st.lblComp.Text = ['Corridas con: ' st.comp.cfg '.'];
end
end

function llena_comp_(tb, R, C)
V = [R mean(R,2)];                     % J: NaN mientras falte una prueba
D = repmat({'—'}, size(V));
for i = 1:size(V,1)
    for j = 1:size(V,2)
        if isfinite(V(i,j))
            if V(i,j) >= 10, f = '%.1f'; else, f = '%.2f'; end
            D{i,j} = strrep(sprintf(f, V(i,j)), '.', ',');
        end
    end
end
tb.Data = D;
try
    removeStyle(tb);
    [ib, jb] = find(V < 1);
    if ~isempty(ib)
        addStyle(tb, uistyle('BackgroundColor',C.bien), 'cell', [ib, jb]);
    end
    [im, jm] = find(V > 1);
    if ~isempty(im)
        addStyle(tb, uistyle('BackgroundColor',C.mal), 'cell', [im, jm]);
    end
catch
end
end

function exportaTabla_(h)
st = cargar_(h);  vuelve = enraiz_(st); %#ok<NASGU>
[R, Ri] = comp_cocientes_(st.comp);
ok = all(isfinite(R), 2);
if ~any(ok)
    aviso_(st, ['Tabla 4: ningún renglón completo.  Hace falta el mismo ' ...
                'controlador en las dos rampas.']);
    return
end
% Se propone la carpeta de la ultima exportacion (la del articulo, si ya
% se eligio una vez) o resultados/articulo.
if isfield(st,'dirTex') && ~isempty(st.dirTex) && exist(st.dirTex,'dir')
    d0 = st.dirTex;
else
    d0 = fullfile(st.raiz,'resultados','articulo');
    if ~exist(d0,'dir'), mkdir(d0); end
end
[f, d] = uiputfile({'*.tex','LaTeX (*.tex)'}, 'Guardar la Tabla 4', ...
                   fullfile(d0,'tabla4.tex'));
figure(st.fig);
if isequal(f,0), return, end
try
    amin_tabla4_tex(fullfile(d,f), st.compNom(ok), R(ok,:), Ri(ok,:), ...
                    st.comp.piIAE, st.comp.piITAE, st.C.bien, st.C.mal, st.comp.cfg);
    st.dirTex = d;
    aviso_(st, sprintf('Tabla 4 (%s): %s', strjoin(st.compNom(ok), ', '), ...
                       fullfile(d,f)));
catch err
    aviso_(st, ['ERROR al escribir la tabla: ' err.message]);
end
guardar_(st.fig, st);
end

function vaciaTabla_(h)
st = cargar_(h);
st.comp = comp_vacia_();
pinta_comp_(st);
aviso_(st, 'Tabla 4 vacía.');
guardar_(st.fig, st);
end

% =========================================================================
%                          PESTANA «PLANTA»
% =========================================================================
function D = planta_def_()
%PLANTA_DEF_  Que se muestra en el esquema y donde.
%   x, y   centro del recuadro, en pixeles de codigo/esquema_planta.png
%          (1284 x 634).
%   col    columna del registro de DIGPTE47 (ver su YLOG):
%            2 ntr, 3 mwo, 4 psso, 7 cacvd, 10 vdrw, 12 cfwd, 13 cdwd,
%            18 nfp, 24 nrp, 25 ncp, 26 tsso, 27 trho, 29..31 cbmd cxgg cwsy,
%            35 ldc.  0 = el tiempo simulado.
%   tipo   'val' valor con unidades; 'vgob' / 'vxd' apertura de valvula en %
%          (gobernador: mando de 0 a 5 V; agua de alimentacion y deareador:
%          transductor de 1 a 5 V); 'ldc' demanda en V y en %; 't' tiempo.
fd = [1 1 1];  fm = [0.93 0.96 1.00];  fv = [1.00 0.97 0.80];
D = struct('x',{}, 'y',{}, 'tit',{}, 'col',{}, 'fmt',{}, 'uni',{}, ...
           'tipo',{}, 'fondo',{});
D = add_(D,   95, 120, 'Vol. agua domo',    10, '%.1f', 'ft³',   'val', fd);
D = add_(D,  350, 112, 'CWSY',              31, '%.2f', 'V',     'val', fm);
D = add_(D,  458, 112, 'TSSO',              26, '%.1f', '°R',    'val', fd);
D = add_(D,  458, 152, 'PSSO',              28, '%.1f', 'psia',  'val', fd);
D = add_(D,  465, 255, 'CBMD',              29, '%.2f', 'V',     'val', fm);
D = add_(D,  805, 128, 'Vel. turbina',       2, '%.1f', 'rad/s', 'val', fd);
D = add_(D, 1195,  92, 'Potencia',           3, '%.1f', 'MW',    'val', fd);
D = add_(D,  770, 318, 'TRHO',              27, '%.1f', '°R',    'val', fd);
D = add_(D,  655, 338, 'CXGG',              30, '%.2f', 'V',     'val', fm);
D = add_(D,  232, 432, 'Vel. bomba rec.',   24, '%.1f', 'rad/s', 'val', fd);
D = add_(D,  505, 598, 'Vel. bomba alim.',  18, '%.1f', 'rad/s', 'val', fd);
D = add_(D, 1062, 470, 'Vel. bomba cond.',  25, '%.1f', 'rad/s', 'val', fd);
D = add_(D,  120, 470, 'Demanda ldc',       35, '%.2f', 'V',     'ldc', fd);
D = add_(D,   60,  25, 'Tiempo',             0, '%.0f', 's',     't',   fd);
D = add_(D,  650,  72, '',                   7, '%.0f', '%',     'vgob', fv);
D = add_(D,  360, 575, '',                  12, '%.0f', '%',     'vxd',  fv);
D = add_(D,  835, 575, '',                  13, '%.0f', '%',     'vxd',  fv);
end

function D = add_(D, x, y, tit, col, fmt, uni, tipo, fondo)
D(end+1) = struct('x',x, 'y',y, 'tit',tit, 'col',col, 'fmt',fmt, ...
                  'uni',uni, 'tipo',tipo, 'fondo',fondo);
end

% =========================================================================
function st = planta_construye_(st)
%PLANTA_CONSTRUYE_  El esquema de la unidad de 600 MW de Usoro (1977), tomado
%   de Quintero-Marmol (2025), con los valores del modelo de 47 estados
%   encima: los que muestra el simulador de Galindo (2001) ---volumen de
%   agua del domo, temperaturas, velocidades de turbina y bombas, potencia---
%   mas la presion, los tres mandos, la demanda de carga y la apertura de
%   las valvulas.  Se actualiza en cada instante de control.
gp = uigridlayout(st.tabPl, [2 1]);
gp.RowHeight = {'1x','fit'};
gp.Padding = [6 6 6 6];  gp.RowSpacing = 2;
a = uiaxes(gp);
a.XTick = [];  a.YTick = [];  a.XColor = 'none';  a.YColor = 'none';
a.Color = 'w';  a.Box = 'off';
try a.Toolbar.Visible = 'off'; catch, end
try disableDefaultInteractivity(a); catch, end
arch = fullfile(fileparts(mfilename('fullpath')), 'esquema_planta.png');
if exist(arch,'file') == 2
    img = imread(arch);
    image(a, img);
    axis(a, 'image');
    a.XLim = [0.5 size(img,2)+0.5];  a.YLim = [0.5 size(img,1)+0.5];
    a.YDir = 'reverse';
else
    a.XLim = [0 1284];  a.YLim = [0 634];  a.YDir = 'reverse';
    text(a, 642, 317, 'Falta codigo/esquema_planta.png', ...
         'HorizontalAlignment','center', 'Interpreter','none');
end
hold(a, 'on');
D = planta_def_();
h = gobjects(1, numel(D));
for k = 1:numel(D)
    h(k) = text(a, D(k).x, D(k).y, planta_txt_(D(k), NaN), ...
        'HorizontalAlignment','center', 'VerticalAlignment','middle', ...
        'FontSize',9, 'Interpreter','none', 'Clipping','on', ...
        'BackgroundColor',D(k).fondo, 'EdgeColor',[0.45 0.45 0.45], ...
        'Margin',2);
end
st.pl = struct('ax',a, 'h',h, 'D',D);
u = uilabel(gp, 'FontColor',st.C.tenue, 'FontSize',11, 'WordWrap','on', ...
    'Text',['Esquema de la unidad de 600 MW (Usoro, 1977), tomado de ' ...
            'Quintero-Mármol (2025).  Valores del modelo de 47 estados en el ' ...
            'instante actual; azul: mandos del controlador; amarillo: apertura ' ...
            'de las válvulas.']);
u.Layout.Row = 2;
end

% =========================================================================
function st = planta_actualiza_(st)
%PLANTA_ACTUALIZA_  Pone en el esquema los valores del instante actual.
if ~isfield(st,'pl') || ~isfield(st,'x') || isempty(st.x) || ~isfield(st,'P')
    return
end
try
    [~, yl] = digpte47(st.t, st.x, st.P);
catch
    return
end
D = st.pl.D;
for k = 1:numel(D)
    switch D(k).tipo
        case 't',    v = st.t;
        case 'vgob', v = 100*xducer(st.P.kn0, st.P.kn5, st.P.kavl, st.P.kavu, yl(D(k).col));
        case 'vxd',  v = 100*xducer(st.P.kcl, st.P.kcu, st.P.kavl, st.P.kavu, yl(D(k).col));
        otherwise,   v = yl(D(k).col);
    end
    set(st.pl.h(k), 'String', planta_txt_(D(k), v));
end
end

% =========================================================================
function planta_vacia_(st)
%PLANTA_VACIA_  Vuelve a poner guiones (al limpiar).
if ~isfield(st,'pl'), return, end
for k = 1:numel(st.pl.D)
    set(st.pl.h(k), 'String', planta_txt_(st.pl.D(k), NaN));
end
end

% =========================================================================
function s = planta_txt_(d, v)
%PLANTA_TXT_  Texto de un recuadro: titulo y, debajo, valor con unidades.
if isnan(v)
    val = '—';
elseif strcmp(d.tipo, 'ldc')
    val = sprintf('%s V (%s %%)', n_(v, d.fmt), n_(20*v, '%.1f'));
else
    val = [n_(v, d.fmt) ' ' d.uni];
end
if isempty(d.tit)
    s = val;
else
    s = sprintf('%s\n%s', d.tit, val);
end
end

% =========================================================================
function aviso_(st, s)
st.lblEstado.Text = s;
end

function guardar_(fig, st)
setappdata(fig,'st',st);
setappdata(fig,'stopReq',st.stopReq);
end

function st = cargar_(h)
fig = ancestor(h,'figure');
st = getappdata(fig,'st');
end

function cerrar_(fig)
setappdata(fig,'stopReq',true);
delete(fig);
end
