function F = amin_fig5(varargin)
%AMIN_FIG5  La figura 5 del articulo: planta contra modelo AR, mismas entradas.
%
%   F = AMIN_FIG5
%   F = AMIN_FIG5('valvula',true, 'modelo','datos/amin_modelo_valvula.mat')
%   F = AMIN_FIG5('dur',1400, 'semilla',7, 'modelo','datos/amin_modelo.mat', ...
%                 'arch','resultados/amin_fig5.png')
%
%   «Fig. 5: Comparison of the responses, to the same set of inputs, from
%    the open loop system and from the identified AR model.»   (p. 343)
%
%   EXPERIMENTO.  Igual que una corrida de identificacion de AMIN_DATOS
%   ---75 %, lazo abierto, entradas gaussianas alrededor de u_ss con
%   sigma = [0,1 0,3 0,6] V retenidas 20 s--- pero:
%
%     * con OTRA semilla: son datos que el modelo no vio al estimarse, asi
%       que la figura es una VALIDACION y no un ajuste sobre la muestra;
%     * durante 1400 s, lo que dura el eje de la figura del articulo, para
%       ver lo que el articulo dice: el modelo sigue a la planta unos 400 s
%       y despues se separa porque la planta se va del 75 %.
%
%   EL MODELO arranca, como la planta, en el estado estable: su historia
%   inicial son valores de estado estable (cero incremental), que es el
%   «x(0-k) contained steady state values» del articulo.  Se dibujan:
%
%     planta                    la respuesta en lazo abierto (x del articulo)
%     modelo, simulacion libre  el modelo solo con las entradas: usa SUS
%                               salidas pasadas, nunca las medidas.  Es lo
%                               que parece dibujar el articulo (el * )
%     modelo, a un paso         con las salidas MEDIDAS hasta t-20 s; mas
%                               facil.  No se dibuja (Amin no lo dibuja):
%                               va en F.Yh y en los indices
%
%   INDICES.  IAE del error del modelo (modelo - planta) en dos ventanas,
%   0-400 s y 400-1400 s, y ajuste en % (100(1 - |e|/|y - media|)).
%
%   See also AMIN_DATOS, AMIN_IDENT, AMIN_PRED.

opt = struct('dur',1400, 'semilla',7, 'modelo',fullfile('datos','amin_modelo.mat'), ...
             'arch',fullfile('resultados','amin_fig5.png'), 'corte',400, ...
             'entradas',fullfile('datos','amin_fig5_entradas.mat'), ...
             'valvula',false, 'sigma',[0.1 0.3 0.6], 'Useq',[]);
for i = 1:2:numel(varargin), opt.(varargin{i}) = varargin{i+1}; end
% Las entradas guardadas son las de las desviaciones del articulo: con otras
% se sortean siempre.
if ~isequal(opt.sigma(:), [0.1;0.3;0.6]), opt.entradas = ''; end

q = load(opt.modelo);  M = q.M;
if ~isfield(M,'nd')
    M = amin_modelo(M.th, M.N, M.nu, M.ny, M.k, M.T, M.u_ss, M.y_ss, M.pct);
end
S = amin_estacionario(75, 'verbose',false);
M = amin_modelo(M.th, M.N, M.nu, M.ny, M.k, M.T, S.u(:), S.y(:), 75, ...
                M.d_ss);                                   % mismo punto de operacion

T = 20;  Ts = 0.1;  stride = round(T/Ts);  nS = floor(opt.dur/T) + 1;
% LAS ENTRADAS SE GUARDAN.  randn('state',s) NO da la misma secuencia en
% MATLAB que en Octave: con la misma semilla salian dos experimentos
% distintos.  La secuencia se sortea una vez, se guarda en
% datos/amin_fig5_entradas.mat y, si existe, se lee: asi la figura es la
% misma en cualquier maquina.  Con 'entradas','' se sortea siempre.
sig = opt.sigma(:);
Useq = opt.Useq;          % una secuencia dada (3 x n) tiene prioridad
if ~isempty(Useq), opt.entradas = ''; nS = min(nS, size(Useq,2)); Useq = Useq(:,1:nS); end
if ~isempty(opt.entradas) && exist(opt.entradas,'file') == 2
    q = load(opt.entradas);
    if size(q.Useq,2) >= nS, Useq = q.Useq(:,1:nS); end
end
if isempty(Useq)
    try, randn('state', opt.semilla); catch, rng(opt.semilla); end %#ok<RAND>
    Useq = S.u(:)*ones(1,nS) + diag(sig)*randn(3,nS);
    if ~isempty(opt.entradas)
        semilla = opt.semilla; %#ok<NASGU>
        save(opt.entradas, 'Useq', 'semilla', '-v7');
    end
end

P = amin_planta(S.base, 'ldcStart',S.ldc, 'ldcRate',0, 'ldcT0',0, 'ldcT1',0, ...
                'samples',nS*stride+1);
P.x0 = S.x0;  P.ldc = S.ldc;  P.openLoop = [true true true];
% VALVULA DE LA TURBINA FIJA (hueco 9): sin el lazo de potencia de la
% turbina (kc1tr = 0) la planta en lazo abierto deja de ser inestable en
% presion.  Es la configuracion que se parece a la figura 5 del articulo.
if opt.valvula, P.kc1tr = 0; end
uNow = Useq(:,1);  P.uFcn = @(z) uNow;
x = S.x0(:);  t = 0;  Y = nan(3,nS);  tt = (0:nS-1)*T;  nOK = nS;
for s = 1:nS
    uNow = Useq(:,s);  P.uFcn = @(z) uNow;
    [~, yl] = digpte47(t, x, P);  Y(:,s) = yl(26:28).';
    for i = 1:stride
        xd1 = digpte47(t,x,P);  xd2 = digpte47(t+Ts/2,x+(Ts/2)*xd1,P);
        xd3 = digpte47(t+Ts/2,x+(Ts/2)*xd2,P);  xd4 = digpte47(t+Ts,x+Ts*xd3,P);
        x = x + (Ts/6)*(xd1+2*xd2+2*xd3+xd4);  x = pte47_clamp(x,P);  t = t + Ts;
    end
    if ~all(isfinite(x)) || ~isreal(x), nOK = s; break, end
end
U = Useq(:,1:nOK);  Y = Y(:,1:nOK);  tt = tt(1:nOK);

% historia inicial = estado estable (N+k muestras antes de t = 0)
np = M.N + M.k;
Up = [S.u(:)*ones(1,np), U];  Yp = [S.y(:)*ones(1,np), Y];
if M.nd > 0
    [Yh, Ys] = amin_pred(M, Up, Yp, S.ldc*ones(1,size(Up,2)));
else
    [Yh, Ys] = amin_pred(M, Up, Yp);
end
Yh = Yh(:, np+1:end);  Ys = Ys(:, np+1:end);

F = struct('t',tt, 'U',U, 'Y',Y, 'Ys',Ys, 'Yh',Yh, 'opt',opt, 'M',M);
% CUANDO SE SEPARA EL MODELO.  Primer instante en que la simulacion libre se
% aleja de la planta mas del 1 % del valor de estado estable de la salida
% (el mismo 1 % del criterio de amplitudes del articulo).
for r = 1:3
    j = find(abs(Ys(r,:) - Y(r,:)) > 0.01*abs(S.y(r)), 1);
    if isempty(j), F.tSep(r) = NaN; else, F.tSep(r) = tt(j); end
end
F.zmax = zmax_(M);                 % mayor polo del modelo (|z| > 1: inestable)
F.dYfin = Y(:,end) - Y(:,1);       % cuanto se alejo la planta al final
v = {tt <= opt.corte, tt > opt.corte};
for w = 1:2
    j = v{w};
    for r = 1:3
        e = Ys(r,j) - Y(r,j);  e1 = Yh(r,j) - Y(r,j);
        F.iaeLibre(r,w) = sum(abs(e))*T;   F.iaeUno(r,w) = sum(abs(e1))*T;
        d = norm(Y(r,j) - mean(Y(r,j)));
        F.ajLibre(r,w) = 100*(1 - norm(e)/d);  F.ajUno(r,w) = 100*(1 - norm(e1)/d);
    end
end

% ------------------------------------------------------------ figura
% CON LA ESCALA DE AMIN, fija: temperaturas 1400-1520 R (140,00-152,00 x10),
% presion 2000-3200 psia (200,00-320,00 x10), tiempo 0-1400 s (0-140 x10),
% los tres paneles en su orden (TRHO, TSSO, PSSO), la planta con x y el
% modelo con *.  Lo que se sale del cuadro SE SALE: reproducir una figura
% con otra escala es reproducir otra figura (igual criterio que AMIN_FIGS).
if ~isempty(opt.arch)            % sin archivo no se dibuja (uso por lotes)
nomY = {'TSSO,  R x10^1', 'TRHO,  R x10^1', 'PSSO,  PSIA x10^1'};
ord  = [2 1 3];
lim  = {[1400 1520], [1400 1520], [2000 3200]};
tk   = {1400:40:1520, 1400:40:1520, 2000:400:3200};
cada = 5;                                          % un marcador cada 100 s
h = figure('Color','w', 'Position',[60 60 620 900], 'Name','Figura 5');
for p = 1:3
    r = ord(p);
    subplot(3,1,p); hold on; box on
    plot(tt, Y(r,:),  'k-', 'LineWidth', 1.1);
    plot(tt, Ys(r,:), 'k-', 'LineWidth', 1.1);
    h1 = plot(tt(1:cada:end), Y(r,1:cada:end),  'kx', 'MarkerSize', 7, 'LineWidth', 1.1);
    h2 = plot(tt(1:cada:end), Ys(r,1:cada:end), 'k*', 'MarkerSize', 7);
    set(gca, 'XLim',[0 opt.dur], 'YLim',lim{p}, 'YTick',tk{p}, ...
        'YTickLabel', strrep(cellstr(num2str(tk{p}(:)/10, '%.2f')), '.', ','), ...
        'XTick',0:200:opt.dur, ...
        'XTickLabel', strrep(cellstr(num2str((0:200:opt.dur).'/10, '%.2f')), '.', ','), ...
        'FontName','Courier', 'FontSize',8, 'Clipping','on');
    ylabel(nomY{r});  xlabel('TIEMPO ,  s  x10^1');
    legend([h1 h2], {'RESPUESTA EN LAZO ABIERTO A ENTRADAS ALEATORIAS', ...
                     'SALIDA PREDICHA POR EL MODELO AR'}, ...
           'Location','northwest', 'Box','off', 'FontName','Courier', 'FontSize',7);
end
print(h, opt.arch, '-dpng', '-r200');
end
end

% =========================================================================
function z = zmax_(M)
%ZMAX_  Mayor modulo de las raices de det A(q^-1), por la forma companera.
N = M.N;  ny = M.ny;
C = zeros(ny*N);
for i = 1:N
    C(1:ny, (i-1)*ny + (1:ny)) = -M.A(:,:,i);
end
if N > 1, C(ny+1:end, 1:ny*(N-1)) = eye(ny*(N-1)); end
z = max(abs(eig(C)));
end
