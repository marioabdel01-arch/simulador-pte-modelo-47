function varargout = amin_hmi_motor(accion, varargin)
%AMIN_HMI_MOTOR  El motor de la consola AMIN_HMI: la planta de 47 estados con
%   los controladores de Amin, Masada y Womack (1984) y los mandos de un
%   operador.  No tiene ventana (ver AMIN_HMI_PRUEBA).
%
%   M = AMIN_HMI_MOTOR('crear', PCT)            arranca en el estado estable
%                                               de PCT = 70, 75, 80, 85 o 90 %
%   M = AMIN_HMI_MOTOR('avanzar', M, N)         N pasos RK4 de 0,1 s
%   M = AMIN_HMI_MOTOR('controlador', M, KC)    1 PI de Usoro
%                                               2 auto-sintonizable (fig. 6)
%                                               3 modificado, mando 20 s (fig. 7)
%                                               4 modificado, mando 2 s
%                                               5 tabla, estimador apagado
%   M = AMIN_HMI_MOTOR('modelo', M, MOD, K)     MOD = 1 (3x3) o 2 (3x4); K = 1 o 2
%   M = AMIN_HMI_MOTOR('lambda', M, L)          en vivo
%   M = AMIN_HMI_MOTOR('beta', M, B)            en vivo
%   M = AMIN_HMI_MOTOR('ley', M, LITERAL)       true = la ley impresa (errata)
%   M = AMIN_HMI_MOTOR('estimador', M, MODO)    'auto' | 'congelado' | 'encendido'
%   M = AMIN_HMI_MOTOR('reiniciaP', M)          P = P(0) (heredada o P0*I)
%   M = AMIN_HMI_MOTOR('demanda', M, PCT, VEL)  rampa de carga a VEL %/min
%   M = AMIN_HMI_MOTOR('evento', M, CUAL, TF)   'tension'|'frecuencia'|'ventiladores'
%   M = AMIN_HMI_MOTOR('indices0', M)           reinicia IAE e ITAE
%   V = AMIN_HMI_MOTOR('variables', M)
%   C = AMIN_HMI_MOTOR('catalogo')
%   A = AMIN_HMI_MOTOR('alarmas', M)
%
%   NO REIMPLEMENTA NADA DEL CONTROLADOR.  El instante de control es el de
%   AMIN_LAZO: AMIN_NODO y AMIN_STC_NODO para la tabla por carga, y AMIN_STC
%   para el estimador (15) y la ley (12).  La planta es la de la replica
%   (AMIN_PLANTA: solo actua la inclinacion de quemadores).
%
%   LO QUE CAMBIA RESPECTO DE LAS PRUEBAS DEL ARTICULO es que aqui la demanda
%   la mueve el operador cuando quiere.  Por eso la congelacion del
%   estimador del «modified S.T.C.» se generaliza: el estimador se apaga en
%   cuanto la demanda empieza a moverse y se vuelve a encender 130 s despues
%   de que se detiene, que es exactamente la ventana [T0, T1 + 130 s] de la
%   seccion V cuando la rampa es una de las del articulo.  Con el modo del
%   estimador en 'congelado' o 'encendido' el operador lo fuerza.
%
%   CAMBIO DE CONTROLADOR EN MARCHA.
%     * De PI a uno de Amin: el controlador se inicializa con el modelo (o el
%       nodo de la tabla) referido al punto de operacion ACTUAL y arranca en
%       modo 'espera': manda el PI mientras se llena la historia del
%       regresor con datos reales (N+k periodos), y luego manda la ley.  Si
%       se elige antes de arrancar (t = 0, planta en estado estable), arranca
%       como en el articulo: historia = estado estable y manda desde t = 0.
%     * De uno de Amin al PI: se corrigen los integradores de los tres PI
%       para que su salida coincida con el ultimo mando, y la vuelta es sin
%       salto (como en PTE47_HMI).
%     * Entre dos de Amin: se pasa por lo anterior (se reinicia el
%       controlador en 'espera').
%
%   See also AMIN_HMI, AMIN_LAZO, AMIN_STC, AMIN_STC_INIT.

switch accion
    case 'crear',       varargout{1} = crear_(varargin{:});
    case 'avanzar',     varargout{1} = avanzar_(varargin{:});
    case 'controlador', varargout{1} = controlador_(varargin{:});
    case 'modelo',      varargout{1} = modelo_(varargin{:});
    case 'lambda',      M = varargin{1};  M.lambda = max(varargin{2},0);
                        if ~isempty(M.S), M.S.lambda = M.lambda; end
                        varargout{1} = M;
    case 'beta',        M = varargin{1};  M.beta = min(max(varargin{2},0.5),1);
                        if ~isempty(M.S), M.S.E.beta = M.beta; end
                        varargout{1} = M;
    case 'ley',         M = varargin{1};  M.literal = logical(varargin{2});
                        if ~isempty(M.S), M.S.literal = M.literal; end
                        varargout{1} = M;
    case 'estimador',   M = varargin{1};  M.modoEst = varargin{2};
                        varargout{1} = M;
    case 'reiniciaP',   varargout{1} = reiniciaP_(varargin{:});
    case 'demanda',     varargout{1} = demanda_(varargin{:});
    case 'evento',      varargout{1} = evento_(varargin{:});
    case 'indices0',    M = varargin{1};  M.iae = zeros(1,3);  M.itae = zeros(1,3);
                        M.tIdx0 = M.t;  varargout{1} = M;
    case 'variables',   varargout{1} = variables_(varargin{:});
    case 'catalogo',    varargout{1} = catalogo_();
    case 'alarmas',     varargout{1} = alarmas_(varargin{:});
    otherwise
        error('amin_hmi_motor:accion', 'accion desconocida: %s', accion);
end
end

% =========================================================================
function M = crear_(pct)
if nargin < 1 || isempty(pct), pct = 90; end
S0 = amin_estacionario(pct, 'verbose',false);
P = amin_planta(S0.base, 'ldcStart',S0.ldc, 'ldcRate',0, 'ldcT0',0, ...
                'ldcT1',0, 'samples',2);
P.x0 = S0.x0;
P.ldc = S0.ldc;
P.ldcT0 = inf;               % la demanda la pone el operador (P.ldcFcn)
P.ldcFcn = [];
P.openLoop = [false false false];
P.uFcn = [];

M = struct();
M.pct0 = pct;
M.P = P;  M.x = S0.x0(:);  M.t = 0;  M.Ts = P.Ts;
M.nPaso = 0;  M.pasoLog = 10;
M.kc1tr0 = P.kc1tr;

M.ldc = S0.ldc;  M.ldcObj = S0.ldc;  M.ldcVel = 10/20/60;
% LA RAMPA ES UNA FUNCION CONTINUA DEL TIEMPO, igual que la de AMIN_RAMPA:
% ldc(t) = ldc0 + s*min(|obj - ldc0|, vel*(t - t0)).  Evaluarla dentro de
% los subpasos de RK4 ---y no a saltos de 0,1 s--- importa: con el
% auto-sintonizable siempre adaptando, una diferencia de milesimas en la
% demanda se amplifica hasta decenas de grados en 300 s.
M.tIniRampa = 0;
M.tFinRampa = -inf;          % instante en que termina (o termino) la rampa

M.eventos = struct('tension',false, 'frecuencia',false, 'ventiladores',false);

% controlador
M.kc = 1;  M.mod = 1;  M.kk = 1;
M.lambda = 0.5;  M.beta = 0.99;  M.P0 = 'heredada';  M.literal = false;
M.modoEst = 'auto';
M.S = [];  M.tabla = [];  M.Mod = [];  M.TB = [];
M.fase = 0;                  % paso en que toca el proximo instante de control
M.stride = round(20/M.Ts);
M.mandaSTC = false;
M.uNow = [];
M.th0 = [];
M.error = '';
M.aviso = '';
M = carga_modelos_(M);

% indices y registros
M.iae = zeros(1,3);  M.itae = zeros(1,3);  M.tIdx0 = 0;
[~, yl] = digpte47(M.t, M.x, M.P);
M.yl = yl(:).';
M.log = nan(3600, numel(M.yl));  M.nlog = 1;  M.log(1,:) = M.yl;
% registro del controlador, una fila por instante de control:
% [t, cond(B0), ||dtheta||, tr P, lambda_max, lambda_min, nodo %, adapt, manda]
M.logC = nan(2000, 9);  M.nlogC = 0;
M.x0cond.vdrw = M.yl(10);
end

% =========================================================================
function M = carga_modelos_(M)
%CARGA_MODELOS_  Modelo AR y tabla por carga del modelo y retardo elegidos.
s = {'', '_ldc', '_k2', '_ldc_k2'};
m = M.mod + 2*(M.kk - 1);
M.Mod = [];  M.TB = [];
f = fullfile('datos', ['amin_modelo' s{m} '.mat']);
if exist(f,'file') == 2
    q = load(f);  Mo = q.M;
    if ~isfield(Mo,'nd')
        Mo = amin_modelo(Mo.th, Mo.N, Mo.nu, Mo.ny, Mo.k, Mo.T, Mo.u_ss, Mo.y_ss, Mo.pct);
    end
    M.Mod = Mo;
end
g = fullfile('datos', ['amin_tabla' s{m} '.mat']);
if exist(g,'file') == 2
    q = load(g);  M.TB = q.TB;
end
end

function M = modelo_(M, mod, kk)
M.mod = mod;  M.kk = kk;
M = carga_modelos_(M);
if M.kc > 1
    M = controlador_(M, M.kc, true);       % reinicia el controlador con el nuevo modelo
end
end

% =========================================================================
function M = controlador_(M, kc, forzar)
if nargin < 3, forzar = false; end
if kc == M.kc && ~forzar, return, end
M.aviso = '';

% ---- de vuelta al PI (o antes de cambiar de controlador de Amin) -----
if M.kc > 1 && M.mandaSTC
    M = vuelta_al_PI_(M);
end
M.S = [];  M.tabla = [];  M.mandaSTC = false;  M.uNow = [];
M.P.openLoop = [false false false];  M.P.uFcn = [];
M.kc = 1;
if kc == 1, return, end

% ---- a uno de Amin ------------------------------------------------------
if isempty(M.Mod)
    M.aviso = 'No hay modelo identificado para esta combinación (AMIN_MAIN).';
    return
end
if kc >= 3 && isempty(M.TB)
    M.aviso = 'Falta la tabla por carga de este modelo (AMIN_TABLA).';
    return
end
[~, yl] = digpte47(M.t, M.x, M.P);
y = yl(26:28).';  u = yl(29:31).';  ldc = yl(35);
enEstable = (M.t == 0);
if kc >= 3
    M.tabla = M.TB;
    nodo = amin_nodo(M.TB, ldc);
    M0 = M.TB.M(nodo);
    if ~isfield(M0,'nd')
        M0 = amin_modelo(M0.th, M0.N, M0.nu, M0.ny, M0.k, M0.T, M0.u_ss, M0.y_ss, M0.pct);
    end
    % El nodo se usa con SU punto de operacion, como en AMIN_RUN: esa es la
    % idea de la tabla.  Las conmutaciones posteriores (AMIN_STC_NODO) cambian
    % de nodo sin re-referir la historia de salidas y mandos.
else
    Mo = M.Mod;
    M0 = amin_modelo(Mo.th, Mo.N, Mo.nu, Mo.ny, Mo.k, Mo.T, u, y, NaN, dss_(Mo, ldc));
end
Tc = M0.T;
if kc == 4, Tc = 2; end
if enEstable, arr = 'estable'; else, arr = 'espera'; end
M.S = amin_stc_init(M0, 'lambda',M.lambda, 'beta',M.beta, 'adapt',(kc == 2), ...
                    'P0',M.P0, 'Tc',Tc, 'literal',M.literal, 'arranque',arr);
if kc >= 3, M.S.nodoActual = amin_nodo(M.TB, ldc); end
M.kc = kc;
M.th0 = M0.th;
M.stride = round(Tc/M.Ts);
M.fase = M.nPaso;                  % el primer instante de control es ahora
end

function d = dss_(Mo, ldc)
d = [];
if isfield(Mo,'nd') && Mo.nd > 0, d = ldc; end
end

function M = vuelta_al_PI_(M)
%VUELTA_AL_PI_  Sin salto: se corrige el integrador de cada PI por la
%   diferencia entre el ultimo mando y la salida que daria el PI.
idx = [23 33 34];
u = M.uNow(:);
P2 = M.P;  P2.openLoop = [false false false];  P2.uFcn = [];
[~, yl] = digpte47(M.t, M.x, P2);
for i = 1:3
    M.x(idx(i)) = M.x(idx(i)) + (u(i) - yl(28+i));
end
M.x = pte47_clamp(M.x, M.P);
end

% =========================================================================
function M = reiniciaP_(M)
if ~isempty(M.S)
    n = size(M.S.E.P,1);
    if ischar(M.P0)                         % 'heredada'
        Ph = amin_covarianza(M.S.M);
        if isempty(Ph), Ph = 1e2*eye(n); end
        M.S.E.P = Ph;
    else
        M.S.E.P = M.P0*eye(n);
    end
end
end

% =========================================================================
function M = demanda_(M, pct, vel)
pct = min(max(pct, 50), 100);
if nargin > 2 && ~isempty(vel), M.ldcVel = max(vel,0.01)/20/60; end
t0 = M.t;
l0 = ldc_(M, t0);                    % arranca de donde este la demanda
obj = pct/20;
d = obj - l0;  v = M.ldcVel;
M.ldcObj = obj;
M.tIniRampa = t0;
M.tFinRampa = t0 + abs(d)/v;
M.P.ldcFcn = @(t) l0 + sign(d)*min(abs(d), v*max(t - t0, 0));
M.ldc = l0;
end

function l = ldc_(M, t)
if isempty(M.P.ldcFcn), l = M.P.ldc; else, l = M.P.ldcFcn(t); end
end

function r = en_rampa_(M)
r = M.t >= M.tIniRampa && M.t < M.tFinRampa - 1e-9;
end

function M = evento_(M, cual, on)
t0 = M.t;
switch cual
    case 'tension'
        if on, M.P.velecFcn = @(t) 2912; else, M.P.velecFcn = []; end
    case 'frecuencia'
        if on, M.P.nelecFcn = @(t) 2*pi*max(56, 60 - 0.8*(t - t0));
        else,  M.P.nelecFcn = []; end
    case 'ventiladores'
        if on, M.P.knfdFcn = @(t) 1;  M.P.knidFcn = @(t) 1;
        else,  M.P.knfdFcn = [];      M.P.knidFcn = []; end
end
M.eventos.(cual) = logical(on);
end

% =========================================================================
function M = avanzar_(M, n)
if ~isempty(M.error), return, end
Ts = M.Ts;
for s = 1:n
    % ---- instante de control (el de AMIN_LAZO) --------------------------
    if M.kc > 1 && mod(M.nPaso - M.fase, M.stride) == 0
        M = instante_(M);
    end
    % ---- indices, a paso de integracion --------------------------------
    if mod(M.nPaso, M.pasoLog) == 0
        e = abs(M.yl(26:28) - M.yl(32:34));
        dt = M.pasoLog*Ts;
        M.iae  = M.iae  + e*dt;
        M.itae = M.itae + e*(M.t - M.tIdx0)*dt;
    end
    % ---- planta ----------------------------------------------------------
    P = M.P;  x = M.x;  t = M.t;
    xd1 = digpte47(t,        x,              P);
    xd2 = digpte47(t+Ts/2,   x + (Ts/2)*xd1, P);
    xd3 = digpte47(t+Ts/2,   x + (Ts/2)*xd2, P);
    xd4 = digpte47(t+Ts,     x +  Ts  *xd3,  P);
    x = x + (Ts/6)*(xd1 + 2*xd2 + 2*xd3 + xd4);
    x = pte47_clamp(x, P);
    M.x = x;  M.t = t + Ts;  M.nPaso = M.nPaso + 1;
    M.ldc = ldc_(M, M.t);

    if ~all(isfinite(x)) || ~isreal(x)
        M.error = sprintf('t = %.1f s: la simulación divergió (%s).  Reinicia.', ...
                          M.t, ternario_(isreal(x), 'estado no finito', 'estado complejo'));
        break
    end
    if mod(M.nPaso, M.pasoLog) == 0
        [~, yl] = digpte47(M.t, M.x, M.P);
        M.yl = yl(:).';
        M.nlog = M.nlog + 1;
        if M.nlog > size(M.log,1), M.log = [M.log; nan(3600, size(M.log,2))]; end
        M.log(M.nlog,:) = M.yl;
    end
end
if isempty(M.error)
    [~, yl] = digpte47(M.t, M.x, M.P);
    M.yl = yl(:).';
end
end

function s = ternario_(c, a, b)
if c, s = a; else, s = b; end
end

% =========================================================================
function M = instante_(M)
[~, yl] = digpte47(M.t, M.x, M.P);
y = yl(26:28).';  w = yl(32:34).';  uPI = yl(29:31).';  ldc = yl(35);
S = M.S;
nodoPct = NaN;
if ~isempty(M.tabla)
    nodo = amin_nodo(M.tabla, ldc);
    if ~isfield(S,'nodoActual') || S.nodoActual ~= nodo
        S = amin_stc_nodo(S, M.tabla.M(nodo));
        S.nodoActual = nodo;
    end
    nodoPct = M.tabla.pct(nodo);
end

% estimador: segun el controlador o forzado por el operador
switch M.modoEst
    case 'congelado', S.adapt = false;
    case 'encendido', S.adapt = true;
    otherwise
        switch M.kc
            case 2, S.adapt = true;
            % la ventana [T0, T1 + 130 s] de la seccion V
            case 3, S.adapt = ~(M.t >= M.tIniRampa - 1e-6 && ...
                                M.t <= M.tFinRampa + 130 + 1e-6);
            otherwise, S.adapt = false;          % 4 y 5: apagado siempre
        end
end

[u, S] = amin_stc(S, y, w, uPI, ldc);
if isempty(u)
    M.uNow = uPI;
    M.P.openLoop = [false false false];  M.P.uFcn = [];
else
    M.uNow = u;
    M.mandaSTC = true;
    M.P.openLoop = [true true true];
    uu = u;
    M.P.uFcn = @(z) uu;
end
M.S = S;

% registro del controlador
ev = eig((S.E.P + S.E.P.')/2);
cB = NaN;  if ~isempty(S.log.condB0), cB = S.log.condB0(end); end
fila = [M.t, cB, norm(S.M.th - M.th0,'fro'), sum(ev), max(ev), min(ev), ...
        nodoPct, double(S.adapt), double(~isempty(u))];
M.nlogC = M.nlogC + 1;
if M.nlogC > size(M.logC,1), M.logC = [M.logC; nan(2000,9)]; end
M.logC(M.nlogC,:) = fila;
end

% =========================================================================
function V = variables_(M)
y = M.yl;
V = struct();
V.t = M.t;
V.tsso = y(26);  V.trho = y(27);  V.psso = y(28);
V.ktss = y(32);  V.ktrh = y(33);  V.kpsso = y(34);
V.cbmd = y(29);  V.cxgg = y(30);  V.cwsy = y(31);
V.mw = y(3);     V.f = y(2)/(2*pi);   V.whp = y(5);   V.valv = y(7);
V.ldc = y(35);   V.carga = 20*y(35);  V.cargaObj = 20*M.ldcObj;
V.rampa = en_rampa_(M);
V.wfl = 22.5*(y(8) - 1);  V.tilt = 15*(y(17) - 3);  V.wsy = 25*(y(16) - 1);
V.vdrw = y(10);
V.iae = M.iae;  V.itae = M.itae;
V.kc = M.kc;
V.manda = M.mandaSTC;
if M.nlogC > 0 && M.kc > 1
    c = M.logC(M.nlogC,:);
    V.condB0 = c(2);  V.dth = c(3);  V.trP = c(4);  V.lmax = c(5);  V.lmin = c(6);
    V.nodo = c(7);    V.adapt = logical(c(8));
    V.nUpd = M.S.E.n;
    V.npar = M.S.M.npar;  V.estructura = M.S.M.estructura;  V.k = M.S.M.k;
    V.Tc = M.S.Tc;
else
    V.condB0 = NaN;  V.dth = NaN;  V.trP = NaN;  V.lmax = NaN;  V.lmin = NaN;
    V.nodo = NaN;    V.adapt = false;  V.nUpd = 0;
    V.npar = NaN;    V.estructura = '';  V.k = M.kk;  V.Tc = 20;
end
% historia llena: cuantos instantes faltan para que mande la ley
V.espera = (M.kc > 1) && ~M.mandaSTC;
end

% =========================================================================
function C = catalogo_()
%CATALOGO_  {nombre, unidad, fuente, funcion, columna de consigna, escala}
%   fuente 'p' = registro de la planta (una fila por segundo, 38 columnas);
%   fuente 'c' = registro del controlador (una fila por instante de control).
C = { ...
 'PSSO  presión de vapor',            'psia', 'p', @(Y) Y(:,28),          34, 'lin'
 'TSSO  sobrecalentador',             '°R',   'p', @(Y) Y(:,26),          32, 'lin'
 'TRHO  recalentador',                '°R',   'p', @(Y) Y(:,27),          33, 'lin'
 'CBMD  maestro de caldera',          'V',    'p', @(Y) Y(:,29),          0,  'lin'
 'CXGG  inclinación de quemadores',   'V',    'p', @(Y) Y(:,30),          0,  'lin'
 'CWSY  atemperación',                'V',    'p', @(Y) Y(:,31),          0,  'lin'
 'Demanda de carga',                  '%',    'p', @(Y) 20*Y(:,35),       0,  'lin'
 'Potencia eléctrica',                'MW',   'p', @(Y) Y(:,3),           0,  'lin'
 'Frecuencia',                        'Hz',   'p', @(Y) Y(:,2)/(2*pi),    0,  'lin'
 'Válvula de la turbina',             'V',    'p', @(Y) Y(:,7),           0,  'lin'
 'cond(B₀)',                          '',     'c', @(Y) Y(:,2),           0,  'log'
 '‖θ(t) − θ(0)‖',                     '',     'c', @(Y) Y(:,3),           0,  'lin'
 'tr P(t)',                           '',     'c', @(Y) Y(:,4),           0,  'log'
 'Nodo de la tabla por carga',        '%',    'c', @(Y) Y(:,7),           0,  'lin'
 'Estimador actualizando (1) / congelado (0)', '', 'c', @(Y) Y(:,8),     0,  'lin'
 };
end

% =========================================================================
function A = alarmas_(M)
V = variables_(M);
A = cell(0,4);
A = banda_(A, 'psso', 'Presión de vapor',      V.psso, V.kpsso, 50, 'psia');
A = banda_(A, 'tsso', 'Temp. sobrecalentador', V.tsso, V.ktss,  15, '°R');
A = banda_(A, 'trho', 'Temp. recalentador',    V.trho, V.ktrh,  20, '°R');
A = banda_(A, 'f',    'Frecuencia',            V.f,    60,      0.5, 'Hz');
A = banda_(A, 'vdrw', 'Volumen del domo',      V.vdrw, M.x0cond.vdrw, 0.10*M.x0cond.vdrw, 'ft³');
nom = {'CBMD','CXGG','CWSY'};
val = [V.cbmd V.cxgg V.cwsy];
for k = 1:3
    if val(k) <= 1.01 || val(k) >= 4.99
        A(end+1,:) = {['sat_' nom{k}], ['Mando ' nom{k} ' saturado'], ...
                      num_(val(k),'%.2f V'), 'tope 1 / 5 V'}; %#ok<AGROW>
    end
end
if isfinite(V.condB0) && V.condB0 > 1e3
    A(end+1,:) = {'condB0', 'B₀ mal condicionada', num_(V.condB0,'%.3g'), '> 1000'};
end
if ~isempty(M.error)
    A(end+1,:) = {'error', 'SIMULACIÓN DETENIDA', M.error, ''};
end
end

function A = banda_(A, clave, nombre, v, ref, tol, u)
if v > ref + tol
    A(end+1,:) = {[clave '_alta'], [nombre ' ALTA'], num_(v,['%.1f ' u]), num_(ref+tol,['> %.1f ' u])};
elseif v < ref - tol
    A(end+1,:) = {[clave '_baja'], [nombre ' BAJA'], num_(v,['%.1f ' u]), num_(ref-tol,['< %.1f ' u])};
end
end

function s = num_(v, fmt)
s = strrep(sprintf(fmt, v), '.', ',');
end
