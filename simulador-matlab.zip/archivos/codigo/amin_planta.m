function P = amin_planta(varargin)
%AMIN_PLANTA  PTE47_PARAMS con la hipotesis de planta del articulo puesta.
%
%   P = AMIN_PLANTA(...)    mismos argumentos que PTE47_PARAMS
%
%   TODA la replica construye sus parametros por aqui, y no llamando a
%   PTE47_PARAMS directamente, por una sola razon:
%
%     «In this study only the burner tilt control is assumed to be active
%      since in most applications it is sufficient to control reheat
%      temperature.»                                   (Amin et al., p. 340)
%
%   En el modelo de Usoro, CXGG manda A LA VEZ dos actuadores, en rango
%   partido:
%
%     * la inclinacion de los quemadores,  xgg = xducer(1, 5, ...);
%     * la valvula de atemperacion del recalentador, a traves de
%       cry = -cxggd  y  wry = xducer(-2, -1, 0, 50, cry),
%
%   o sea que wry = 0 mientras CXGG >= 2 V y se abre hasta 50 lb/s cuando
%   CXGG baja a 1 V.  Es el «spray control is used only if the tilt control
%   is unable to control the reheat temperature» del propio articulo.
%
%   AMIN LO DESACTIVA, y hay que desactivarlo tambien aqui o no se esta
%   simulando su planta.  En regimen permanente da igual ---CXGG vale entre
%   2,87 y 4,74 V del 70 al 90 % de carga, y la valvula esta cerrada--- pero
%   en cuanto el auto-sintonizable satura CXGG contra 1 V el rociado entra,
%   y entonces el lazo de temperatura del recalentador ya no es el del
%   articulo.  Es justo el regimen en el que se le ha estado midiendo.
%
%   La bandera P.soloTilt esta APAGADA por omision en la planta, de modo que
%   el resto del repositorio se comporta exactamente como antes.
%
%   See also PTE47_PARAMS, DIGPTE47.

P = pte47_params(varargin{:});
P.soloTilt = true;
end
