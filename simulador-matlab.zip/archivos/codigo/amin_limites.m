function L = amin_limites(varargin)
%AMIN_LIMITES  Comprueba los limites de fluctuacion de las entradas (nota 1).
%
%   L = AMIN_LIMITES
%   L = AMIN_LIMITES('pct',75, 'amp',[0.05 0.1 0.2 0.3 0.6 1.0], 'dur',400)
%
%   El articulo fija la amplitud de las entradas aleatorias de la seccion IV
%   con este criterio, que esta en la nota al pie de la pagina 343:
%
%     «Acceptable limit of fluctuation of an input around its steady state
%      value was obtained based on the criterion that the fluctuating input
%      should not cause, in any of the outputs, a fluctuation with amplitude
%      greater than 1% of the steady state of the output.»
%
%   y obtiene  +-0,1 para CBMD,  +-0,3 para CXGG  y  +-0,6 para CWSY.
%
%   Esta funcion rehace ese experimento: mantiene dos entradas en su valor de
%   estado estable, hace fluctuar la tercera con una senal aleatoria de
%   amplitud creciente y mide la desviacion maxima de cada salida en por
%   ciento de su valor de estado estable.  El limite es la mayor amplitud que
%   todavia deja las tres salidas por debajo del 1 %.
%
%   No es un adorno: es la unica forma de saber si el experimento de
%   identificacion de esta replica excita la planta como el del articulo, y
%   si no coincide hay que decirlo en vez de adoptar sus numeros por fe.
%
%   LA DEMANDA DE CARGA ---para el modelo 3x4, NO ES DEL ARTICULO---.  Con
%   'ldc',true se mide tambien el limite de la demanda con el MISMO criterio
%   del 1 %, para que su excitacion en AMIN_DATOS no sea un numero elegido a
%   ojo sino el que resulta del procedimiento de Amin aplicado a la cuarta
%   entrada.  Sus amplitudes van en 'ampLdc'.
%
%   DEVUELVE  L.amp, L.pct (desviacion maxima por salida, en %), L.limite
%             (1 x 3, o 1 x 4 con la demanda)
%
%   See also AMIN_DATOS.

opt = struct('pct',75, 'amp',[0.05 0.1 0.2 0.3 0.6 1.0], 'dur',400, ...
             'T',20, 'umbral',1.0, 'semilla',1984, 'verbose',true, ...
             'ldc',false, 'ampLdc',[0.01 0.02 0.03 0.05 0.075 0.1 0.15 0.2], ...
             'entradas',[]);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_limites:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

S = amin_estacionario(opt.pct, 'verbose',opt.verbose);
nom = {'CBMD','CXGG','CWSY'};
nIn = 3;
if opt.ldc, nom{4} = 'ldc';  nIn = 4; end

Ts     = 0.1;
stride = round(opt.T/Ts);
nS     = floor(opt.dur/opt.T);

nA = max(numel(opt.amp), numel(opt.ampLdc)*opt.ldc);
L = struct('amp',opt.amp, 'ampLdc',opt.ampLdc, 'nom',{nom}, ...
           'pico',nan(3,nA,nIn), 'limite',nan(1,nIn), ...
           'umbral',opt.umbral, 'pct',opt.pct);

if isempty(opt.entradas), opt.entradas = 1:nIn; end
for e = opt.entradas(:).'
  if e == 4, amps = opt.ampLdc; else, amps = opt.amp; end
  for a = 1:numel(amps)
    try, rng(opt.semilla+e*100+a,'twister'); catch, randn('state',opt.semilla+e*100+a); end %#ok<RAND>
    Useq = S.u(:)*ones(1,nS);
    Lseq = S.ldc*ones(1,nS);
    if e == 4
        Lseq = min(max(Lseq + amps(a)*randn(1,nS), 1), 5);
    else
        Useq(e,:) = Useq(e,:) + amps(a)*randn(1,nS);
    end

    uNow = Useq(:,1);
    P = amin_planta(S.base, 'ldcStart',S.ldc, 'ldcRate',0, ...
                     'ldcT0',0, 'ldcT1',0, 'samples',nS*stride+1);
    P.x0 = S.x0;  P.ldc = S.ldc;
    P.openLoop = [true true true];
    P.uFcn = @(z) uNow;

    x = S.x0(:);  t = 0;  pico = zeros(3,1);
    for s = 1:nS
        uNow = Useq(:,s);  P.uFcn = @(z) uNow;
        if e == 4, lNow = Lseq(s);  P.ldcFcn = @(z) lNow; end
        [~, yl] = digpte47(t, x, P);
        pico = max(pico, abs(yl(26:28).' - S.y));
        for i = 1:stride
            xd1 = digpte47(t,      x,              P);
            xd2 = digpte47(t+Ts/2, x + (Ts/2)*xd1, P);
            xd3 = digpte47(t+Ts/2, x + (Ts/2)*xd2, P);
            xd4 = digpte47(t+Ts,   x +  Ts  *xd3,  P);
            x = x + (Ts/6)*(xd1 + 2*xd2 + 2*xd3 + xd4);
            x = pte47_clamp(x, P);
            t = t + Ts;
        end
        if ~all(isfinite(x)) || ~isreal(x), break, end
    end
    L.pico(:,a,e) = 100*pico./abs(S.y);
    if opt.verbose
        fprintf('%s  amp %.3f   desviacion %.3f %.3f %.3f %%\n', ...
                nom{e}, amps(a), L.pico(:,a,e));
    end
  end
  ok = find(max(L.pico(:,1:numel(amps),e),[],1) <= opt.umbral, 1, 'last');
  if ~isempty(ok), L.limite(e) = amps(ok); end
end

if opt.verbose
    fprintf('\nlimite medido  CBMD %.2f   CXGG %.2f   CWSY %.2f\n', L.limite(1:3));
    if opt.ldc
        fprintf('               ldc  %.3f   (no es del articulo: modelo 3x4)\n', L.limite(4));
    end
    fprintf('limite de Amin CBMD 0.10   CXGG 0.30   CWSY 0.60\n');
end
end
