function amin_hmi()
%AMIN_HMI  Consola de operación con los controladores de Amin et al. (1984).
%
%   >> INICIO('consola')       desde la carpeta de la replica, o
%   >> amin_hmi                desde la carpeta codigo
%
%   No hace falta ningun paso previo: la consola pone la ruta ella misma.
%
%   La planta de 47 estados corre EN VIVO y sus tres lazos ---presion
%   (CBMD), recalentador (CXGG) y sobrecalentador (CWSY)--- los controla el
%   controlador que se elija, y se puede cambiar EN MARCHA:
%
%     PI de Usoro · auto-sintonizable (fig. 6) · modificado, mando 20 s
%     (fig. 7) · modificado, mando 2 s (no publicada) · tabla con el estimador
%     apagado (no es del articulo)
%
%   Lo que AMIN_SIM no permite y aqui si:
%
%     * mover la DEMANDA cuando se quiera, a la velocidad que se quiera, y no
%       solo las dos rampas del articulo (que siguen en dos botones);
%     * cambiar lambda, beta y la ley (corregida o impresa) EN VIVO;
%     * CONGELAR o ENCENDER el estimador a mano y REINICIAR su covarianza;
%     * disparar las emergencias V.5 a V.7 de Usoro con el auto-sintonizable
%       en el lazo;
%     * ver el lazo auto-sintonizable como diagrama de bloques, con los
%       valores en vivo: consignas, demanda, tabla por carga, estimador (15),
%       ley (12), mandos, PI de Usoro en reserva y la planta.
%
%   El instante de control es el de AMIN_LAZO (AMIN_STC, AMIN_STC_NODO): con
%   la rampa de 90 a 70 % a 10 %/min, la consola da EXACTAMENTE las mismas
%   salidas que AMIN_LAZO (ver AMIN_HMI_PRUEBA).  La simulacion la hace
%   AMIN_HMI_MOTOR.
%
%   See also AMIN_HMI_MOTOR, AMIN_HMI_PRUEBA, AMIN_SIM, PTE47_HMI.

raiz = fileparts(fileparts(mfilename('fullpath')));
if isempty(raiz), raiz = pwd; end
if exist(fullfile(pwd,'codigo','amin_stc.m'),'file') == 2, raiz = pwd; end
% Rutas relativas (datos/) solo mientras se leen; al terminar se vuelve a
% la carpeta desde la que se llamo (ver ENRAIZ_).
addpath(fullfile(raiz,'codigo'), fullfile(raiz,'planta','codigo'), ...
        fullfile(raiz,'planta','funciones'));

C = paleta_();
G = struct();
G.C = C;  G.raiz = raiz;
G.cat = amin_hmi_motor('catalogo');
G.ctrlNom = {'PI de Usoro', 'Autosintonizable  (fig. 6)', ...
             'Modificado, mando 20 s  (fig. 7)', 'Modificado, mando 2 s  (no publicada)', ...
             'Tabla, estimador apagado  (*)'};
G = construye_(G);

setappdata(G.fig, 'G', G);
setappdata(G.fig, 'corriendo', false);
setappdata(G.fig, 'alarmas', struct('clave',{{}}, 't0',[], 'nombre',{{}}));
setappdata(G.fig, 'mensajes', {});
reiniciar_(G.fig, true);
end

% =========================================================================
%  CONSTRUCCION
% =========================================================================
function G = construye_(G)
C = G.C;
scr = get(groot,'ScreenSize');
W = max(1200, min(1600, scr(3) - 40));
H = max(720,  min(940,  scr(4) - 80));
G.fig = uifigure('Name', ...
    'Réplica de Amin, Masada y Womack (1984)  ·  consola de operación con el auto-sintonizable', ...
    'Position',[max(10,round((scr(3)-W)/2)) max(40,round((scr(4)-H)/2)) W H], ...
    'Color',C.fondo);
G.fig.CloseRequestFcn = @(s,e) cerrar_(s);

P0 = uigridlayout(G.fig,[3 1]);
P0.RowHeight = {44,'1x',150};
P0.Padding = [8 8 8 8];  P0.RowSpacing = 8;

% ------------------------------------------------------------ barra -----
T = uigridlayout(P0,[1 11]);
T.ColumnWidth = {'fit',80,95,95,'fit',130,'fit','1x',230,150,26};
T.Padding = [6 4 6 4];  T.ColumnSpacing = 8;
T.BackgroundColor = C.barra;
uilabel(T,'Text','Arranque','FontColor','w');
G.ddCaso = uidropdown(T,'Items',{'90 %','85 %','80 %','75 %','70 %'}, ...
                      'ItemsData',[90 85 80 75 70],'Value',90);
tip_(G.ddCaso, ['Estado estable de la réplica (AMIN_ESTACIONARIO).  Al ' ...
                'cambiarlo hay que pulsar «Reiniciar».']);
G.btIni = uibutton(T,'Text','Iniciar','FontWeight','bold', ...
                   'BackgroundColor',C.acento,'FontColor','w', ...
                   'ButtonPushedFcn',@(s,e) alternar_(s));
G.btRei = uibutton(T,'Text','Reiniciar','ButtonPushedFcn',@(s,e) reiniciar_(ancestor(s,'figure'), false));
uilabel(T,'Text','Velocidad','FontColor','w');
G.ddVel = uidropdown(T,'Items',{'1x (tiempo real)','5x','20x','máxima'}, ...
                     'ItemsData',[1 5 20 inf],'Value',20);
G.btExp = uibutton(T,'Text','Exportar corrida…','ButtonPushedFcn',@(s,e) exportar_(s));
uilabel(T,'Text','');
G.lblT = uilabel(T,'Text','t = 00:00:00','FontName','Consolas','FontSize',18, ...
                 'FontWeight','bold','FontColor','w','HorizontalAlignment','right');
G.lblFase = uilabel(T,'Text','detenida','FontWeight','bold','FontColor','w', ...
                    'BackgroundColor',C.gris,'HorizontalAlignment','center');
G.lamp = uilamp(T,'Color',C.ok);
tip_(G.lamp, 'Verde: sin alarmas.  Rojo: hay alarmas activas (abajo).');

% ------------------------------------------------------------ centro ----
Mg = uigridlayout(P0,[1 3]);
Mg.ColumnWidth = {340,'1x',400};
Mg.Padding = [0 0 0 0];  Mg.ColumnSpacing = 8;
G = columna_operacion_(G, Mg);

Cg = uigridlayout(Mg,[2 1]);
Cg.RowHeight = {150,'1x'};
Cg.Padding = [0 0 0 0];  Cg.RowSpacing = 8;
G = indicadores_(G, Cg);
pD = uipanel(Cg,'Title','El lazo auto-sintonizable, en vivo','FontWeight','bold', ...
             'BackgroundColor',C.panel);
gD = uigridlayout(pD,[1 1]);  gD.Padding = [2 2 2 2];
G.axD = uiaxes(gD);
G.D = diagrama_(G.axD, C);

G = tendencias_(G, Mg);

% ------------------------------------------------------------ abajo -----
Bg = uigridlayout(P0,[1 2]);
Bg.ColumnWidth = {'1x', 460};
Bg.Padding = [0 0 0 0];  Bg.ColumnSpacing = 8;
pA = uipanel(Bg,'Title','Alarmas activas','FontWeight','bold','BackgroundColor',C.panel);
gA = uigridlayout(pA,[1 1]);  gA.Padding = [4 4 4 4];
G.tabA = uitable(gA,'ColumnName',{'desde','alarma','valor','límite'}, 'RowName',{}, ...
                 'Data',cell(0,4), 'ColumnWidth',{90,'auto',130,130}, 'FontSize',12);
pM = uipanel(Bg,'Title','Registro del operador','FontWeight','bold','BackgroundColor',C.panel);
gM = uigridlayout(pM,[1 1]);  gM.Padding = [4 4 4 4];
G.txtM = uitextarea(gM,'Editable','off','Value',{''},'FontName','Consolas','FontSize',11);
end

% =========================================================================
function G = columna_operacion_(G, padre)
C = G.C;
L = uigridlayout(padre,[4 1]);
L.RowHeight = {'fit','fit','fit','fit'};
L.Padding = [0 0 0 0];  L.RowSpacing = 8;
try L.Scrollable = 'on'; catch, end

% ---- controlador --------------------------------------------------------
p = uipanel(L,'Title','Controlador','FontWeight','bold','BackgroundColor',C.panel);
g = uigridlayout(p,[9 2]);
g.RowHeight = repmat({'fit'},1,9);  g.ColumnWidth = {82,'1x'};
g.Padding = [10 8 10 8];  g.RowSpacing = 6;  g.ColumnSpacing = 8;
et_(g,'Controlador', ['Se puede cambiar en marcha.  Al pasar del PI a uno de Amin, ' ...
    'el PI sigue mandando hasta que se llena la historia del regresor.  (*) no es del artículo.']);
G.ddCtrl = uidropdown(g,'Items',G.ctrlNom,'ItemsData',1:5,'Value',1, ...
                      'ValueChangedFcn',@(s,e) controlador_(s));
et_(g,'Modelo ARX','3×3: el del artículo.  3×4: ldc como entrada medida (no es del artículo).');
G.ddMod = uidropdown(g,'Items',{'3×3  (artículo)','3×4  (+ ldc)'},'ItemsData',[1 2],'Value',1, ...
                     'ValueChangedFcn',@(s,e) modelo_(s));
et_(g,'Retardo k','k = 1: el del artículo.  k = 2: el retardo máximo medido aquí (34,6 s).');
G.ddK = uidropdown(g,'Items',{'k = 1  (artículo)','k = 2'},'ItemsData',[1 2],'Value',1, ...
                   'ValueChangedFcn',@(s,e) modelo_(s));
et_(g,'λ','Ponderación del mando.  El artículo no da su valor; la réplica usa 0,5.  Cambia en vivo.');
G.efLam = uieditfield(g,'numeric','Limits',[0 inf],'Value',0.5, ...
                      'ValueChangedFcn',@(s,e) param_(s,'lambda'));
et_(g,'β','Factor de olvido del estimador (15).  Cambia en vivo.');
G.efBeta = uieditfield(g,'numeric','Limits',[0.5 1],'Value',0.99, ...
                       'ValueChangedFcn',@(s,e) param_(s,'beta'));
et_(g,'Ley','Corregida: consistente con la ec. (16).  Impresa: la de la p. 344, con la errata.');
G.ddLey = uidropdown(g,'Items',{'corregida  (ec. 16)','impresa  (errata)'},'ItemsData',[0 1], ...
                     'Value',0,'ValueChangedFcn',@(s,e) param_(s,'ley'));
et_(g,'Estimador', ['«Según el controlador»: siempre encendido en el auto-sintonizable; ' ...
    'en el modificado de 20 s se apaga mientras se mueve la demanda y 130 s después ' ...
    '(sección V); apagado en los otros dos.']);
G.ddEst = uidropdown(g,'Items',{'según el controlador','congelado','encendido'}, ...
                     'ItemsData',{'auto','congelado','encendido'},'Value','auto', ...
                     'ValueChangedFcn',@(s,e) estimador_(s));
G.btP = uibutton(g,'Text','Reiniciar la covarianza  P = P(0) heredada', ...
                 'ButtonPushedFcn',@(s,e) reiniciaP_(s));
G.btP.Layout.Column = [1 2];
G.lblCtrl = uilabel(g,'Text','—','FontWeight','bold','WordWrap','on');
G.lblCtrl.Layout.Column = [1 2];

% ---- demanda -------------------------------------------------------------
p = uipanel(L,'Title','Demanda de carga','FontWeight','bold','BackgroundColor',C.panel);
g = uigridlayout(p,[5 2]);
g.RowHeight = repmat({'fit'},1,5);  g.ColumnWidth = {'1x','1x'};
g.Padding = [10 8 10 8];  g.RowSpacing = 6;
G.lblCarga = uilabel(g,'Text','—','FontSize',16,'FontWeight','bold');
G.lblCarga.Layout.Column = [1 2];
G.efObj = uieditfield(g,'numeric','Limits',[50 100],'Value',90, ...
                      'ValueDisplayFormat','objetivo %.1f %%');
G.ddRampa = uidropdown(g,'Items',{'1 %/min','5 %/min','10 %/min (artículo)','15 %/min','30 %/min'}, ...
                       'ItemsData',[1 5 10 15 30],'Value',10);
G.btRampa = uibutton(g,'Text','Aplicar rampa','FontWeight','bold', ...
                     'ButtonPushedFcn',@(s,e) rampa_(s,[]));
G.btAlto = uibutton(g,'Text','Detener rampa','ButtonPushedFcn',@(s,e) rampa_(s,-1));
G.btP1 = uibutton(g,'Text','Prueba 90 → 70 %','ButtonPushedFcn',@(s,e) rampa_(s,70));
G.btP2 = uibutton(g,'Text','Prueba 70 → 90 %','ButtonPushedFcn',@(s,e) rampa_(s,90));
tip_(G.btP1, 'La rampa de las figuras 6a, 7a y 8a: a 70 % a 10 %/min.  Arranca en 90 % para reproducirla.');
tip_(G.btP2, 'La rampa de las figuras 6b, 7b y 8b: a 90 % a 10 %/min.  Arranca en 70 % para reproducirla.');
lb = uilabel(g,'Text','','FontColor',C.tenue,'FontSize',10);  lb.Layout.Column = [1 2];

% ---- emergencias ---------------------------------------------------------
p = uipanel(L,'Title','Emergencias (Usoro, cap. V)','FontWeight','bold','BackgroundColor',C.panel);
g = uigridlayout(p,[3 1]);
g.RowHeight = repmat({'fit'},1,3);  g.Padding = [10 8 10 8];  g.RowSpacing = 6;
ev = {'tension','frecuencia','ventiladores'};
txt = {'V.5  caída de tensión auxiliar','V.6  caída de frecuencia','V.7  sale un par de ventiladores'};
G.btEv = gobjects(1,3);
for k = 1:3
    G.btEv(k) = uibutton(g,'state','Text',txt{k},'Value',false, ...
                         'ValueChangedFcn',@(s,e) evento_(s, ev{k}));
    tip_(G.btEv(k), 'Púlsalo otra vez para restablecer.');
end

% ---- indices ---------------------------------------------------------------
p = uipanel(L,'Title','Índices desde el último reinicio','FontWeight','bold','BackgroundColor',C.panel);
g = uigridlayout(p,[2 1]);
g.RowHeight = {'fit','fit'};  g.Padding = [6 6 6 6];  g.RowSpacing = 6;
G.tabI = uitable(g,'ColumnName',{'IAE','ITAE'},'RowName',{'TSSO','TRHO','PSSO'}, ...
                 'Data',repmat({'—'},3,2),'FontSize',11);
G.btI = uibutton(g,'Text','Reiniciar índices (compara desde aquí)', ...
                 'ButtonPushedFcn',@(s,e) indices0_(s));
end

% =========================================================================
function G = indicadores_(G, padre)
C = G.C;
g = uigridlayout(padre,[2 5]);
g.RowHeight = {'1x', 22};
g.Padding = [0 0 0 0];  g.RowSpacing = 0;  g.ColumnSpacing = 8;
tit = {'TSSO (°R)','TRHO (°R)','PSSO (psia)','Carga (%)','Potencia (MW)'};
lim = {[1400 1520], [1400 1520], [2000 2800], [50 100], [300 650]};
G.gau = gobjects(1,5);  G.lblG = gobjects(1,5);
for k = 1:5
    p = uipanel(g,'Title',tit{k},'BackgroundColor',C.panel,'FontWeight','bold');
    p.Layout.Row = 1;  p.Layout.Column = k;
    q = uigridlayout(p,[1 1]);  q.Padding = [2 2 2 2];
    G.gau(k) = uigauge(q,'semicircular','Limits',lim{k});
    G.lblG(k) = uilabel(g,'Text','—','HorizontalAlignment','center', ...
                        'FontSize',14,'FontWeight','bold');
    G.lblG(k).Layout.Row = 2;  G.lblG(k).Layout.Column = k;
end
end

% =========================================================================
function G = tendencias_(G, padre)
C = G.C;
g = uigridlayout(padre,[5 1]);
g.RowHeight = {'fit','1x','1x','1x','1x'};
g.Padding = [0 0 0 0];  g.RowSpacing = 6;
h = uigridlayout(g,[1 2]);  h.Padding = [0 0 0 0];  h.ColumnWidth = {'fit','1x'};
uilabel(h,'Text','Tendencias:  ventana','FontWeight','bold');
G.ddVen = uidropdown(h,'Items',{'últimos 5 min','últimos 15 min','últimos 60 min','toda la corrida'}, ...
                     'ItemsData',[300 900 3600 inf],'Value',900, ...
                     'ValueChangedFcn',@(s,e) refresca_(ancestor(s,'figure')));
def = [2 3 1 4];
col = {C.s1, C.s2, C.s3, C.s4};
G.ddTr = gobjects(1,4);  G.axT = gobjects(1,4);  G.hT = gobjects(1,4);  G.hS = gobjects(1,4);
for k = 1:4
    p = uipanel(g,'BackgroundColor',C.panel);
    q = uigridlayout(p,[2 1]);
    q.RowHeight = {'fit','1x'};  q.Padding = [4 2 4 2];  q.RowSpacing = 0;
    G.ddTr(k) = uidropdown(q,'Items',G.cat(:,1).','ItemsData',1:size(G.cat,1), ...
                           'Value',def(k),'ValueChangedFcn',@(s,e) cambiaTendencia_(s,k));
    a = uiaxes(q);
    a.XGrid = 'on';  a.YGrid = 'on';  a.Box = 'off';
    a.GridColor = [0.85 0.85 0.85];  a.GridAlpha = 1;  a.FontSize = 9;
    a.XLabel.String = 'tiempo (s)';
    try a.Toolbar.Visible = 'off'; catch, end
    hold(a,'on');
    G.hS(k) = plot(a, nan, nan, '--', 'Color',C.gris, 'LineWidth',1.0);
    G.hT(k) = plot(a, nan, nan, '-',  'Color',col{k}, 'LineWidth',1.6);
    hold(a,'off');
    G.axT(k) = a;
    etiqueta_tendencia_(G, k);
end
end

function etiqueta_tendencia_(G, k)
i = G.ddTr(k).Value;
G.axT(k).YLabel.String = G.cat{i,2};
G.axT(k).YScale = G.cat{i,6};
end

% =========================================================================
%  EL DIAGRAMA DE BLOQUES DEL LAZO
% =========================================================================
function D = diagrama_(ax, C)
cla(ax);  hold(ax,'on');
ax.XLim = [0 100];  ax.YLim = [0 62];
ax.XTick = [];  ax.YTick = [];
ax.XColor = 'none';  ax.YColor = 'none';
ax.Color = C.panel;
try ax.Toolbar.Visible = 'off'; catch, end
try disableDefaultInteractivity(ax); catch, end

% ---- flechas (debajo de los bloques) ------------------------------------
D.f.w     = flecha_(ax, [19 50; 25 50], C.linea);            % consignas -> ley
D.f.ley   = flecha_(ax, [47 49; 55 49], C.acento);           % ley -> mandos
D.f.pi    = flecha_(ax, [62 21; 62 41], C.gris);             % PI -> mandos
D.f.u     = flecha_(ax, [69 49; 74 49], C.linea);            % mandos -> planta
D.f.y1    = flecha_(ax, [86 31; 86 3; 36 3; 36 7], C.linea); % planta -> estimador
D.f.y2    = flecha_(ax, [86 3; 62 3; 62 7], C.linea);        % planta -> PI
D.f.th    = flecha_(ax, [36 31; 36 38], C.acento);           % estimador -> ley (theta)
D.f.ldc1  = flecha_(ax, [19 30; 22 30; 22 58; 86 58; 86 57], C.linea); % demanda -> planta
D.f.ldc2  = flecha_(ax, [10 24; 10 21], C.linea);            % demanda -> tabla
D.f.tab   = flecha_(ax, [19 13; 25 13], C.linea);            % tabla -> estimador (theta nodo)

% ---- bloques --------------------------------------------------------------
caja_(ax, [1 42 18 14], C.cajaA, 'CONSIGNAS  w  (Usoro)');
caja_(ax, [1 24 18 13], C.cajaA, 'DEMANDA  ldc');
caja_(ax, [1 6 18 15],  C.cajaT, 'TABLA POR CARGA');
caja_(ax, [25 38 22 18], C.cajaL, 'LEY DE CONTROL  (12)');
caja_(ax, [25 7 22 24],  C.cajaE, 'ESTIMADOR RLS  (15)');
caja_(ax, [55 41 14 15], C.cajaU, 'MANDOS  u');
caja_(ax, [55 7 14 14],  C.cajaP, 'PI DE USORO');
caja_(ax, [74 31 25 26], C.cajaW, 'PLANTA  (47 estados)');
text(ax, 88, 33, 'caldera + turbina de 600 MW', 'HorizontalAlignment','center', ...
     'FontSize',8, 'Color',C.tenue);

% ---- valores --------------------------------------------------------------
D.t.w1   = val_(ax, 10, 51.5, 9);  D.t.w2 = val_(ax, 10, 48.5, 9);  D.t.w3 = val_(ax, 10, 45.5, 9);
D.t.carga = val_(ax, 10, 32, 11, true);
D.t.rampa = val_(ax, 10, 28.5, 9);
D.t.nodo  = val_(ax, 10, 15.5, 11, true);
D.t.tabla = val_(ax, 10, 11.5, 8.5);

D.t.leyA  = text(ax, 36, 51.2, 'u = (B₀ + λ B₀ᵀ⁻¹)⁻¹ [w − h]', 'HorizontalAlignment','center', ...
                 'FontSize',9, 'Color',[0.2 0.2 0.25]);
D.t.lam   = val_(ax, 36, 47.5, 10);
D.t.cond  = val_(ax, 36, 44.2, 10);
D.t.ley   = val_(ax, 36, 40.8, 8.5);

D.t.est   = text(ax, 36, 26.3, '—', 'HorizontalAlignment','center', 'FontSize',11, ...
                 'FontWeight','bold', 'Color',C.gris);
D.t.nupd  = val_(ax, 36, 22.8, 9);
D.t.dth   = val_(ax, 36, 19.8, 9);
D.t.trP   = val_(ax, 36, 16.8, 9);
D.t.lP    = val_(ax, 36, 13.8, 9);
D.t.beta  = val_(ax, 36, 10.5, 9);
text(ax, 38.5, 34.5, 'θ', 'FontSize',11, 'FontWeight','bold', 'Color',C.acento);
text(ax, 21.5, 14.8, 'θ nodo', 'FontSize',8, 'Color',C.tenue);
text(ax, 50.5, 50.5, 'ley', 'FontSize',8, 'Color',C.tenue);
text(ax, 63, 32, 'PI', 'FontSize',8, 'Color',C.tenue);
text(ax, 60, 4.3, 'y', 'FontSize',10, 'FontWeight','bold', 'Color',C.linea);

D.t.u1 = val_(ax, 62, 51.5, 9);  D.t.u2 = val_(ax, 62, 47.8, 9);  D.t.u3 = val_(ax, 62, 44.1, 9);
D.b.u1 = barra_(ax, [56 50.2 12 0.6], C);
D.b.u2 = barra_(ax, [56 46.5 12 0.6], C);
D.b.u3 = barra_(ax, [56 42.8 12 0.6], C);
D.t.pi = text(ax, 62, 14, '—', 'HorizontalAlignment','center', 'FontSize',10, ...
              'FontWeight','bold', 'Color',C.gris);
D.t.pi2 = val_(ax, 62, 10.5, 8.5);

D.t.tsso = val_(ax, 86.5, 52, 11, true);
D.t.trho = val_(ax, 86.5, 48.5, 11, true);
D.t.psso = val_(ax, 86.5, 45, 11, true);
D.t.act1 = val_(ax, 86.5, 41.2, 8.5);
D.t.act2 = val_(ax, 86.5, 38.7, 8.5);
D.t.act3 = val_(ax, 86.5, 36.2, 8.5);
hold(ax,'off');
end

function F = flecha_(ax, xy, c)
F.l = plot(ax, xy(:,1), xy(:,2), '-', 'Color',c, 'LineWidth',1.8);
p1 = xy(end-1,:);  p2 = xy(end,:);
d = p2 - p1;  d = d/norm(d);  n = [-d(2) d(1)];
a = 1.4;  b = 0.8;
v = [p2; p2 - a*d + b*n; p2 - a*d - b*n];
F.h = patch(ax, v(:,1), v(:,2), c, 'EdgeColor','none');
end

function flecha_color_(F, c, grosor, estilo)
set(F.l, 'Color',c, 'LineWidth',grosor, 'LineStyle',estilo);
set(F.h, 'FaceColor',c);
end

function caja_(ax, pos, cara, titulo)
rectangle(ax, 'Position',pos, 'Curvature',0.06, 'FaceColor',cara, ...
          'EdgeColor',[0.45 0.47 0.52], 'LineWidth',1);
text(ax, pos(1)+pos(3)/2, pos(2)+pos(4)-1.4, titulo, 'HorizontalAlignment','center', ...
     'FontSize',8.5, 'FontWeight','bold', 'Color',[0.20 0.22 0.28]);
end

function h = val_(ax, x, y, fs, negrita)
if nargin < 4, fs = 10; end
if nargin < 5, negrita = false; end
if negrita, fw = 'bold'; else, fw = 'normal'; end
h = text(ax, x, y, '—', 'HorizontalAlignment','center', 'FontSize',fs, ...
         'FontWeight',fw, 'Color',[0.10 0.10 0.12]);
end

function B = barra_(ax, pos, C)
rectangle(ax, 'Position',pos, 'FaceColor',[0.90 0.91 0.93], 'EdgeColor','none');
B.h = rectangle(ax, 'Position',[pos(1) pos(2) eps pos(4)], 'FaceColor',C.acento, 'EdgeColor','none');
B.pos = pos;
end

function barra_set_(B, v)
f = min(max((v - 1)/4, 0), 1);
B.h.Position = [B.pos(1) B.pos(2) max(f*B.pos(3), eps) B.pos(4)];
end

% =========================================================================
%  REFRESCO
% =========================================================================
function refresca_(fig)
if ~isvalid(fig), return, end
G = getappdata(fig,'G');  M = getappdata(fig,'M');
if isempty(M), return, end
C = G.C;
V = amin_hmi_motor('variables', M);
A = amin_hmi_motor('alarmas', M);
claves = A(:,1);

s = round(M.t);
G.lblT.Text = sprintf('t = %02d:%02d:%02d', floor(s/3600), floor(mod(s,3600)/60), mod(s,60));

% ---- demanda --------------------------------------------------------------
if V.rampa
    G.lblCarga.Text = sprintf('%s %%  →  %s %%', n_(V.carga,'%.1f'), n_(V.cargaObj,'%.1f'));
else
    G.lblCarga.Text = sprintf('%s %%   (ldc %s V)', n_(V.carga,'%.1f'), n_(V.ldc,'%.3f'));
end

% ---- estado del controlador ------------------------------------------------
if M.kc == 1
    G.lblCtrl.Text = 'Manda el PI de Usoro.';  G.lblCtrl.FontColor = C.tenue;
elseif V.espera && M.t == 0
    G.lblCtrl.Text = 'Arranca como en el artículo: historia = estado estable, manda la ley desde t = 0.';
    G.lblCtrl.FontColor = C.acento;
elseif V.espera
    G.lblCtrl.Text = 'Llenando la historia del regresor: manda el PI.';
    G.lblCtrl.FontColor = C.pausa;
else
    G.lblCtrl.Text = sprintf('Manda la ley (12).  %s, k = %d, %d par./fila, Tc = %g s.', ...
                             V.estructura, V.k, V.npar, V.Tc);
    G.lblCtrl.FontColor = C.acento;
end
if ~isempty(M.aviso), G.lblCtrl.Text = M.aviso;  G.lblCtrl.FontColor = C.alarma; end

% ---- indicadores ------------------------------------------------------------
v  = [V.tsso V.trho V.psso V.carga V.mw];
sp = [V.ktss V.ktrh V.kpsso NaN NaN];
tol = [15 20 50 NaN NaN];
u  = {' °R',' °R',' psia',' %',' MW'};
for k = 1:5
    Lm = G.gau(k).Limits;
    G.gau(k).Value = min(max(v(k), Lm(1)), Lm(2));
    G.lblG(k).Text = [n_(v(k),'%.1f') u{k}];
    fuera = false;
    if isfinite(sp(k))
        try
            G.gau(k).ScaleColors = [C.bandaOK; C.bandaMal; C.bandaMal];
            G.gau(k).ScaleColorLimits = [sp(k)-tol(k) sp(k)+tol(k); ...
                Lm(1) max(Lm(1),sp(k)-tol(k)); min(Lm(2),sp(k)+tol(k)) Lm(2)];
        catch
        end
        fuera = abs(v(k) - sp(k)) > tol(k);
    end
    if fuera, G.lblG(k).FontColor = C.alarma; else, G.lblG(k).FontColor = [0.1 0.1 0.12]; end
end

% ---- diagrama ---------------------------------------------------------------
D = G.D;
set(D.t.w1, 'String', ['TSSO  ' n_(V.ktss,'%.1f') ' °R']);
set(D.t.w2, 'String', ['TRHO  ' n_(V.ktrh,'%.1f') ' °R']);
set(D.t.w3, 'String', ['PSSO  ' n_(V.kpsso,'%.0f') ' psia']);
set(D.t.carga, 'String', [n_(V.carga,'%.1f') ' %']);
if V.rampa
    set(D.t.rampa, 'String', ['en rampa a ' n_(V.cargaObj,'%.1f') ' %'], 'Color', C.pausa);
else
    set(D.t.rampa, 'String', 'estable', 'Color', C.tenue);
end
usaTabla = M.kc >= 3;
if usaTabla && isfinite(V.nodo)
    set(D.t.nodo, 'String', ['nodo ' n_(V.nodo,'%g') ' %'], 'Color', [0.1 0.1 0.12]);
    set(D.t.tabla,'String', 'cambia en los puntos medios');
else
    set(D.t.nodo, 'String', 'no se usa', 'Color', C.gris);
    set(D.t.tabla,'String', '(sólo en los modificados)');
end

ctrlAmin = M.kc > 1;
set(D.t.lam,  'String', ['λ = ' n_(M.lambda,'%g')]);
if ctrlAmin && isfinite(V.condB0)
    set(D.t.cond, 'String', ['cond(B₀) = ' n_(V.condB0,'%.3g')], 'Color', color_(claves,'condB0',C));
else
    set(D.t.cond, 'String', 'cond(B₀) = —', 'Color', C.gris);
end
if M.literal, s = 'ley IMPRESA (errata)'; else, s = 'ley corregida'; end
set(D.t.ley, 'String', s);

if ~ctrlAmin
    set(D.t.est, 'String', 'fuera de servicio', 'Color', C.gris);
elseif V.adapt
    set(D.t.est, 'String', 'ACTUALIZANDO', 'Color', C.ok*0.8);
else
    set(D.t.est, 'String', 'CONGELADO', 'Color', C.pausa);
end
set(D.t.nupd, 'String', sprintf('%d actualizaciones', V.nUpd));
set(D.t.dth,  'String', ['‖Δθ‖ = ' n_(V.dth,'%.4g')]);
set(D.t.trP,  'String', ['tr P = ' n_(V.trP,'%.4g')]);
set(D.t.lP,   'String', ['λ(P): ' n_(V.lmin,'%.3g') ' a ' n_(V.lmax,'%.3g')]);
set(D.t.beta, 'String', ['β = ' n_(M.beta,'%g')]);

set(D.t.u1, 'String', ['CBMD ' n_(V.cbmd,'%.2f') ' V'], 'Color', color_(claves,'sat_CBMD',C));
set(D.t.u2, 'String', ['CXGG ' n_(V.cxgg,'%.2f') ' V'], 'Color', color_(claves,'sat_CXGG',C));
set(D.t.u3, 'String', ['CWSY ' n_(V.cwsy,'%.2f') ' V'], 'Color', color_(claves,'sat_CWSY',C));
barra_set_(D.b.u1, V.cbmd);  barra_set_(D.b.u2, V.cxgg);  barra_set_(D.b.u3, V.cwsy);

mandaLey = ctrlAmin && ~V.espera;
if mandaLey
    set(D.t.pi, 'String', 'en reserva', 'Color', C.gris);
    set(D.t.pi2,'String', 'integradores congelados');
    flecha_color_(D.f.ley, C.acento, 2.6, '-');
    flecha_color_(D.f.pi,  C.gris,   1.0, ':');
    flecha_color_(D.f.th,  C.acento, 2.0, '-');
else
    set(D.t.pi, 'String', 'MANDA', 'Color', C.ok*0.8);
    set(D.t.pi2,'String', 'los tres PI originales');
    flecha_color_(D.f.ley, C.gris,   1.0, ':');
    flecha_color_(D.f.pi,  C.ok*0.8, 2.6, '-');
    flecha_color_(D.f.th,  C.gris,   1.0, ':');
end
if usaTabla, flecha_color_(D.f.tab, C.linea, 1.8, '-');
else,        flecha_color_(D.f.tab, C.gris, 1.0, ':'); end

set(D.t.tsso, 'String', ['TSSO ' n_(V.tsso,'%.1f') ' °R'], 'Color', color_(claves,'tsso',C));
set(D.t.trho, 'String', ['TRHO ' n_(V.trho,'%.1f') ' °R'], 'Color', color_(claves,'trho',C));
set(D.t.psso, 'String', ['PSSO ' n_(V.psso,'%.1f') ' psia'], 'Color', color_(claves,'psso',C));
set(D.t.act1, 'String', sprintf('combustible %s lb/s', n_(V.wfl,'%.1f')));
set(D.t.act2, 'String', sprintf('inclinación %s°', n_(V.tilt,'%+.1f')));
set(D.t.act3, 'String', sprintf('atemperación %s lb/s   ·   %s MW', n_(V.wsy,'%.1f'), n_(V.mw,'%.0f')));

% ---- indices ----------------------------------------------------------------
Di = cell(3,2);
for r = 1:3
    Di{r,1} = n_(V.iae(r),'%.4g');  Di{r,2} = n_(V.itae(r),'%.4g');
end
G.tabI.Data = Di;

% ---- tendencias ---------------------------------------------------------------
ven = G.ddVen.Value;
for k = 1:4
    i = G.ddTr(k).Value;
    if G.cat{i,3} == 'p'
        Y = M.log(1:M.nlog,:);  tt = Y(:,1);
    else
        Y = M.logC(1:M.nlogC,:);  tt = Y(:,1);
    end
    if isempty(tt)
        set(G.hT(k),'XData',nan,'YData',nan);  set(G.hS(k),'XData',nan,'YData',nan);
    else
        if isfinite(ven), sel = tt >= M.t - ven; else, sel = true(size(tt)); end
        set(G.hT(k), 'XData',tt(sel), 'YData',G.cat{i,4}(Y(sel,:)));
        cs = G.cat{i,5};
        if cs > 0, set(G.hS(k),'XData',tt(sel),'YData',Y(sel,cs));
        else,      set(G.hS(k),'XData',nan,'YData',nan); end
    end
    if isfinite(ven), G.axT(k).XLim = [max(0, M.t - ven), max(M.t, 10)];
    else,             G.axT(k).XLim = [0 max(M.t, 10)]; end
end

% ---- alarmas --------------------------------------------------------------------
alarmas_(fig, A, M.t);
if isempty(A), G.lamp.Color = C.ok; else, G.lamp.Color = C.alarma; end
end

function c = color_(claves, prefijo, C)
if any(strncmp(claves, prefijo, numel(prefijo)))
    c = C.alarma;
else
    c = [0.10 0.10 0.12];
end
end

% =========================================================================
function alarmas_(fig, A, t)
G = getappdata(fig,'G');
H = getappdata(fig,'alarmas');
nuevas = A(:,1);
for k = numel(H.clave):-1:1
    if ~any(strcmp(H.clave{k}, nuevas))
        mensaje_(fig, sprintf('normalizada: %s', H.nombre{k}));
        H.clave(k) = [];  H.t0(k) = [];  H.nombre(k) = [];
    end
end
for k = 1:size(A,1)
    if ~any(strcmp(A{k,1}, H.clave))
        H.clave{end+1} = A{k,1};  H.t0(end+1) = t;  H.nombre{end+1} = A{k,2};
        mensaje_(fig, sprintf('ALARMA: %s  (%s)', A{k,2}, A{k,3}));
    end
end
setappdata(fig,'alarmas',H);
Dt = cell(size(A,1), 4);
for k = 1:size(A,1)
    j = find(strcmp(A{k,1}, H.clave), 1);
    Dt(k,:) = {sprintf('%.0f s', H.t0(j)), A{k,2}, A{k,3}, A{k,4}};
end
G.tabA.Data = Dt;
try
    removeStyle(G.tabA);
    if ~isempty(Dt)
        addStyle(G.tabA, uistyle('FontColor',G.C.alarma,'FontWeight','bold'), 'row', 1:size(Dt,1));
    end
catch
end
end

function mensaje_(fig, s)
G = getappdata(fig,'G');  M = getappdata(fig,'M');
if isempty(M), t = 0; else, t = M.t; end
L = getappdata(fig,'mensajes');
L = [{sprintf('[%6.0f s]  %s', t, s)}; L(:)];
if numel(L) > 200, L = L(1:200); end
setappdata(fig,'mensajes',L);
G.txtM.Value = L;
end

% =========================================================================
%  MARCHA
% =========================================================================
function alternar_(h)
fig = ancestor(h,'figure');
G = getappdata(fig,'G');  C = G.C;
if getappdata(fig,'corriendo')
    setappdata(fig,'corriendo',false);
    return
end
M = getappdata(fig,'M');
if ~isempty(M.error), uialert(fig, M.error, 'Simulación detenida');  return, end
setappdata(fig,'corriendo',true);
G.btIni.Text = 'Pausar';  G.btIni.BackgroundColor = C.pausa;
G.lblFase.Text = 'en marcha';  G.lblFase.BackgroundColor = C.ok*0.85;
G.ddCaso.Enable = 'off';
bucle_(fig);
if isvalid(fig)
    M = getappdata(fig,'M');
    G.btIni.Text = 'Continuar';  G.btIni.BackgroundColor = C.acento;
    if M.t == 0
        G.btIni.Text = 'Iniciar';
        G.lblFase.Text = 'detenida';  G.lblFase.BackgroundColor = C.gris;
    elseif isempty(M.error)
        G.lblFase.Text = 'en pausa';  G.lblFase.BackgroundColor = C.pausa;
    else
        G.lblFase.Text = 'DETENIDA';  G.lblFase.BackgroundColor = C.alarma;
        G.btIni.Text = 'Iniciar';
    end
    G.ddCaso.Enable = 'on';
end
end

function bucle_(fig)
G = getappdata(fig,'G');
M = getappdata(fig,'M');
tWall = tic;  tSim0 = M.t;  velAnt = G.ddVel.Value;
while isvalid(fig) && getappdata(fig,'corriendo')
    vel = G.ddVel.Value;
    if vel ~= velAnt
        Ma = getappdata(fig,'M');  tWall = tic;  tSim0 = Ma.t;  velAnt = vel;
    end
    M = getappdata(fig,'M');
    if isfinite(vel), n = max(1, round(vel*0.25/M.Ts)); else, n = 50; end
    M = amin_hmi_motor('avanzar', M, n);
    setappdata(fig,'M',M);
    if ~isempty(M.error)
        mensaje_(fig, M.error);
        setappdata(fig,'corriendo',false);
    end
    refresca_(fig);
    drawnow limitrate
    if ~isvalid(fig), return, end
    if isfinite(vel)
        Ma = getappdata(fig,'M');
        esperar = (Ma.t - tSim0)/vel - toc(tWall);
        if esperar > 0, pause(esperar); else, pause(0.001); end
    else
        pause(0.001);
    end
end
end

function reiniciar_(fig, primera)
setappdata(fig,'corriendo',false);
drawnow;
G = getappdata(fig,'G');  C = G.C;
vuelve = enraiz_(G); %#ok<NASGU>
d = uiprogressdlg(fig,'Title','Arranque','Message', ...
                  sprintf('estado estable al %g %%...', G.ddCaso.Value),'Indeterminate','on');
try
    M = amin_hmi_motor('crear', G.ddCaso.Value);
    M = amin_hmi_motor('lambda', M, G.efLam.Value);
    M = amin_hmi_motor('beta', M, G.efBeta.Value);
    M = amin_hmi_motor('ley', M, G.ddLey.Value == 1);
    M = amin_hmi_motor('estimador', M, G.ddEst.Value);
    M = amin_hmi_motor('modelo', M, G.ddMod.Value, G.ddK.Value);
    M = amin_hmi_motor('controlador', M, G.ddCtrl.Value);
catch err
    close(d);
    uialert(fig, err.message, 'No se pudo arrancar');
    return
end
close(d);
setappdata(fig,'M',M);
setappdata(fig,'alarmas', struct('clave',{{}}, 't0',[], 'nombre',{{}}));
setappdata(fig,'mensajes',{});
for k = 1:3, G.btEv(k).Value = false; end
G.efObj.Value = 20*M.ldc;
G.btIni.Text = 'Iniciar';  G.btIni.BackgroundColor = C.acento;
G.lblFase.Text = 'detenida';  G.lblFase.BackgroundColor = C.gris;
if primera, s = 'consola abierta'; else, s = 'reinicio'; end
mensaje_(fig, sprintf('%s: estado estable al %g %%, controlador: %s', s, ...
                      G.ddCaso.Value, G.ctrlNom{M.kc}));
if ~isempty(M.aviso), mensaje_(fig, M.aviso); end
refresca_(fig);
end

% =========================================================================
%  MANDOS DEL OPERADOR
% =========================================================================
function controlador_(h)
fig = ancestor(h,'figure');
G = getappdata(fig,'G');  M = getappdata(fig,'M');
kAnt = M.kc;
M = amin_hmi_motor('controlador', M, h.Value);
setappdata(fig,'M',M);
if ~isempty(M.aviso)
    mensaje_(fig, M.aviso);
    h.Value = M.kc;
elseif M.kc == 1
    mensaje_(fig, 'controlador: PI de Usoro (vuelta sin salto)');
else
    s = sprintf('controlador: %s', G.ctrlNom{M.kc});
    if M.t > 0 && kAnt ~= M.kc
        s = sprintf('%s; manda el PI hasta llenar la historia (%d periodos de %g s)', ...
                    s, M.S.M.N + M.S.M.k, M.S.M.T);
    end
    mensaje_(fig, s);
end
refresca_(fig);
end

function modelo_(h)
fig = ancestor(h,'figure');
G = getappdata(fig,'G');  M = getappdata(fig,'M');
vuelve = enraiz_(G); %#ok<NASGU>
M = amin_hmi_motor('modelo', M, G.ddMod.Value, G.ddK.Value);
setappdata(fig,'M',M);
mensaje_(fig, sprintf('modelo %s, k = %d', ternario_(G.ddMod.Value == 1,'3×3','3×4'), G.ddK.Value));
if ~isempty(M.aviso)
    mensaje_(fig, M.aviso);
    G.ddCtrl.Value = M.kc;
end
refresca_(fig);
end

function s = ternario_(c, a, b)
if c, s = a; else, s = b; end
end

function param_(h, cual)
fig = ancestor(h,'figure');
M = getappdata(fig,'M');
switch cual
    case 'lambda', M = amin_hmi_motor('lambda', M, h.Value);
                   mensaje_(fig, ['λ = ' n_(h.Value,'%g')]);
    case 'beta',   M = amin_hmi_motor('beta', M, h.Value);
                   mensaje_(fig, ['β = ' n_(h.Value,'%g')]);
    case 'ley',    M = amin_hmi_motor('ley', M, h.Value == 1);
                   mensaje_(fig, ['ley ' ternario_(h.Value == 1,'IMPRESA (errata)','corregida')]);
end
setappdata(fig,'M',M);
refresca_(fig);
end

function estimador_(h)
fig = ancestor(h,'figure');
M = getappdata(fig,'M');
M = amin_hmi_motor('estimador', M, h.Value);
setappdata(fig,'M',M);
mensaje_(fig, ['estimador: ' h.Value]);
refresca_(fig);
end

function reiniciaP_(h)
fig = ancestor(h,'figure');
M = getappdata(fig,'M');
M = amin_hmi_motor('reiniciaP', M);
setappdata(fig,'M',M);
if ischar(M.P0), txt = 'la heredada de la identificacion'; else, txt = sprintf('%g·I', M.P0); end
mensaje_(fig, ['covarianza reiniciada: P = ' txt]);
refresca_(fig);
end

function rampa_(h, destino)
fig = ancestor(h,'figure');
G = getappdata(fig,'G');  M = getappdata(fig,'M');
if isempty(destino)                          % aplicar
    obj = G.efObj.Value;  vel = G.ddRampa.Value;
elseif destino < 0                           % detener
    obj = 20*M.ldc;  vel = [];
else                                         % prueba del articulo
    obj = destino;  vel = 10;
    ini = 160 - destino;                     % 90 -> 70 parte de 90, 70 -> 90 de 70
    if abs(20*M.ldc - ini) > 0.5
        mensaje_(fig, sprintf(['OJO: la prueba del artículo parte de %g %% y la planta ' ...
                  'está en %s %%'], ini, n_(20*M.ldc,'%.1f')));
    end
end
M = amin_hmi_motor('demanda', M, obj, vel);
setappdata(fig,'M',M);
if destino < 0
    mensaje_(fig, sprintf('rampa detenida en %s %%', n_(obj,'%.1f')));
else
    mensaje_(fig, sprintf('rampa de carga a %s %% a %g %%/min', n_(obj,'%.1f'), M.ldcVel*20*60));
end
refresca_(fig);
end

function evento_(h, cual)
fig = ancestor(h,'figure');
M = getappdata(fig,'M');
M = amin_hmi_motor('evento', M, cual, h.Value);
setappdata(fig,'M',M);
nom = struct('tension','V.5 caída de tensión auxiliar', 'frecuencia','V.6 caída de frecuencia', ...
             'ventiladores','V.7 salida de un par de ventiladores');
if h.Value, s = 'EVENTO: '; else, s = 'restablecido: '; end
mensaje_(fig, [s nom.(cual)]);
refresca_(fig);
end

function indices0_(h)
fig = ancestor(h,'figure');
M = getappdata(fig,'M');
M = amin_hmi_motor('indices0', M);
setappdata(fig,'M',M);
mensaje_(fig, 'índices IAE e ITAE en cero');
refresca_(fig);
end

function cambiaTendencia_(h, k)
fig = ancestor(h,'figure');
G = getappdata(fig,'G');
etiqueta_tendencia_(G, k);
refresca_(fig);
end

% =========================================================================
function exportar_(h)
fig = ancestor(h,'figure');
setappdata(fig,'corriendo',false);
G = getappdata(fig,'G');  M = getappdata(fig,'M');
carpeta = fullfile(G.raiz, 'resultados', 'hmi');
if exist(carpeta,'dir') ~= 7, mkdir(carpeta); end
def = fullfile(carpeta, sprintf('amin_hmi_%s.mat', datestr(now,'yyyymmdd_HHMMSS'))); %#ok<TNOW1,DATST>
[f, d] = uiputfile('*.mat', 'Exportar corrida', def);
figure(fig);
if isequal(f,0), return, end
planta = M.log(1:M.nlog,:); %#ok<NASGU>
columnas = {'t','ntr','mwo','psso','whp','c3md','cacvd','cfld','card', ...
    'vdrw','vdew','cfwd','cdwd','hsso','hrho','csyd','cxggd','nfp','cgrd', ...
    'cfnd','twwm','nfd','nid','nrp','ncp','tsso','trho','psso_y','cbmd', ...
    'cxgg','cwsy','ktss','ktrh','kpsso','ldc','tsso_m','trho_m','psso_m'}; %#ok<NASGU>
controlador = M.logC(1:M.nlogC,:); %#ok<NASGU>
columnasC = {'t','condB0','dtheta','trP','lambdaMaxP','lambdaMinP','nodo', ...
             'estimadorActualizando','mandaLaLey'}; %#ok<NASGU>
mensajes = flipud(getappdata(fig,'mensajes')); %#ok<NASGU>
config = struct('arranque',M.pct0, 'controlador',G.ctrlNom{M.kc}, 'lambda',M.lambda, ...
                'beta',M.beta, 'modelo',M.mod, 'k',M.kk, 'leyImpresa',M.literal); %#ok<NASGU>
save(fullfile(d,f), 'planta','columnas','controlador','columnasC','mensajes','config','-v7');
mensaje_(fig, ['corrida exportada: ' fullfile(d,f)]);
end

% =========================================================================
function cerrar_(fig)
setappdata(fig,'corriendo',false);
delete(fig);
end

function c = enraiz_(G)
%ENRAIZ_  Se coloca en la raiz de la replica; al salir de la funcion que lo
%   llamo vuelve a la carpeta anterior.
antes = pwd;
if ~strcmp(antes, G.raiz), cd(G.raiz); end
c = onCleanup(@() cd(antes));
end

function et_(g, s, ayuda)
u = uilabel(g,'Text',s,'FontColor',[0.30 0.30 0.34]);
if nargin > 2, tip_(u, ayuda); end
end

function tip_(h, s)
try h.Tooltip = s; catch, end
end

function s = n_(v, fmt)
s = strrep(sprintf(fmt, v), '.', ',');
end

% =========================================================================
function C = paleta_()
C.fondo  = [0.93 0.94 0.95];
C.panel  = [1 1 1];
C.barra  = [0.17 0.22 0.30];
C.tenue  = [0.40 0.40 0.45];
C.acento = [0.20 0.45 0.80];
C.gris   = [0.60 0.62 0.66];
C.linea  = [0.30 0.32 0.38];
C.ok     = [0.20 0.70 0.35];
C.pausa  = [0.86 0.54 0.13];
C.alarma = [0.85 0.15 0.20];
C.bandaOK  = [0.55 0.82 0.60];
C.bandaMal = [0.96 0.80 0.80];
C.s1 = [0.25 0.45 0.80];  C.s2 = [0.85 0.45 0.15];
C.s3 = [0.56 0.29 0.66];  C.s4 = [0.13 0.55 0.45];
C.cajaA = [0.93 0.95 0.99];
C.cajaT = [0.96 0.93 0.99];
C.cajaL = [0.90 0.94 1.00];
C.cajaE = [0.92 0.97 0.93];
C.cajaU = [0.97 0.95 0.90];
C.cajaP = [0.95 0.95 0.96];
C.cajaW = [0.99 0.93 0.91];
end
