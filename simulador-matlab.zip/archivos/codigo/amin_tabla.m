function TB = amin_tabla(M0, varargin)
%AMIN_TABLA  Los juegos de parametros por nivel de carga, seccion V.
%
%   TB = AMIN_TABLA(M0)
%   TB = AMIN_TABLA(M0, 'pct',70:5:90, 'asentar',2000, 'lambda',1)
%
%   ES LA «MODIFICACION» DEL ARTICULO, y conviene citarla entera porque
%   define el procedimiento sin ambiguedad:
%
%     «This is demonstrated by dividing the load range between the initial
%      and final loads of the transient into 5% load intervals and assuming
%      that in each interval, the system can be represented by a linear time
%      invariant model. [...] Parameters of the self-tuning controller for
%      each of the load intervals were obtained by running the system under
%      the self-tuning controller to steady state at a constant load.  The
%      sets of the controller parameters were stored.»
%
%   O sea: NO se reidentifica en lazo abierto en cada nivel.  Se pone el
%   controlador auto-sintonizable a trabajar A CARGA CONSTANTE en ese nivel,
%   con el estimador encendido, se deja llegar al regimen permanente y se
%   guarda el theta con el que se quedo.  Eso es lo que se hace aqui.
%
%   El modelo de partida en cada nivel es M0 ---el identificado al 75 %---
%   referido al punto de operacion de ESE nivel: el theta se conserva y lo
%   que cambia son u_ss e y_ss.  Es lo unico coherente con un modelo
%   incremental, y ademas es lo que haria un controlador real al conmutar.
%
%   OPCIONES
%     'pct'      niveles de carga                               [70:5:90]
%     'asentar'  segundos de carga constante bajo el STC           [2000]
%     'lambda'   la del controlador (hueco 1 del README)              [1]
%     'beta'     factor de olvido (hueco 2)                        [0.99]
%     'P0'       covarianza inicial en linea                        [1e2]
%     'cache'    guardar/leer datos/amin_tabla.mat                 [true]
%                (datos/amin_tabla<sufijo>.mat: _ldc si M0 es 3x4, _k2 si
%                su retardo es k = 2; ver AMIN_SUFIJO)
%
%   MODELO 3x4.  Si M0 trae la demanda ldc como entrada exogena, cada nivel
%   se refiere tambien al ldc de ese nivel (d_ss = 0,05*pct) y el
%   procedimiento es el mismo.  Se guarda en otro archivo para que las dos
%   tablas convivan: el simulador elige cual cargar.
%
%   DEVUELVE  TB.pct (1 x L), TB.M (1 x L de modelos), TB.ss (1 x L),
%             TB.nupd, TB.zmax, TB.condB0, TB.opt
%
%   See also AMIN_STC_INIT, AMIN_LAZO, AMIN_ESTACIONARIO.

opt = struct('pct',70:5:90, 'asentar',2000, 'lambda',1, 'beta',0.99, ...
             'P0',1e2, 'cache',true, 'verbose',true);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_tabla:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

% LA CACHE TIENE QUE DEPENDER DEL MODELO DE PARTIDA, no solo de las opciones.
% Si se cambia el orden N (por ejemplo, de la eleccion del criterio al 5 del
% articulo) la tabla guardada deja de valer, y leerla sin comprobarlo mezcla
% un modelo con otro sin avisar.
if ~isfield(M0,'nd')        % modelo guardado antes del 3x4: es 3x3
    M0 = amin_modelo(M0.th, M0.N, M0.nu, M0.ny, M0.k, M0.T, M0.u_ss, M0.y_ss, M0.pct);
end
huella = struct('N',M0.N, 'npar',M0.npar, 'th',sum(abs(M0.th(:))));

arch = fullfile('datos', ['amin_tabla' amin_sufijo(M0) '.mat']);
if opt.cache && exist(arch,'file') == 2
    q = load(arch);
    mismoM = isfield(q.TB,'huella') && amin_misma_huella(q.TB.huella, huella);
    if ~mismoM && opt.verbose
        fprintf(['tabla por carga: la guardada es de otro modelo ' ...
                 '(N distinto o theta distinto); se recalcula\n']);
    end
    if mismoM && isequal(q.TB.opt.pct, opt.pct) && q.TB.opt.lambda == opt.lambda ...
            && q.TB.opt.beta == opt.beta && q.TB.opt.asentar == opt.asentar
        TB = q.TB;
        if opt.verbose
            fprintf('tabla por carga: leida de %s (%d niveles)\n', ...
                    arch, numel(TB.pct));
        end
        return
    end
end

L = numel(opt.pct);
TB = struct();
TB.pct = opt.pct(:).';
TB.opt = opt;
TB.huella = huella;
% Se siembra con el modelo de partida ya reempaquetado, para que todas las
% entradas del arreglo tengan exactamente los mismos campos.
M0n = amin_modelo(M0.th, M0.N, M0.nu, M0.ny, M0.k, M0.T, M0.u_ss, M0.y_ss, NaN, M0.d_ss);
TB.M   = repmat(M0n, 1, L);
TB.nupd = zeros(1,L);  TB.zmax = zeros(1,L);  TB.condB0 = zeros(1,L);
% Cuanto se ha movido theta respecto del modelo de partida en cada nivel.  A
% carga constante NO hay excitacion, asi que este numero dice si el
% procedimiento de la seccion V identifica algo o solo recoloca el punto de
% operacion.  Es informacion que el articulo no da y que hay que mirar.
TB.dth = zeros(1,L);

for q = 1:L
    pct = opt.pct(q);
    Sss = amin_estacionario(pct, 'verbose',opt.verbose);

    % Modelo de partida: el theta del 75 %, referido a ESTE punto.
    dq = [];  if M0.nd > 0, dq = Sss.ldc; end
    Mq = amin_modelo(M0.th, M0.N, M0.nu, M0.ny, M0.k, M0.T, Sss.u, Sss.y, pct, dq);

    S = amin_stc_init(Mq, 'lambda',opt.lambda, 'beta',opt.beta, ...
                      'adapt',true, 'P0',opt.P0, 'Tc',M0.T);

    P = amin_planta(Sss.base, 'ldcStart',Sss.ldc, 'ldcRate',0, ...
                     'ldcT0',0, 'ldcT1',0, ...
                     'samples', round(opt.asentar/0.1)+1);
    P.x0  = Sss.x0;
    P.ldc = Sss.ldc;

    R = amin_lazo(S, P);

    % El modelo que devuelve el lazo se reempaqueta antes de guardarlo: asi
    % TB.M es un arreglo homogeneo pase lo que pase con los campos.
    Rm = R.S.M;
    TB.M(q) = amin_modelo(Rm.th, Rm.N, Rm.nu, Rm.ny, Rm.k, Rm.T, ...
                          Rm.u_ss, Rm.y_ss, pct, Rm.d_ss);
    TB.ss(q)  = Sss;
    TB.nupd(q)  = R.S.E.n;
    TB.zmax(q)  = zmax_(R.S.M);
    TB.condB0(q) = cond(R.S.M.B(:,:,1));
    TB.dth(q)  = norm(Rm.th - Mq.th, 'fro') / max(norm(Mq.th,'fro'), eps);

    if opt.verbose
        fprintf(['nivel %5.1f %%:  %3d actualizaciones,  |z|max %7.4f,  ' ...
                 'cond(B0) %8.3g,  |dtheta| %8.2e,  e_max %6.2f %6.2f %7.2f\n'], ...
                pct, TB.nupd(q), TB.zmax(q), TB.condB0(q), TB.dth(q), R.emax);
    end
end

if opt.cache
    if exist('datos','dir') ~= 7, mkdir('datos'); end
    save(arch, 'TB', '-v7');
end
end

% =========================================================================
function z = zmax_(M)
N = M.N;  ny = M.ny;
C = zeros(ny*N);
for i = 1:N
    C(1:ny, (i-1)*ny + (1:ny)) = -M.A(:,:,i);
end
if N > 1
    C(ny+1:end, 1:ny*(N-1)) = eye(ny*(N-1));
end
z = max(abs(eig(C)));
end
