function [u, S] = amin_stc(S, y, w, uPI, ldc)
%AMIN_STC  Un instante del controlador auto-sintonizable de Amin.
%
%   [U, S] = AMIN_STC(S, Y, W, UPI)
%   [U, S] = AMIN_STC(S, Y, W, UPI, LDC)      modelo 3x4
%
%   Y y W son las salidas medidas y sus consignas, en unidades fisicas
%   (TSSO R, TRHO R, PSSO psia).  U sale en voltios (CBMD, CXGG, CWSY), o
%   VACIO mientras no haya historia suficiente para aplicar la ley ---en ese
%   caso el lazo debe seguir con el mando original de Usoro, que es lo que
%   hace AMIN_LAZO---.  UPI es ese mando original: hace falta SIEMPRE, porque
%   la historia de entradas del estimador tiene que contener lo que de verdad
%   entro en la planta, tanto durante el calentamiento como despues.
%
%   ES EL ALGORITMO DE LA PAGINA 342, en su orden:
%
%     1. leer y(t) y w(t)
%     2. actualizar el vector de datos x(t-k)
%     3. actualizar la estimacion de theta
%     4. calcular y*(t+k|t) en terminos de u(t)
%     5. calcular Q(q^-1) = (B0')^-1 (Q0' Q'(q^-1))
%     6. calcular u(t) con (12)
%     7. t = t+1
%
%   El paso 5 con Q'(q^-1) = sqrt(lambda) I es simplemente lambda (B0')^-1,
%   que es el termino que aparece en la ley reducida.
%
%   UNA ERRATA DEL ARTICULO, Y HAY QUE DECLARARLA.  La ley impresa en la
%   pagina 344 es
%
%       u(t) = {B0 + lambda (B0')^-1}^-1 { [I - A(q^-1)] y(t+1)
%                                          - [B(q^-1) - B0] u(t) + w(t) }
%
%   y [I - A(q^-1)] y(t+1) = -A1 y(t) - ... - AN y(t-N+1).  Sustituyendo eso
%   en el modelo (16) NO sale y(t+1) = w: sale y(t+1) = w - 2 sum Ai y(t+1-i).
%   El despeje correcto de (16) con y(t+1) = w es
%
%       B0 u(t) = w(t) + A1 y(t) + ... + AN y(t-N+1)
%                      - B1 u(t-1) - ... - BN u(t-N)
%
%   o sea el mismo corchete con el PRIMER TERMINO CAMBIADO DE SIGNO.  Es una
%   errata de composicion, del tipo que abunda en los originales de camara de
%   1984, y se comprueba en un renglon: con lambda = 0 y modelo exacto, la
%   version corregida deja y(t+1) = w a precision de maquina y la impresa no
%   (VERIFICA_AMIN, prueba 8).
%
%   Se implementa la CORREGIDA.  Poniendo S.literal = true se usa la impresa,
%   para poder ensenar la diferencia en vez de tener que afirmarla.
%
%   MODELO 3x4 ---NO ES DEL ARTICULO---.  Con la demanda de carga medida
%   como entrada exogena, el despeje de (16) con y(t+1) = w gana un termino:
%
%       B0 u(t) = w(t) + A1 y(t) + ... + AN y(t-N+1)
%                      - B1 u(t-1) - ... - BN u(t-N)
%                      - D0 ldc(t) - D1 ldc(t-1) - ... - DN ldc(t-N)
%
%   ldc(t) ya se conoce en el instante t, asi que D0 ldc(t) es
%   PREALIMENTACION pura: el controlador corrige el mando por el cambio de
%   demanda antes de que aparezca en las salidas.  Es lo unico que cambia en
%   la ley; lambda entra igual.  LDC va en voltios (1..5 V, el del Load
%   Demand Computer) y hace falta si y solo si S.M.nd > 0.
%
%   LO QUE NO LLEVA, y es deliberado: no hay zona muerta, ni cota de traza,
%   ni limite del paso de theta, ni proyeccion de B0, ni congelacion del
%   estimador por movimiento de la demanda.  Nada de eso esta en el articulo.
%   La unica salvaguarda es el recorte al rango 1..5 V de los transductores
%   de Usoro, que es de la PLANTA y no del controlador.
%
%   See also AMIN_STC_INIT, AMIN_LAZO.

M   = S.M;
% Un nodo de una tabla guardada antes del 3x4 no trae nd: es 3x3.
if ~isfield(M,'nd')
    M = amin_modelo(M.th, M.N, M.nu, M.ny, M.k, M.T, M.u_ss, M.y_ss, M.pct);
    S.M = M;
end
N   = M.N;   nu = M.nu;  ny = M.ny;  nd = M.nd;
lag = S.lag;
k   = M.k;

yd = y(:) - M.y_ss;
wd = w(:) - M.y_ss;

% ---- 1 y 2: entra la medida nueva --------------------------------------
S.Yh = [yd, S.Yh(:, 1:end-1)];
S.nc = S.nc + 1;
if nd > 0
    if nargin < 5 || isempty(ldc)
        error('amin_stc:ldc', ...
              'El modelo es %s: hace falta LDC, la demanda de carga medida.', ...
              M.estructura);
    end
    if ~isfield(S,'Dh') || size(S.Dh,1) ~= nd
        error('amin_stc:Dh', ['El controlador se preparo para un modelo sin ' ...
              'ldc.  Vuelve a llamar a AMIN_STC_INIT con el modelo 3x4.']);
    end
    S.Dh = [ldc(:) - M.d_ss, S.Dh(:, 1:end-1)];
end

% Hay ley en cuanto la historia que pide el regresor esta completa (el mando
% mas viejo que usa es u(t-(N+k)Tm), columna (N+k)*lag de S.Uh).  Con el
% arranque del articulo ('estable') lo esta desde el primer instante, porque
% la historia se inicializa en el estado estable ---cero incremental--- y el
% primer mando sale igual a u_ss.  Con 'espera' hay que llenarla de verdad.
listo = all(isfinite(S.Uh(:, (N+k)*lag))) && ...
        all(isfinite(S.Yh(:, (N+k-1)*lag + 1)));
if nd > 0
    listo = listo && all(isfinite(S.Dh(:, (N+k)*lag + 1)));
end

if ~listo
    % Calentamiento: manda el PI de Usoro, pero su mando SE REGISTRA, porque
    % es el que explica las salidas que el estimador va a ver.
    u = [];
    S.Uh = [uPI(:) - M.u_ss, S.Uh(:, 1:end-1)];
    return
end

% ---- 3: actualizar theta -----------------------------------------------
% Regresor de la ecuacion (17b) con el bloque de salidas de N terminos
% (ver AMIN_MODELO).  Tm = T es el periodo del MODELO (20 s), Tc el del
% mando y lag = Tm/Tc (1 con el mando cada 20 s, 10 con el mando cada 2 s).
% Las historias van en la rejilla de control:
%   S.Yh(:,m) = y(t - (m-1) Tc)    y(t) ya entro en este instante
%   S.Dh(:,m) = ldc(t - (m-1) Tc)  ldc(t) ya entro en este instante
%   S.Uh(:,m) = u(t - m Tc)        u(t) todavia no se ha calculado
% El valor de hace j periodos del MODELO esta entonces en la columna
% j*lag + 1 de S.Yh y S.Dh, pero en la columna j*lag de S.Uh (la historia de
% mandos empieza un instante de control atras).  Asi las muestras quedan a
% Tm una de otra tambien con el mando cada 2 s, que es lo que dice el
% articulo: «the samples of inputs and outputs needed to calculate the
% controls are 20 seconds apart».  Con k = 1:
%   x(t-1) = [u(t-Tm) ... u(t-(N+1)Tm), y(t-Tm) ... y(t-N Tm), ldc(t-Tm) ...]
% y con k general cada bloque se corre k-1 periodos mas atras (abajo).
%
% CORREGIDO 2026-09-29.  Antes el bloque de mandos usaba la columna
% (j-1)*lag + 1, que con lag = 1 es la misma, pero con lag = 10 tomaba
% u(t-2 s), u(t-22 s), ... en vez de u(t-20 s), u(t-40 s), ...  Solo
% afectaba al mando cada 2 s ('mstc2').
upd = false;
if S.adapt
    % RETARDO k.  Forma predictora de (17b): y(t) = theta x(t-k) con
    % x(t-k) = [u(t-k) ... u(t-k-N), y(t-k) ... y(t-k-N+1), ldc(t-k) ...].
    % S.Uh(:,1) es el ultimo mando aplicado, u(t-Tc) (u(t) aun no se ha
    % calculado), y S.Yh(:,1) es y(t), que acaba de entrar.  Por eso
    % u(t-(k+j)Tm) esta en la columna (k+j)*lag y no en (k+j)*lag + 1.
    x = zeros(M.npar,1);
    for j = 0:N
        x(j*nu + (1:nu)) = S.Uh(:, (k+j)*lag);        % u(t-(k+j)Tm)
    end
    off = (N+1)*nu;
    for i = 1:N
        x(off + (i-1)*ny + (1:ny)) = S.Yh(:, (k+i-1)*lag + 1);
    end
    % Bloque de la demanda, ldc(t-Tm) ... ldc(t-(N+1)Tm).  S.Dh(:,1) es
    % ldc(t), que entro al principio de este instante.
    off = (N+1)*nu + N*ny;
    if nd > 0
        for j = 0:N
            x(off + j*nd + (1:nd)) = S.Dh(:, (k+j)*lag + 1);
        end
    end
    if all(isfinite(x))
        S.E = amin_rls(S.E, yd, x);
        S.M = amin_modelo(S.E.th, N, nu, ny, M.k, M.T, M.u_ss, M.y_ss, ...
                          M.pct, M.d_ss);
        M   = S.M;
        upd = true;
    end
end

% ---- 4 y 6: la ley (12) ------------------------------------------------
% Con el modelo en forma predictora, theta*x(t) ES y*(t+k|t) para cualquier
% k, asi que el despeje de abajo no depende de k: pone y*(t+k|t) = w.
B0 = M.B(:,:,1);
cB = cond(B0);
if ~isfinite(cB) || cB > 1e12
    warning('amin_stc:B0', ...
        ['B0 esta practicamente singular (cond = %.3g) en el instante %d. ' ...
         'El articulo advierte de esto al bajar el periodo de muestreo.'], ...
        cB, S.nc);
end

% SIGNO DEL BLOQUE DE SALIDAS: ver la nota de cabecera.  sA = +1 es la
% version consistente con el modelo (16); sA = -1 reproduce la ley tal como
% esta impresa, que no coloca la salida en la consigna.
sA = 1;
if isfield(S,'literal') && S.literal, sA = -1; end

rhs = wd;
for i = 1:N                                   % +A1 y(t) + ... + AN y(t-(N-1)Tm)
    rhs = rhs + sA * M.A(:,:,i) * S.Yh(:, (i-1)*lag + 1);
end
for j = 1:N                                   % -B1 u(t-Tm) - ... - BN u(t-N Tm)
    rhs = rhs - M.B(:,:,j+1) * S.Uh(:, j*lag);
end
if nd > 0                                     % solo 3x4: prealimentacion
    for j = 0:N                               % -D0 ldc(t) - ... - DN ldc(t-N Tm)
        rhs = rhs - M.D(:,:,j+1) * S.Dh(:, j*lag + 1);
    end
end

G  = B0 + S.lambda * inv(B0.');               %#ok<MINV>  asi esta escrito en (12)
ud = G \ rhs;

u = M.u_ss + ud;

% ---- el unico limite: el rango del transductor de Usoro ----------------
u = min(max(u, S.Umin), S.Umax);

% ---- 7 -----------------------------------------------------------------
S.Uh = [u(:) - M.u_ss, S.Uh(:, 1:end-1)];
S.log.nc = S.log.nc + 1;
S.log.upd(S.log.nc,1)    = upd;
S.log.condB0(S.log.nc,1) = cB;
end
