function P = amin_covarianza(M, varargin)
%AMIN_COVARIANZA  La covarianza P con que TERMINA la identificacion.
%
%   P = AMIN_COVARIANZA(M)
%   P = AMIN_COVARIANZA(M, 'datos','datos/amin_datos_75_valvula.mat')
%
%   ES LA P(0) DEL AUTO-SINTONIZABLE EN LINEA (hueco 3 del README).  El
%   articulo dice que el STC «was started with the parameters of the 5th
%   order AR model estimated in the previous section», pero no dice con que
%   covarianza.  Lo coherente es arrancar tambien con la P con que termino
%   ese mismo RLS encadenado: es la incertidumbre que el estimador tiene
%   realmente sobre esos parametros.  Con un P(0) arbitrario grande
%   (10^2 I, la primera version de la replica) el estimador da pasos
%   enormes con la poca excitacion de la rampa, B0 se vuelve casi singular y
%   los mandos se saturan el 92-98 % del tiempo; con la P heredada el STC se
%   acerca a la figura 6 del articulo (articulo CITCA/TyCAP, Sec. 3.4).
%
%   COMO SE CALCULA.  En el RLS la P NO depende de las salidas ni de theta:
%   solo de los regresores.  Asi que basta repetir el RLS encadenado de
%   AMIN_IDENT (P0 = 1e4 I, beta = 1, historia en estado estable al empezar
%   cada corrida) sobre los mismos datos.  Por la misma razon sirve para
%   cualquier juego de parametros con la misma estructura (N, k, nd), por
%   ejemplo los nodos de la tabla por carga.
%
%   Si el modelo ya trae el campo Pf (AMIN_IDENT lo guarda) se usa ese.
%   Si no hay datos compatibles con la estructura del modelo (modelos
%   sinteticos de las pruebas), devuelve [] y AMIN_STC_INIT usa 10^2 I.
%
%   OPCIONES
%     'datos'   archivo de datos de identificacion.  Vacio = el que
%               corresponde al modelo: datos/amin_datos_75.mat (3x3) o
%               datos/amin_datos_75_ldc.mat (3x4)                      [[]]
%     'P0'      P(0) de la identificacion                              [1e4]
%
%   See also AMIN_IDENT, AMIN_STC_INIT, AMIN_RLS.

opt = struct('datos',[], 'P0',1e4);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_covarianza:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

if isfield(M,'Pf') && ~isempty(M.Pf) && isempty(opt.datos)
    P = M.Pf;
    return
end
if ~isfield(M,'nd'), M.nd = 0; end

if isempty(opt.datos)
    raiz = fileparts(fileparts(mfilename('fullpath')));
    if M.nd > 0
        opt.datos = fullfile(raiz, 'datos', 'amin_datos_75_ldc.mat');
    else
        opt.datos = fullfile(raiz, 'datos', 'amin_datos_75.mat');
    end
end

persistent cache
if isempty(cache), cache = struct('clave',{}, 'P',{}); end
clave = sprintf('%s|N%d|k%d|nd%d|P0%g', opt.datos, M.N, M.k, M.nd, opt.P0);
for c = 1:numel(cache)
    if strcmp(cache(c).clave, clave), P = cache(c).P; return, end
end

P = [];
if exist(opt.datos, 'file') ~= 2, return, end
q = load(opt.datos);  D = q.D;
nu = size(D.run(1).U,1);  ny = size(D.run(1).Y,1);
nd = 0;
if isfield(D.run,'L') && ~isempty(D.run(1).L), nd = size(D.run(1).L,1); end
if nu ~= M.nu || ny ~= M.ny || nd ~= M.nd, return, end

N = M.N;  k = M.k;
npar = (N+1)*nu + N*ny + (N+1)*nd;
if npar ~= M.npar, return, end

E = struct('th', zeros(ny, npar), 'P', opt.P0*eye(npar), 'beta', 1, 'n', 0);
for r = 1:numel(D.run)
    n  = size(D.run(r).Y, 2);
    Ud = D.run(r).U - D.u_ss(:)*ones(1,n);
    Yd = D.run(r).Y - D.y_ss(:)*ones(1,n);
    if nd > 0, Ld = D.run(r).L - D.d_ss(:)*ones(1,n); else, Ld = zeros(0,n); end
    pad = max(N+k, N);
    Ud = [zeros(nu,pad), Ud];  Yd = [zeros(ny,pad), Yd];  Ld = [zeros(nd,pad), Ld];
    for t = (pad+1):(pad+n)
        E = amin_rls(E, Yd(:,t), regresor_(Ud, Yd, Ld, t, N, k));
    end
end
P = E.P;
cache(end+1) = struct('clave', clave, 'P', P);
end

% =========================================================================
function x = regresor_(Ud, Yd, Ld, t, N, k)
%REGRESOR_  El mismo de AMIN_IDENT (ec. 17b; demanda al final en el 3x4).
nu = size(Ud,1);  ny = size(Yd,1);  nd = size(Ld,1);
x = zeros((N+1)*nu + N*ny + (N+1)*nd, 1);
for j = 0:N
    x(j*nu + (1:nu)) = Ud(:, t-k-j);
end
off = (N+1)*nu;
for i = 1:N
    x(off + (i-1)*ny + (1:ny)) = Yd(:, t-k-i+1);
end
off = (N+1)*nu + N*ny;
if nd > 0
    for j = 0:N
        x(off + j*nd + (1:nd)) = Ld(:, t-k-j);
    end
end
end
