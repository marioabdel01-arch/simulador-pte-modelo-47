function amin_tabla4_tex(arch, filas, R, Ri, piIAE, piITAE, bien, mal, cfg)
%AMIN_TABLA4_TEX  Escribe la Tabla 4 del articulo (IAE e ITAE normalizados
%   contra el PI de Usoro) como codigo LaTeX, con las celdas coloreadas
%   igual que en el simulador: verde si el cociente es < 1 (mejora al PI),
%   rojo si es > 1 (empeora).  La llama AMIN_SIM desde su pestana «Tabla 4».
%
%   AMIN_TABLA4_TEX(ARCH, FILAS, R, RI, PIIAE, PIITAE, BIEN, MAL, CFG)
%     ARCH    archivo de salida (p. ej. tabla4.tex)
%     FILAS   nombres de los controladores, celda 1 x n
%     R       n x 6 cocientes IAE/IAE_PI   [TSSO TRHO PSSO]x[90->70, 70->90]
%     RI      n x 6 cocientes ITAE/ITAE_PI, mismo orden
%     PIIAE   1 x 6 IAE del PI de Usoro, mismo orden
%     PIITAE  1 x 6 ITAE del PI de Usoro, mismo orden
%     BIEN, MAL  colores RGB 0-1 de las celdas (PALETA_ del simulador)
%     CFG     texto con la configuracion de las corridas (va en un comentario)
%
%   La tabla tiene dos bloques, IAE arriba e ITAE abajo, con un renglon por
%   controlador; J es la media de los seis cocientes de cada renglon.
%
%   En el articulo:
%     preambulo:  \usepackage{xcolor}  y  \usepackage{colortbl}
%     tabla:      \input{tabla4}  dentro de center, y despues  \notaTablaIV
%   El archivo define los colores mejorPI y peorPI y el macro \notaTablaIV
%   (con \gdef, para que sobreviva al entorno center).

n = numel(filas);

L = {};
L{end+1} = sprintf('%% Tabla 4 generada por amin_sim (pestana Tabla 4), %s', ...
                   datestr(now, 'yyyy-mm-dd HH:MM'));
L{end+1} = ['% Configuracion: ' cfg];
L{end+1} = '% No editar a mano: se vuelve a escribir desde el simulador.';
L{end+1} = sprintf('\\definecolor{mejorPI}{rgb}{%.3f,%.3f,%.3f}%% = C.bien del simulador', bien);
L{end+1} = sprintf('\\definecolor{peorPI}{rgb}{%.3f,%.3f,%.3f}%% = C.mal del simulador', mal);

% La nota: indices del PI con que se normaliza y regla de colores.  El ITAE
% del PI va en miles para que no ocupe media columna.
nota = ['IAE del PI (\textdegree R$\cdot$s, \textdegree R$\cdot$s, psia$\cdot$s): ' ...
        enteros_(piIAE(1:3)) ' en 90$\to$70~\% y ' enteros_(piIAE(4:6)) ...
        ' en 70$\to$90~\%; ITAE del PI ($10^3$ \textdegree R$\cdot$s$^2$, ' ...
        '\textdegree R$\cdot$s$^2$, psia$\cdot$s$^2$): ' ...
        enteros_(piITAE(1:3)/1e3) ' y ' enteros_(piITAE(4:6)/1e3) '. ' ...
        'Fondo verde: menor que el del PI (cociente $<1$); rojo: mayor ($>1$).'];
L{end+1} = ['\gdef\notaTablaIV{' nota '}'];

L{end+1} = '\begin{tabular}{lccccccc}';
L{end+1} = '\toprule';
L{end+1} = '& \multicolumn{3}{c}{90$\to$70~\%} & \multicolumn{3}{c}{70$\to$90~\%} & \\';
L{end+1} = '\cmidrule(lr){2-4}\cmidrule(lr){5-7}';
L{end+1} = 'Controlador & TSSO & TRHO & PSSO & TSSO & TRHO & PSSO & $J$ \\ \midrule';
L = bloque_(L, '\emph{IAE / IAE del PI}', filas, R, n);
L{end} = [L{end} ' \midrule'];
L = bloque_(L, '\emph{ITAE / ITAE del PI}', filas, Ri, n);
L{end} = [L{end} ' \bottomrule'];
L{end+1} = '\end{tabular}';

try
    fid = fopen(arch, 'w', 'n', 'UTF-8');
catch
    fid = fopen(arch, 'w');
end
if fid < 0
    error('amin_tabla4_tex:archivo', 'No se pudo abrir %s para escribir.', arch);
end
c = onCleanup(@() fclose(fid));
for k = 1:numel(L)
    fprintf(fid, '%s\n', L{k});
end
end

% -------------------------------------------------------------------------
function L = bloque_(L, titulo, filas, R, n)
%BLOQUE_  Un rotulo y un renglon por controlador, con J al final.
L{end+1} = ['\multicolumn{8}{l}{' titulo '} \\'];
J = mean(R, 2);
for i = 1:n
    s = filas{i};
    v = [R(i,:) J(i)];
    for c = 1:7
        s = [s ' & ' celda_(v(c))]; %#ok<AGROW>
    end
    L{end+1} = [s ' \\']; %#ok<AGROW>
end
end

function s = celda_(v)
%CELDA_  Un cociente con coma decimal y su color.  Dos decimales; uno si
%   pasa de 10, como en el articulo.
s = num_(v);
if v < 1
    s = ['\cellcolor{mejorPI}' s];
elseif v > 1
    s = ['\cellcolor{peorPI}' s];
end
end

function s = num_(v)
if abs(v) >= 10, s = sprintf('%.1f', v); else, s = sprintf('%.2f', v); end
s = strrep(s, '.', ',');
end

function s = enteros_(v)
s = sprintf('%d, %d, %d', round(v));
end
