function [S, g] = amin_congela_mov(S, g, t, ldc, dt)
%AMIN_CONGELA_MOV  Congelacion del estimador mientras la carga se mueve.
%
%   [S, G] = AMIN_CONGELA_MOV(S, G, T, LDC, DT)      un instante de control
%
%   G = struct('umbral',U, 'reten',R, 'ult',-inf, 'lPrev',NaN) al empezar
%   (AMIN_DEMANDA da los valores por omision: U = 1 %/min, R = 130 s).
%
%   Generaliza la regla de la seccion V a una demanda cualquiera.  Amin apaga
%   el estimador desde que empieza la rampa hasta 130 s despues de terminar;
%   aqui se apaga cuando la carga cambio mas de U %/min desde el instante de
%   control anterior (DT segundos antes) y sigue apagado R segundos despues
%   del ultimo movimiento.
%
%   Con U = 1 %/min solo congelan las rampas rapidas, como la del articulo
%   (10 %/min).  La demanda de un dia real no pasa de 0,11 %/min, de modo que
%   en esa prueba el estimador no se congela.  Con U = 0,02 %/min queda
%   congelado casi todo el dia y, como la ley no tiene accion integral, la
%   presion se atrasa 3-4 psia siguiendo la rampa.
%
%   See also AMIN_STC_INTERP, AMIN_LAZO, AMIN_DEMANDA.

if ~isnan(g.lPrev) && 20*abs(ldc - g.lPrev)*60/dt > g.umbral
    g.ult = t;
end
g.lPrev = ldc;
S.adapt = (t - g.ult) > g.reten;
end
