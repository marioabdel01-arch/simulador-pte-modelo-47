function s = amin_sufijo(M)
%AMIN_SUFIJO  Sufijo de archivo de un modelo: '' (3x3, k = 1, el del articulo),
%   '_ldc' (3x4), '_k2' (retardo de dos periodos), '_ldc_k2' (los dos).
%
%   Asi los modelos, las tablas por carga y los barridos de las cuatro
%   variantes conviven en datos/ y resultados/ sin pisarse, y el caso del
%   articulo conserva los nombres de siempre.
%
%   See also AMIN_TABLA, AMIN_SIM.
s = '';
if isfield(M,'nd') && M.nd > 0, s = [s '_ldc']; end
if isfield(M,'k') && M.k ~= 1,  s = sprintf('%s_k%d', s, M.k); end
end
