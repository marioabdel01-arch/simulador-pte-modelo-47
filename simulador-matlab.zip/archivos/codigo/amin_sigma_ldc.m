function s = amin_sigma_ldc()
%AMIN_SIGMA_LDC  Excitacion de la demanda de carga para identificar el 3x4.
%
%   S = AMIN_SIGMA_LDC        desviacion tipica de ldc, en V
%
%   NO ES DEL ARTICULO: Amin identifica con la demanda quieta.  Para el
%   modelo 3x4 la demanda tiene que moverse, y su amplitud se fija con EL
%   MISMO CRITERIO que el articulo usa para los tres mandos (nota 1, p. 343):
%   la mayor amplitud que no produce en ninguna salida una fluctuacion de
%   mas del 1 % de su estado estable.  Medido con AMIN_LIMITES('ldc',true)
%   al 75 %:
%
%       amplitud ldc   0,010  0,020  0,030  0,050  0,075  0,100  0,150  0,200
%       PSSO, %         0,39   2,40   0,56   1,91   4,74   3,31   7,24  13,04
%
%   La regla de AMIN_LIMITES ---la mayor amplitud de la rejilla que queda
%   por debajo del 1 %--- da 0,03 V, o sea 0,6 % de carga (3,6 MW).  La
%   columna no es monotona porque cada amplitud usa su propia realizacion
%   aleatoria y la presion en lazo abierto se comporta casi como un
%   integrador: el criterio es ruidoso, y eso vale igual para los mandos.
%
%   ES PEQUENA Y BASTA.  Identificado con 0,01, 0,03 y 0,15 V ---esta
%   ultima es la del resto de la tesis, PTE47_IDENT_DATA---, el bloque D0
%   sale practicamente igual (PSSO: -212, -230 y -219 psia/V), y sobre los
%   mismos datos el 3x4 predice mejor que un 3x3 en las tres salidas, a un
%   paso y en simulacion libre.  Ver README, «Modelo 3x4».
%
%   See also AMIN_LIMITES, AMIN_DATOS, AMIN_MAIN.

s = 0.03;
end
