
function h = amin_fig_ident(arch)
%AMIN_FIG_IDENT  Figura de los datos de identificacion de la seccion IV.
%
%   AMIN_FIG_IDENT
%   AMIN_FIG_IDENT('resultados/amin_fig_ident.png')
%   H = AMIN_FIG_IDENT(...)
%
%   Grafica las diez corridas de identificacion en lazo abierto al 75 %
%   que genera AMIN_DATOS (datos/amin_datos_75.mat):
%
%     fila de arriba   entradas CBMD, CXGG, CWSY [V], en escalon porque se
%                      retienen un periodo de muestreo (20 s); la linea
%                      discontinua es el valor de estado estable u_ss
%     fila de abajo    desviacion de las salidas respecto de y_ss
%                      (dTSSO, dTRHO [R], dPSSO [psia]) en los instantes
%                      de muestreo
%
%   La corrida 1 va en color y las otras nueve en gris.  No simula nada:
%   solo lee los datos.  Si no existen, los genera AMIN_DATOS.
%
%   Por omision guarda resultados/amin_fig_ident.png.
%
%   See also AMIN_DATOS, AMIN_FIGS.

if nargin < 1, arch = fullfile('resultados', 'amin_fig_ident.png'); end

D = amin_datos('pct', 75, 'verbose', false);   % lee el cache si existe

azul   = [31 78 121]/255;    gris_a = [208 215 224]/255;
guinda = [104 20 52]/255;    gris_g = [227 208 214]/255;
oro    = [179 142 93]/255;

nomU = {'CBMD [V]', 'CXGG [V]', 'CWSY [V]'};
nomY = {'\DeltaTSSO [R]', '\DeltaTRHO [R]', '\DeltaPSSO [psia]'};

h = figure('Color', 'w', 'Position', [60 60 1350 420], 'Name', 'Datos de identificacion');
nRun = numel(D.run);
orden = [2:nRun 1];                    % la corrida 1 al final, encima de las grises

for j = 1:3
    % ---------------- entradas
    subplot(2, 3, j); hold on; box off; grid on
    for r = orden
        t = [D.run(r).t, D.run(r).t(end) + D.T];
        u = [D.run(r).U(j,:), D.run(r).U(j,end)];
        if r == 1
            stairs(t, u, 'Color', azul, 'LineWidth', 1.6);
        else
            stairs(t, u, 'Color', gris_a, 'LineWidth', 0.8);
        end
    end
    plot([0 400], D.u_ss(j)*[1 1], '--', 'Color', oro, 'LineWidth', 1);
    xlim([0 400]);
    title(sprintf('%s   (\\sigma = %s V)', nomU{j}, strrep(num2str(D.sigma(j)), '.', ',')));

    % ---------------- salidas
    subplot(2, 3, 3 + j); hold on; box off; grid on
    for r = orden
        dy = D.run(r).Y(j,:) - D.y_ss(j);
        if r == 1
            plot(D.run(r).t, dy, '-o', 'Color', guinda, 'LineWidth', 1.6, ...
                 'MarkerSize', 3, 'MarkerFaceColor', guinda);
        else
            plot(D.run(r).t, dy, 'Color', gris_g, 'LineWidth', 0.8);
        end
    end
    plot([0 400], [0 0], '--', 'Color', oro, 'LineWidth', 1);
    xlim([0 400]); xlabel('t [s]');
    title(nomY{j});
end

annotation(h, 'textbox', [0.55 0 0.44 0.04], 'String', ...
    'corrida 1 en color, las otras 9 en gris; discontinua: estado estable del 75 %', ...
    'EdgeColor', 'none', 'HorizontalAlignment', 'right', 'FontSize', 8, ...
    'Color', [0.35 0.35 0.35]);

if ~isempty(arch)
    d = fileparts(arch);
    if ~isempty(d) && exist(d, 'dir') ~= 7, mkdir(d); end
    print(h, arch, '-dpng', '-r200');
    fprintf('figura guardada en %s\n', arch);
end
if nargout == 0, clear h; end
end
