function ok = verifica_k()
%VERIFICA_K  Comprobaciones del retardo k = 2 (forma predictora).
%
%   >> setup_amin
%   >> verifica_k
%
%   Sobre una planta ARX SINTETICA con retardo de DOS periodos, de la que se
%   conoce el predictor exacto, comprueba que la identificacion, el regresor
%   del estimador en linea y la ley usan la MISMA convencion para k = 2:
%
%     planta     y(t) = -A1 y(t-1) + B0 u(t-2) + E0 ldc(t-2)
%     predictor  y(t) = A1^2 y(t-2) + B0 u(t-2) - A1 B0 u(t-3)
%                       + E0 ldc(t-2) - A1 E0 ldc(t-3)
%
%   (la Diofantina I = A F + q^-2 G con F = I - A1 q^-1, G = A1^2).
%
%     1. AMIN_IDENT con 'k',2 recupera el predictor exacto
%     2. la ley (AMIN_STC) con lambda = 0 deja y(t+2) = w(t) aunque ldc se
%        mueva
%     3. el estimador en linea, arrancado en el predictor exacto, NO se
%        mueve: su regresor esta alineado con el de la identificacion
%     4. la misma ley con el modelo identificado con k = 1 NO lo consigue:
%        el retardo si importa
%
%   See also AMIN_IDENT, AMIN_STC, VERIFICA_LDC.

try, rng(11,'twister'); catch, randn('state',11); rand('state',11); end %#ok<RAND>
ok = true;
A1 = [0.5 0.1 0; -0.1 0.4 0.05; 0 0.1 0.3];
B0 = [1 0.2 0; 0.1 0.8 0.1; 0.3 0 1.2];
E0 = [0.4; -0.2; 0.7];
u_ss = [3; 3; 3];  y_ss = [10; 20; 30];  d_ss = 3;  T = 20;

% ---- datos de identificacion (10 corridas desde el estado estable) ------
nS = 60;  D = struct('pct',75, 'T',T, 'k',1, 'u_ss',u_ss, 'y_ss',y_ss, 'd_ss',d_ss);
for r = 1:10
    U = u_ss + 0.3*randn(3,nS);  L = d_ss + 0.1*randn(1,nS);
    Y = planta_(A1, B0, E0, U - u_ss, L - d_ss) + y_ss;
    D.run(r).U = U;  D.run(r).Y = Y;  D.run(r).L = L;  D.run(r).t = (0:nS-1)*T;
end

% ---- 1. identificacion con k = 2 ---------------------------------------
M = amin_ident(D, 'N',1, 'criterio','fijo', 'Nfijo',1, 'k',2, 'verbose',false);
thv = [B0, -A1*B0, A1^2, E0, -A1*E0];          % [B0 B1 | -A1pred | D0 D1]
e1 = max(abs(M.th(:) - thv(:)));
ok = informa_(1, 'identificacion k = 2 recupera el predictor (max |dtheta|)', e1, 1e-4) && ok;   % sesgo de P0 finito

% ---- 2. ley con lambda = 0 y predictor exacto --------------------------
Mv = amin_modelo(thv, 1, 3, 3, 2, T, u_ss, y_ss, 75, d_ss);
[e2, ~, dth] = lazo_(Mv, A1, B0, E0, u_ss, y_ss, d_ss, false);
ok = informa_(2, 'ley k = 2, lambda = 0: |y(t+2) - w(t)| con ldc moviendose', e2, 1e-9) && ok;

% ---- 3. estimador en linea alineado -------------------------------------
[~, ~, dth] = lazo_(Mv, A1, B0, E0, u_ss, y_ss, d_ss, true);
ok = informa_(3, 'RLS en linea parte del predictor y no se mueve (|dtheta|)', dth, 1e-9) && ok;

% ---- 4. el modelo de k = 1 no coloca la salida -------------------------
M1 = amin_ident(D, 'N',1, 'criterio','fijo', 'Nfijo',1, 'verbose',false);
M1 = amin_modelo(M1.th, 1, 3, 3, 1, T, u_ss, y_ss, 75, d_ss);
e4 = lazo_(M1, A1, B0, E0, u_ss, y_ss, d_ss, false);
ok = informa_(4, 'la misma ley con el modelo de k = 1 (diverge)', e4, -1) && ok;

if ok, fprintf('\nTODO BIEN.\n'); else, fprintf('\nHAY FALLOS.\n'); end
end

% =========================================================================
function Y = planta_(A1, B0, E0, Ud, Ld)
n = size(Ud,2);  Y = zeros(3,n);
for t = 1:n
    y = zeros(3,1);
    if t > 1, y = y - A1*Y(:,t-1); end
    if t > 2, y = y + B0*Ud(:,t-2) + E0*Ld(:,t-2); end
    Y(:,t) = y;
end
end

function [err, Y, dth] = lazo_(M, A1, B0, E0, u_ss, y_ss, d_ss, adapt)
S = amin_stc_init(M, 'lambda',0, 'adapt',adapt, 'P0',100, 'Umin',-inf, 'Umax',inf);
th0 = S.E.th;
n = 40;  Yd = zeros(3,n);  Ud = zeros(3,n);  W = zeros(3,n);
L = d_ss + 0.2*sin(0.4*(1:n));
for t = 1:n
    y = zeros(3,1);
    if t > 1, y = y - A1*Yd(:,t-1); end
    if t > 2, y = y + B0*Ud(:,t-2) + E0*(L(t-2) - d_ss); end
    Yd(:,t) = y;
    W(:,t) = y_ss + [1; -1; 2]*(t > 5) + 0.5*randn(3,1)*adapt;
    [u, S] = amin_stc(S, y + y_ss, W(:,t), u_ss, L(t));
    Ud(:,t) = u - u_ss;
end
Y = Yd + y_ss;
err = max(max(abs(Y(:,3:n) - W(:,1:n-2))));
dth = max(abs(S.E.th(:) - th0(:)));
end

function ok = informa_(i, txt, v, tol)
if tol < 0
    ok = v > 1e-3;  est = 'debe ser >> 0';
else
    ok = v <= tol;  if ok, est = 'bien'; else, est = 'MAL'; end
end
fprintf('%4d  %-62s %10.3g   %s\n', i, txt, v, est);
end
