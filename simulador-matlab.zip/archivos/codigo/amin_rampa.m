function [P, info] = amin_rampa(pctIni, pctFin, varargin)
%AMIN_RAMPA  Prepara una de las dos pruebas de carga del articulo.
%
%   [P, INFO] = AMIN_RAMPA(90, 70)          figuras 6a, 7a, 8a
%   [P, INFO] = AMIN_RAMPA(70, 90)          figuras 6b, 7b, 8b
%   [P, INFO] = AMIN_RAMPA(PCTINI, PCTFIN, 'dur',800, 'T0',10)
%
%   «Response of the system to a load ramp from 90% load to 70% load at a
%   rate of 10% per minute» y su simetrica.  Son las UNICAS dos pruebas del
%   articulo, y NO son ninguna de las cuatro de Usoro: aquellas van a
%   15 %/min entre 100, 77,5 y 50 %.
%
%   La condicion inicial no esta tabulada en Usoro para el 90 % ni para el
%   70 %, asi que se genera con AMIN_ESTACIONARIO y se cachea.
%
%   OPCIONES
%     'dur'  duracion total de la simulacion, s.  Las figuras del articulo
%            llegan a 800 s.                                       [800]
%     'T0'   instante en que arranca la rampa, s.  El articulo no lo dice;
%            se usan los 10 s de la convencion de Usoro.            [10]
%
%   INFO trae T0, T1 (fin de la rampa), rate y los dos estacionarios.
%
%   See also AMIN_ESTACIONARIO, AMIN_LAZO, AMIN_RUN.

opt = struct('dur',800, 'T0',10, 'verbose',true);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_rampa:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

Si = amin_estacionario(pctIni, 'verbose',opt.verbose);
ldc0 = amin_carga(pctIni);
ldc1 = amin_carga(pctFin);

rate  = sign(ldc1 - ldc0)/120;              % 10 %/min
tramp = abs(ldc1 - ldc0)*120;
T1    = opt.T0 + tramp;

P = amin_planta(Si.base, 'ldcStart',ldc0, 'ldcRate',rate, ...
                 'ldcT0',opt.T0, 'ldcT1',T1, ...
                 'samples', round(opt.dur/0.1)+1);
P.x0 = Si.x0;
P.ldc = ldc0;

info = struct('pctIni',pctIni, 'pctFin',pctFin, 'T0',opt.T0, 'T1',T1, ...
              'rate',rate, 'tramp',tramp, 'dur',opt.dur, 'ss',Si, ...
              'ldc0',ldc0, 'ldc1',ldc1);

if opt.verbose
    fprintf(['rampa %g %% -> %g %%  al 10 %%/min:  ldc %.4f -> %.4f, ' ...
             't = %g..%g s, %g s de simulacion\n'], ...
            pctIni, pctFin, ldc0, ldc1, opt.T0, T1, opt.dur);
end
end
