function [M, T] = amin_ident(D, varargin)
%AMIN_IDENT  Identificacion del modelo AR de Amin, seccion IV del articulo.
%
%   [M, T] = AMIN_IDENT(D)
%   [M, T] = AMIN_IDENT(D, 'N',1:8, 'criterio','fuera', 'holdout',3)
%
%   D es la estructura que devuelve AMIN_DATOS: D.run(r).U (nu x n) y
%   D.run(r).Y (ny x n), las diez corridas de 400 s en lazo abierto, ya
%   muestreadas a T = 20 s, en unidades fisicas, con D.u_ss y D.y_ss.
%
%   COMO IDENTIFICA, Y POR QUE ASI
%
%   El articulo describe el procedimiento con todo detalle y aqui se sigue al
%   pie de la letra:
%
%     «Initial matrices O(0) and P(0) were chosen arbitrarily and x(0-k)
%      contained steady state values of inputs and outputs at the constant
%      load level.  The 400 seconds of the inputs and the outputs of the
%      first run were sampled and used in the recursive LS estimator to
%      improve the initial estimate.  Matrices O(.) and P(.) at the end of
%      the 400 seconds of the first run were used as initial values [...]
%      for the second run.  [...]  This procedure was repeated for all the
%      10 runs.»
%
%   O sea: UN SOLO estimador, ENCADENADO a traves de las diez corridas.  No
%   es un minimo cuadrados por lotes ni diez estimaciones promediadas; theta
%   y P sobreviven de una corrida a la siguiente y el regresor se reinicia en
%   el punto de operacion al empezar cada una.
%
%   COMO ELIGE EL ORDEN, Y POR QUE NO SE PUEDE HACER LITERALMENTE
%
%     «The order, N, of the AR model (16) is estimated by identifying the
%      model for several values of N and selecting the value which results
%      in the best prediction of the outputs of the system.»
%
%   El articulo NO DICE SOBRE QUE DATOS se mide esa prediccion, y la
%   diferencia lo decide todo (README, hueco 8):
%
%     * medida SOBRE LOS MISMOS DATOS de la identificacion, el ajuste a un
%       paso **crece monotonamente con N** ---mas parametros siempre ajustan
%       mejor en la propia muestra---, asi que el criterio degenera y elige
%       SIEMPRE EL CANDIDATO MAS GRANDE.  Con N = 1..8 sale N = 8, no 5.
%       No es un fallo de la replica: es lo que da la lectura literal.
%
%     * medida SOBRE CORRIDAS QUE NO SE USARON para estimar, el ajuste tiene
%       un maximo interior y el criterio decide de verdad.
%
%   Aqui se hace lo segundo, y se declara.  Las ultimas HOLDOUT corridas se
%   apartan, el orden se elige con ellas, y **el modelo final se reestima
%   encadenando LAS DIEZ**, que es lo que el articulo describe.  La tabla T
%   devuelve las tres columnas ---dentro, fuera y simulacion libre--- para
%   que la eleccion se pueda discutir en vez de tener que creersela.
%
%   Y hay que recordar lo que el propio articulo admite a continuacion:
%
%     «It is possible that a lower order AR model is adequate.  However,
%      since the purpose of this work is to obtain an input-output
%      representation which closely represents the system at a constant
%      level, no attempt was made to verify whether a suitable lower order
%      AR model could be found.»
%
%   O sea que el 5 de Amin no es un optimo: es un orden que les bastaba.  Con
%   'criterio','fijo' y 'Nfijo',5 se reproduce su eleccion tal cual.
%
%   OPCIONES
%     'N'        vector de ordenes candidatos                        [1:8]
%     'criterio' como se elige el orden:
%                  'fuera'  ajuste a un paso en las corridas apartadas
%                  'dentro' ajuste a un paso en las mismas (lectura literal;
%                           degenera en el N mas grande)
%                  'libre'  ajuste en simulacion libre, que es lo que dibuja
%                           la figura 5 del articulo
%                  'fijo'   se impone 'Nfijo'                      ['fuera']
%     'Nfijo'    el orden que se impone con 'criterio','fijo'            [5]
%     'holdout'  corridas apartadas para elegir el orden                 [3]
%     'P0'       P(0) = P0 * I.  «Arbitrario» segun el articulo        [1e4]
%     'beta'     factor de olvido de (15).  NO ESTA EN EL ARTICULO        [1]
%     'k'        retardo en periodos de muestreo.  Vacio = el de los datos
%                (D.k = 1, el del articulo).  Los datos no dependen de k:
%                el mismo experimento sirve para k = 1 y k = 2.          [[]]
%
%   EL RETARDO k Y LA FORMA DEL MODELO.  Se identifica la forma PREDICTORA
%   de (17): y(t) = theta x(t-k) con
%
%       x(t-k) = [ u(t-k) ... u(t-k-N);  y(t-k) ... y(t-k-N+1) ]
%
%   que es la del auto-sintonizable implicito que aplica Amin: el algoritmo
%   de la p. 342 calcula y*(t+k|t) directamente con theta.  Con k = 1 es
%   exactamente el ARX (16).  Con k = 2 theta ya no son las A y B de (16)
%   sino los polinomios G y F*B del predictor a dos pasos ---la Diofantina
%   I = A F + q^-k G queda resuelta DENTRO de la estimacion--- y la ley (12)
%   se aplica sin cambiar una linea.
%
%   DEVUELVE
%     M   el modelo elegido, reestimado sobre las diez corridas
%     T   tabla por orden: T.N, T.npar, T.aj_dentro, T.aj_fuera,
%         T.aj_libre, T.zmax, T.condB0, T.elegido
%
%   MODELO 3x4.  Si los datos traen la demanda excitada (AMIN_DATOS con
%   'sigmaLdc'), el modelo se identifica con ldc como cuarta entrada: el
%   mismo RLS encadenado, el mismo criterio de orden, y seis parametros mas
%   por fila (D0 ... DN).  No hay que pedirlo: lo decide D.
%
%   See also AMIN_DATOS, AMIN_RLS, AMIN_MODELO, AMIN_PRED.

opt = struct('N',1:8, 'criterio','fuera', 'Nfijo',5, 'holdout',3, ...
             'P0',1e4, 'beta',1, 'verbose',true, 'k',[]);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_ident:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

nu = size(D.run(1).U,1);
ny = size(D.run(1).Y,1);
nd = 0;
if isfield(D.run,'L') && ~isempty(D.run(1).L), nd = size(D.run(1).L,1); end
if nd > 0, dss = D.d_ss; else, dss = []; end
k  = D.k;
if ~isempty(opt.k), k = opt.k; end
nR = numel(D.run);

nH = min(max(opt.holdout,0), max(nR-2,0));
nE = nR - nH;
if nH == 0 && strcmpi(opt.criterio,'fuera')
    warning('amin_ident:holdout', ...
        ['Con holdout = 0 no hay corridas apartadas: el criterio «fuera» ' ...
         'no se puede medir y se usa «libre».']);
    opt.criterio = 'libre';
end

T = struct('N',[], 'npar',[], 'aj_dentro',[], 'aj_fuera',[], ...
           'aj_libre',[], 'zmax',[], 'condB0',[], 'nupd',[], ...
           'criterio',opt.criterio, 'holdout',nH);
Ms = cell(1, numel(opt.N));

if opt.verbose
    fprintf('  (prediccion a %d paso(s): el horizonte del retardo k = %d)\n', k, k);
    fprintf(['  N  npar   k pasos dentro  k pasos fuera  simul. libre   ' ...
             '|z|max   cond(B0)\n']);
end

for q = 1:numel(opt.N)
    N = opt.N(q);

    % --- modelo final: las DIEZ corridas encadenadas --------------------
    Eall = estima_(D, 1:nR, N, nu, ny, nd, k, opt);
    Mall = amin_modelo(Eall.th, N, nu, ny, k, D.T, D.u_ss, D.y_ss, D.pct, dss);
    Mall.Pf = Eall.P;       % covarianza final: P(0) heredada del STC (AMIN_COVARIANZA)
    Ms{q} = Mall;

    % --- modelo de seleccion: solo las de estimacion --------------------
    if nH > 0
        Esel = estima_(D, 1:nE, N, nu, ny, nd, k, opt);
        Msel = amin_modelo(Esel.th, N, nu, ny, k, D.T, D.u_ss, D.y_ss, D.pct, dss);
    else
        Msel = Mall;
    end

    T.N(q,1)    = N;
    T.npar(q,1) = (N+1)*nu + N*ny + (N+1)*nd;
    T.aj_dentro(q,:) = ajuste_(Mall, D.run(1:nE), 'un');
    if nH > 0
        T.aj_fuera(q,:) = ajuste_(Msel, D.run(nE+1:nR), 'un');
        T.aj_libre(q,:) = ajuste_(Msel, D.run(nE+1:nR), 'libre');
    else
        T.aj_fuera(q,:) = nan(1,ny);
        T.aj_libre(q,:) = ajuste_(Mall, D.run, 'libre');
    end
    T.zmax(q,1)   = zmax_(Mall);
    T.condB0(q,1) = cond(Mall.B(:,:,1));
    T.nupd(q,1)   = Eall.n;

    if opt.verbose
        fprintf('%3d %4d %14.2f %14.2f %14.2f %9.4f %10.3g\n', ...
                N, T.npar(q), mean(T.aj_dentro(q,:)), ...
                mean(T.aj_fuera(q,:)), mean(T.aj_libre(q,:)), ...
                T.zmax(q), T.condB0(q));
    end
end

% --- la eleccion --------------------------------------------------------
switch lower(opt.criterio)
  case 'dentro', [~, best] = max(mean(T.aj_dentro, 2));
  case 'fuera',  [~, best] = max(mean(T.aj_fuera,  2));
  case 'libre',  [~, best] = max(mean(T.aj_libre,  2));
  case 'fijo'
    best = find(T.N == opt.Nfijo, 1);
    if isempty(best)
        error('amin_ident:Nfijo', ...
              'N = %d no esta entre los candidatos.', opt.Nfijo);
    end
  otherwise
    error('amin_ident:criterio','criterio desconocido: %s', opt.criterio);
end

M = Ms{best};
T.elegido = T.N(best);

% CUANTO DISCRIMINA EL CRITERIO.  Es tan importante como cual gana: si varios
% ordenes quedan dentro del ruido, el criterio del articulo NO determina el
% orden, y eso hay que reportarlo en vez de presentar el ganador como si
% fuera una eleccion informada.
switch lower(opt.criterio)
  case 'dentro', col = mean(T.aj_dentro,2);
  case 'libre',  col = mean(T.aj_libre, 2);
  otherwise,     col = mean(T.aj_fuera, 2);
end
T.mejor = max(col);
T.empatan = T.N(col >= T.mejor - 1);      % dentro de 1 punto del mejor
T.rango = max(col) - min(col);

if opt.verbose
    fprintf('\nElegido N = %d  (criterio «%s», %d corridas apartadas).\n', ...
            M.N, opt.criterio, nH);
    if strcmpi(opt.criterio,'dentro')
        fprintf(['OJO: el ajuste dentro de muestra crece con N, asi que este ' ...
                 'criterio\n     elige siempre el candidato mas grande.  ' ...
                 'Ver la ayuda de AMIN_IDENT.\n']);
    end
    fprintf(['Dentro de 1 punto del mejor quedan N = %s: el criterio ' ...
             'separa %.2f puntos\n'], mat2str(T.empatan(:).'), T.rango);
    if numel(T.empatan) > 1
        fprintf(['=> EL CRITERIO DEL ARTICULO NO DETERMINA EL ORDEN.  ' ...
                 'Varios quedan empatados\n   dentro del ruido, y el 5 de ' ...
                 'Amin esta entre ellos.  Hay que reportarlo asi.\n']);
    end
    if M.N ~= 5
        fprintf(['NOTA: Amin usa N = 5.  Para reproducir su eleccion tal ' ...
                 'cual:\n     amin_ident(D, ''criterio'',''fijo'', ''Nfijo'',5)\n']);
    end
end
end

% =========================================================================
function E = estima_(D, idx, N, nu, ny, nd, k, opt)
%ESTIMA_  El RLS encadenado de la seccion IV sobre las corridas IDX.
npar = (N+1)*nu + N*ny + (N+1)*nd;
E = struct('th', zeros(ny, npar), 'P', opt.P0*eye(npar), ...
           'beta', opt.beta, 'n', 0);
for r = idx(:).'
    U = D.run(r).U;  Y = D.run(r).Y;
    n = size(Y,2);
    Ud = U - D.u_ss(:)*ones(1,n);
    Yd = Y - D.y_ss(:)*ones(1,n);
    if nd > 0
        Ld = D.run(r).L - D.d_ss(:)*ones(1,n);
    else
        Ld = zeros(0, n);
    end
    % «Initial matrices theta(0) and P(0) were chosen arbitrarily and x(0-k)
    %  contained steady state values of inputs and outputs at the constant
    %  load level. [...] In the second run, x(0-k) again contained steady
    %  state values of inputs and outputs.»
    %
    % O sea: la HISTORIA se repone a estado estable al empezar cada corrida
    % ---que en variables incrementales es CERO---, y se usan las 20 muestras
    % de los 400 s, no solo las que tienen historia propia.  theta y P si se
    % encadenan de una corrida a la siguiente.  Saltarse las primeras N+k
    % muestras seria tirar el 30 % de los datos del articulo.
    pad = max(N+k, N);
    Ud = [zeros(nu, pad), Ud];
    Yd = [zeros(ny, pad), Yd];
    Ld = [zeros(nd, pad), Ld];
    for t = (pad+1):(pad+n)
        E = amin_rls(E, Yd(:,t), regresor_(Ud, Yd, Ld, t, N, k));
    end
end
end

% =========================================================================
function a = ajuste_(M, runs, tipo)
%AJUSTE_  Ajuste medio sobre un conjunto de corridas.
A = zeros(numel(runs), M.ny);
for r = 1:numel(runs)
    if M.nd > 0
        [~,~,aj] = amin_pred(M, runs(r).U, runs(r).Y, runs(r).L);
    else
        [~,~,aj] = amin_pred(M, runs(r).U, runs(r).Y);
    end
    if strcmpi(tipo,'un'), A(r,:) = aj.un; else, A(r,:) = aj.libre; end
end
A(~isfinite(A)) = -1e6;      % un modelo que se va no puede ganar por NaN
a = mean(A,1);
end

% =========================================================================
function x = regresor_(Ud, Yd, Ld, t, N, k)
%REGRESOR_  Ecuacion (17b), con el bloque de salidas de N terminos, y en el
%   3x4 el bloque de la demanda al final (ver AMIN_MODELO).
nu = size(Ud,1);  ny = size(Yd,1);  nd = size(Ld,1);
x = zeros((N+1)*nu + N*ny + (N+1)*nd, 1);
for j = 0:N
    x(j*nu + (1:nu)) = Ud(:, t-k-j);
end
off = (N+1)*nu;
for i = 1:N                          % y(t-k) ... y(t-k-N+1): con k = 1, y(t-1)..y(t-N)
    x(off + (i-1)*ny + (1:ny)) = Yd(:, t-k-i+1);
end
off = (N+1)*nu + N*ny;
if nd > 0
    for j = 0:N
        x(off + j*nd + (1:nd)) = Ld(:, t-k-j);
    end
end
end

% =========================================================================
function z = zmax_(M)
%ZMAX_  Mayor modulo de las raices de det A(q^-1), por la forma companera.
N = M.N;  ny = M.ny;
C = zeros(ny*N);
for i = 1:N
    C(1:ny, (i-1)*ny + (1:ny)) = -M.A(:,:,i);
end
if N > 1
    C(ny+1:end, 1:ny*(N-1)) = eye(ny*(N-1));
end
z = max(abs(eig(C)));
end
