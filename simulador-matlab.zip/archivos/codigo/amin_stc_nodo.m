function S = amin_stc_nodo(S, M)
%AMIN_STC_NODO  Cambia el controlador al juego de parametros de otro nodo.
%
%   S = AMIN_STC_NODO(S, M)
%
%   Es la conmutacion de la tabla por carga (seccion V): se sustituye el
%   modelo ---y con el el punto de operacion--- y el theta del estimador,
%   para que si mas tarde se vuelve a encender parta del juego correcto.
%
%   EL PUNTO DE OPERACION DE LA HISTORIA.  El controlador guarda sus
%   historias como DESVIACIONES respecto del punto de operacion del modelo
%   con el que se registraron.  Al conmutar, el punto cambia (u_ss, y_ss y,
%   en el 3x4, ldc_ss = 0,05*pct) y las columnas viejas quedan referidas al
%   nodo anterior.  Que hacer con eso lo decide S.reref (AMIN_STC_INIT):
%
%     'ldc'   solo se re-refiere la historia de la demanda.  Es lo que se
%             hace por omision: en el 3x3 no existe y el resultado es
%             identico al de siempre; en el 3x4 evita que cada conmutacion
%             meta un escalon ficticio de 0,25 V de demanda (5 % de carga)
%             en el termino D(q^-1) ldc.
%     'todo'  se re-refieren tambien mandos y salidas.  Es lo coherente
%             ---la historia fisica no cambia por conmutar---, pero CAMBIA
%             LOS RESULTADOS DEL 3x3 publicados hasta ahora, y por eso no es
%             la opcion por omision.
%     'nada'  como estaba antes de existir esta funcion.
%
%   See also AMIN_LAZO, AMIN_SIM, AMIN_TABLA.

Mv = S.M;
if ~isfield(M,'nd')          % nodo de una tabla guardada antes del 3x4
    M = amin_modelo(M.th, M.N, M.nu, M.ny, M.k, M.T, M.u_ss, M.y_ss, M.pct);
end
if ~isfield(Mv,'nd')
    Mv = amin_modelo(Mv.th, Mv.N, Mv.nu, Mv.ny, Mv.k, Mv.T, Mv.u_ss, Mv.y_ss, Mv.pct);
end
modo = 'ldc';
if isfield(S,'reref') && ~isempty(S.reref), modo = lower(S.reref); end

if any(strcmp(modo, {'ldc','todo'})) && M.nd > 0 && isfield(S,'Dh') ...
        && numel(Mv.d_ss) == M.nd
    S.Dh = S.Dh + (Mv.d_ss - M.d_ss)*ones(1, size(S.Dh,2));
end
if strcmp(modo, 'todo')
    S.Yh = S.Yh + (Mv.y_ss - M.y_ss)*ones(1, size(S.Yh,2));
    S.Uh = S.Uh + (Mv.u_ss - M.u_ss)*ones(1, size(S.Uh,2));
end

S.M    = M;
S.E.th = M.th;
end
