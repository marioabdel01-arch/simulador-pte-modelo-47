function R = amin_run(M, TB, varargin)
%AMIN_RUN  Las dos pruebas del articulo con los cuatro controladores.
%
%   R = AMIN_RUN(M, TB)
%   R = AMIN_RUN(M, TB, 'lambda',1, 'dur',800)
%   R = AMIN_RUN(M, TB, 'P0',1e2)          % la primera version de la replica
%
%   P(0) EN LINEA.  Por omision 'heredada': la covarianza con que termina la
%   identificacion (AMIN_COVARIANZA), la misma para el STC y para todos los
%   nodos de la tabla.  Es la configuracion del articulo CITCA/TyCAP.  Las
%   dos variantes con el estimador apagado toda la corrida (mstc2 y
%   tablapura) no dependen de P(0).
%
%   M es el modelo AR identificado al 75 % (AMIN_IDENT) y TB la tabla por
%   carga (AMIN_TABLA).  Se corren las dos rampas del articulo ---90 -> 70 %
%   y 70 -> 90 %, las dos al 10 %/min--- con los cuatro controladores que el
%   articulo compara:
%
%     'pi'      los tres PI originales de Usoro           (figuras 6, 7, 8)
%     'stc'     el auto-sintonizable, estimador siempre encendido  (fig. 6)
%     'mstc20'  el «modified S.T.C.»: tabla por carga, estimador apagado
%               durante el transitorio y 130 s mas, mando cada 20 s (fig. 7)
%     'mstc2'   el mismo, con el mando calculado cada 2 s.  El articulo dice
%               que sale «more smoothly» pero con desviaciones casi iguales,
%               y por eso NO publica sus graficas.  Se corre para poder
%               comprobar esa afirmacion.
%
%   La congelacion del estimador va de T0 (arranque de la rampa) a
%   T1 + 130 s, literalmente lo que describe la seccion V.
%
%   DEVUELVE  R.prueba(p).nombre, .info y R.prueba(p).ctrl.<nombre> con la
%   corrida completa, mas R.tabla con el resumen de errores maximos.
%
%   See also AMIN_LAZO, AMIN_TABLA, AMIN_FIGS.

opt = struct('lambda',1, 'beta',0.99, 'P0','heredada', 'dur',800, ...
             'hold',130, 'verbose',true);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_run:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

% La P heredada se calcula UNA vez con el modelo identificado (que puede
% traer su propia Pf, p. ej. el de valvula fija) y se pasa como matriz: los
% modelos referidos al punto de operacion de cada prueba no la heredan.
if ischar(opt.P0) && strcmpi(opt.P0,'heredada')
    Ph = amin_covarianza(M);
    if ~isempty(Ph), opt.P0 = Ph; else, opt.P0 = 1e2; end
end

pruebas = {[90 70], [70 90]};
nom     = {'90 -> 70 %', '70 -> 90 %'};

R = struct('opt',opt, 'prueba',struct('nombre',{},'info',{},'ctrl',{}));

for p = 1:2
    a = pruebas{p}(1);  b = pruebas{p}(2);
    [P, info] = amin_rampa(a, b, 'dur',opt.dur, 'verbose',opt.verbose);
    congelar = [info.T0, info.T1 + opt.hold];

    C = struct();

    % --- 1. los PI de Usoro --------------------------------------------
    C.pi = amin_lazo([], P);

    % --- 2. el auto-sintonizable tal cual -------------------------------
    % Arranca con el modelo del 75 % referido al punto de operacion REAL de
    % la prueba.  Sin eso, «u incremental = 0» corresponderia a un mando de
    % otro nivel de carga y el primer instante de control daria un salto.
    M0 = amin_modelo(M.th, M.N, M.nu, M.ny, M.k, M.T, info.ss.u, info.ss.y, ...
                     NaN, dss_(M, info.ss));
    S  = amin_stc_init(M0, 'lambda',opt.lambda, 'beta',opt.beta, ...
                       'adapt',true, 'P0',opt.P0, 'Tc',M.T);
    C.stc = amin_lazo(S, P);

    % --- 3. el «modified S.T.C.», mando cada 20 s -----------------------
    S = amin_stc_init(TB.M(nodo_(TB,a)), 'lambda',opt.lambda, ...
                      'beta',opt.beta, 'adapt',false, 'P0',opt.P0, 'Tc',M.T);
    C.mstc20 = amin_lazo(S, P, 'tabla',TB, 'congelar',congelar);

    % --- 4. el mismo con el mando cada 2 s ------------------------------
    % EL ESTIMADOR SE QUEDA APAGADO TODA LA CORRIDA, no solo el transitorio:
    %   «As in the previous case, the estimator is off at the beginning of
    %    the transient period and IS KEPT OFF WHILE THE CONTROL IS
    %    CALCULATED EVERY 2 SECONDS.»
    % Volver a encenderlo a los 130 s de llegar a la carga final ---como en
    % la configuracion de 20 s--- lo haria actualizar diez veces mas a
    % menudo de lo que se diseno, con el mismo beta por actualizacion.
    S = amin_stc_init(TB.M(nodo_(TB,a)), 'lambda',opt.lambda, ...
                      'beta',opt.beta, 'adapt',false, 'P0',opt.P0, 'Tc',2);
    C.mstc2 = amin_lazo(S, P, 'tabla',TB, 'congelar',[0 inf]);

    % --- 5. tabla con el estimador SIEMPRE apagado ----------------------
    % NO ES DEL ARTICULO.  Es el control por tabla puro: el mismo juego de
    % parametros por nivel de carga, pero sin reidentificar nunca.  Sirve
    % para separar las dos cosas que el «modified S.T.C.» mezcla ---la
    % recolocacion del punto de operacion y la adaptacion en linea--- y
    % decidir cual de las dos aporta.  Se declara como aportacion de la
    % replica cuando se reporte.
    S = amin_stc_init(TB.M(nodo_(TB,a)), 'lambda',opt.lambda, ...
                      'beta',opt.beta, 'adapt',false, 'P0',opt.P0, 'Tc',M.T);
    C.tablapura = amin_lazo(S, P, 'tabla',TB, 'congelar',[0 inf]);

    R.prueba(p).nombre = nom{p};
    R.prueba(p).info   = info;
    R.prueba(p).ctrl   = C;

    if opt.verbose
        fprintf('\nprueba %s\n', nom{p});
        fprintf(['  %-10s %s   %s\n'], 'controlador', ...
                'error maximo  TSSO    TRHO     PSSO', ...
                '     IAE  TSSO     TRHO      PSSO');
        f = fieldnames(C);
        for q = 1:numel(f)
            fprintf('  %-10s %14.2f %8.2f %9.2f   %11.3g %9.3g %9.3g\n', ...
                    f{q}, C.(f{q}).emax, C.(f{q}).iae);
        end
    end
end

% --- resumen ------------------------------------------------------------
f = fieldnames(R.prueba(1).ctrl);
R.tabla = struct('ctrl',{f}, 'emax',zeros(numel(f),3,2), ...
                 'iae',zeros(numel(f),3,2), 'itae',zeros(numel(f),3,2));
for p = 1:2
    for q = 1:numel(f)
        R.tabla.emax(q,:,p) = R.prueba(p).ctrl.(f{q}).emax;
        R.tabla.iae(q,:,p)  = R.prueba(p).ctrl.(f{q}).iae;
        R.tabla.itae(q,:,p) = R.prueba(p).ctrl.(f{q}).itae;
    end
end
end

% =========================================================================
function i = nodo_(TB, pct)
[~, i] = min(abs(TB.pct - pct));
end

% =========================================================================
function d = dss_(M, ss)
%DSS_  Punto de operacion de ldc para el modelo 3x4; vacio en el 3x3.
d = [];
if isfield(M,'nd') && M.nd > 0, d = ss.ldc; end
end
