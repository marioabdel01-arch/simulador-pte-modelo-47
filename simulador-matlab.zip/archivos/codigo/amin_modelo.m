function M = amin_modelo(th, N, nu, ny, k, T, u_ss, y_ss, pct, d_ss)
%AMIN_MODELO  Empaqueta una matriz de parametros como el modelo AR de Amin.
%
%   M = AMIN_MODELO(TH, N, NU, NY, K, T, U_SS, Y_SS)
%   M = AMIN_MODELO(..., PCT)
%   M = AMIN_MODELO(..., PCT, D_SS)          modelo 3x4, con la demanda ldc
%
%   TH es la matriz THETA de la ecuacion (17a):
%
%       theta = [ B0  B1 ... BN  -A1 ... -AN ]        (ny x npar)
%
%   y el regresor asociado es el de la ecuacion (17b), CON UNA SALVEDAD que
%   hay que declarar (README, hueco 4): (17b) escribe el bloque de salidas
%   como y(t-k) ... y(t-k-N), o sea N+1 terminos, mientras que el modelo (16)
%   solo tiene A1 ... AN, o sea N.  Las dos cosas no pueden ser ciertas a la
%   vez.  Aqui se sigue (16) y (17a), que son consistentes entre si:
%
%       x(t-k) = [ u(t-k); ... ; u(t-k-N); y(t-k); ... ; y(t-k-N+1) ]
%
%   que es la FORMA PREDICTORA: y(t) = theta x(t-k).  Con k = 1 coincide con
%   el ARX (16) y A, B son las de (16).  Con k >= 2 los bloques «A» y «B» son
%   los polinomios G y F*B del predictor a k pasos (la Diofantina queda
%   dentro de la estimacion); se siguen llamando A y B solo por el sitio que
%   ocupan en theta.  Ver AMIN_IDENT.
%
%       npar = (N+1)*nu + N*ny
%
%   Con N = 5, nu = ny = 3:  npar = 18 + 15 = 33.
%
%   MODELO 3x4 ---NO ES DEL ARTICULO---.  La demanda de carga ldc no la
%   manipula el controlador, pero SE MIDE.  Metida como cuarta entrada, el
%   modelo pasa a ser
%
%       A(q^-1) y(t) = B(q^-1) u(t-k) + D(q^-1) ldc(t-k) + e(t)
%
%   y theta gana un bloque AL FINAL, para que el caso 3x3 no cambie ni un
%   indice:
%
%       theta = [ B0 ... BN  -A1 ... -AN  D0 ... DN ]
%       x     = [ u(t-k) ... u(t-k-N);  y(t-k) ... y(t-k-N+1);
%                 ldc(t-k) ... ldc(t-k-N) ]
%
%   (con k = 1 el bloque de salidas es y(t-1) ... y(t-N), el de (16))
%
%       npar = (N+1)*nu + N*ny + (N+1)*nd      con N = 5, nd = 1:  39
%
%   ND NO SE PASA: se deduce del ancho de TH.  Lo que si hay que pasar es
%   D_SS, el valor de ldc en el punto de operacion, porque ldc tambien entra
%   como desviacion.  Pedir un modelo 3x4 sin D_SS es un error, no un cero
%   por omision: un ldc referido al nivel equivocado es exactamente un
%   escalon de demanda que no existe.
%
%   El modelo es INCREMENTAL: y, u y ldc son desviaciones respecto del punto
%   de operacion (U_SS, Y_SS, D_SS) del nivel de carga en el que se
%   identifico.  La ecuacion (16) no tiene termino constante, asi que no
%   puede ser de otra manera.
%
%   PCT es el nivel de carga al que corresponde el punto de operacion.  Es
%   opcional y solo sirve para rotular, pero el campo EXISTE SIEMPRE: dos
%   modelos con juegos de campos distintos no se pueden meter en el mismo
%   arreglo de structs, y eso es exactamente lo que rompia AMIN_TABLA.  Por
%   la misma razon nd, D y d_ss existen siempre, tambien en el 3x3 (vacios).
%
%   DEVUELVE
%     M.th, M.N, M.nu, M.ny, M.k, M.T, M.u_ss, M.y_ss, M.npar, M.pct
%     M.B   ny x nu x (N+1)      B0 ... BN
%     M.A   ny x ny x N          A1 ... AN   (con el signo del modelo (16),
%                                             o sea A = -th(bloque de salidas))
%     M.nd, M.d_ss               0 y [] en el 3x3;  1 y ldc_ss en el 3x4
%     M.D   ny x nd x (N+1)      D0 ... DN   (vacio en el 3x3)
%     M.estructura               '3x3' o '3x4'
%
%   See also AMIN_IDENT, AMIN_STC, AMIN_PRED.

if nargin < 9 || isempty(pct), pct = NaN; end

npar0 = (N+1)*nu + N*ny;
extra = size(th,2) - npar0;
if size(th,1) ~= ny || extra < 0 || mod(extra, N+1) ~= 0
    error('amin_modelo:tam', ...
          ['theta es %dx%d y se esperaba %dx%d (3x3) o %dx%d (3x4) ' ...
           '(N=%d, nu=%d, ny=%d).'], size(th,1), size(th,2), ...
          ny, npar0, ny, npar0 + (N+1), N, nu, ny);
end
nd = extra/(N+1);

if nd > 0
    if nargin < 10 || isempty(d_ss) || numel(d_ss) ~= nd
        error('amin_modelo:dss', ...
              ['El modelo tiene %d entrada(s) exogena(s) (ldc) y hace falta ' ...
               'su punto de operacion D_SS.'], nd);
    end
    d_ss = d_ss(:);
else
    d_ss = zeros(0,1);
end

M = struct();
M.th   = th;
M.N    = N;   M.nu = nu;  M.ny = ny;
M.k    = k;   M.T  = T;
M.npar = npar0 + (N+1)*nd;
M.u_ss = u_ss(:);
M.y_ss = y_ss(:);
M.pct  = pct;

M.B = zeros(ny, nu, N+1);
for i = 0:N
    M.B(:,:,i+1) = th(:, i*nu + (1:nu));
end
off = (N+1)*nu;
M.A = zeros(ny, ny, N);
for i = 1:N
    % theta guarda -Ai; el modelo (16) los usa con signo +.
    M.A(:,:,i) = -th(:, off + (i-1)*ny + (1:ny));
end

M.nd   = nd;
M.d_ss = d_ss;
M.D = zeros(ny, nd, N+1);
off = npar0;
for i = 0:N
    M.D(:,:,i+1) = th(:, off + i*nd + (1:nd));
end
if nd > 0, M.estructura = sprintf('3x%d', nu + nd); else, M.estructura = '3x3'; end
end
