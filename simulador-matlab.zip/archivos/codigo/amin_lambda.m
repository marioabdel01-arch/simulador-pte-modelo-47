function L = amin_lambda(M, varargin)
%AMIN_LAMBDA  Barrido de la ponderacion que el articulo no especifica.
%
%   L = AMIN_LAMBDA(M)
%   L = AMIN_LAMBDA(M, 'lam',[0 1 3 10 30 100 300 1000], 'dur',800)
%
%   EL HUECO.  La seccion V dice que el coste (2) se usa con
%   P(q^-1) = 1, R(q^-1) = I y Q'(q^-1) = sqrt(lambda) I, y la ley reducida
%   lleva lambda (B0')^-1.  Pero **el valor numerico de lambda no aparece en
%   ninguna parte del articulo**.  Sin el, la replica no esta determinada.
%
%   Esta funcion corre las dos pruebas del articulo para cada lambda del
%   barrido, con el estimador encendido (la configuracion de su figura 6), y
%   devuelve el error maximo por salida.  Sirve para dos cosas:
%
%     1. elegir un valor y DECLARAR que la eleccion es nuestra, no de Amin;
%     2. ensenar cuanto depende su conclusion del parametro que no publico,
%        que es un resultado por si mismo.
%
%   El criterio de eleccion que se propone es el mas cercano a lo que el
%   articulo ensena: la lambda cuyo error maximo se parece mas al que se lee
%   en sus figuras 6a y 6b.  Esas lecturas van en L.objetivo y se pueden
%   cambiar; por omision estan tomadas de las escalas impresas (TSSO y TRHO
%   en R x10, PSSO en psia x10).
%
%   LA ESCALA DE LAMBDA NO ES LIBRE, Y CONVIENE SABERLO ANTES DE BARRER.
%   La ley invierte G = B0 + lambda (B0')^-1.  Con B0 = U S V' eso es
%   G = U (S + lambda/S) V', o sea que en cada direccion singular el mando se
%   reduce en un factor  s/(s + lambda/s) = s^2/(s^2 + lambda).  LAMBDA SE
%   COMPARA CON EL CUADRADO DE LOS VALORES SINGULARES DE B0, no con 1.  Con
%   el modelo identificado al 75 % (N = 6) esos valores son 96,5, 3,46 y
%   2,07, o sea s^2 = 9,3e3, 11,9 y 4,3: con lambda = 1 la direccion mas
%   debil solo se frena un 19 %, o sea que la ley es varianza minima a
%   efectos practicos.
%
%   PERO SUBIR LAMBDA NO ARREGLA NADA, Y HAY QUE ENTENDER POR QUE.  El mando
%   es u = u_ss + G^-1 rhs, con u_ss el punto de operacion AL QUE SE REFIRIO
%   EL MODELO.  Cuando lambda crece, G^-1 -> 0 y el mando tiende a u_ss, que
%   es la entrada de la carga INICIAL: durante una rampa eso es exactamente
%   congelar los mandos.  Medido en esta planta, el error maximo crece de
%   forma monotona con lambda (71 R y 744 psia con lambda = 0; 160 R y 1184
%   psia con lambda = 50).  O sea:
%
%     lambda pequena  -> varianza minima sobre un modelo con ceros fuera del
%                        circulo: el lazo se va en oscilacion y satura;
%     lambda grande   -> mando pegado a u_ss: error de regimen enorme.
%
%   No hay un lambda bueno porque el problema NO es lambda.  El modelo (16)
%   es incremental y 3x3: no tiene termino constante ni entrada de carga, asi
%   que NO PUEDE mover su propio punto de operacion, y la rampa de carga es
%   para el una perturbacion no medida.  Por eso el articulo acaba anadiendo
%   la tabla por nivel de carga de la seccion V: es la unica forma, dentro de
%   su estructura, de recolocar u_ss.  El barrido de lambda sirve para
%   DOCUMENTAR esto, no para encontrar un valor que salve la figura 6.
%
%   POR QUE 'figuras' USA EL ERROR MAXIMO.  Para evaluar desempeno esta
%   tesis usa indices integrales (IAE, ITAE), no el error maximo.  Aqui se
%   hace una excepcion, y solo aqui: la pregunta no es que lambda controla
%   mejor, sino que lambda usaron Amin et al., y de sus figuras 6a y 6b
%   impresas lo unico que se puede leer con alguna fiabilidad es el pico de
%   cada curva.  No hay forma de sacar su IAE de una grafica de 1984.  Para
%   cualquier comparacion de desempeno usense L.Jiae / L.Jitae o
%   AMIN_LAMBDA_TODOS, que reporta IAE e ITAE normalizados por el PI.
%
%   DOS CRITERIOS, DOS PREGUNTAS DISTINTAS.
%     'figuras' (por omision)  que par reproduce mejor lo que Amin publico.
%                              Es el criterio de la REPLICA: busca SU lambda.
%     'iae', 'itae', 'ise',    que par da el mejor desempeno integral segun
%     'itse'                   ese indice.  Es un criterio de SINTONIA: busca
%                              el mejor lambda, que no tiene por que ser el
%                              suyo.
%   Los dos se calculan siempre; 'criterio' solo decide cual se devuelve en
%   L.elegida / L.elegidaBeta.  El indice integral es
%
%       J_IAE = (1/6) sum_{prueba, salida} IAE / IAE_PI
%
%   o sea el IAE de cada salida normalizado por el del PI de Usoro en la misma
%   prueba (J_IAE = 1 empata con el PI, < 1 lo mejora).  Normalizar hace
%   sumables temperaturas y presion.  Igual con J_ITAE, J_ISE y J_ITSE.
%
%   DEVUELVE  L.lam, L.beta, L.emax (nlam x nbeta x 3 x 2), L.peor,
%             L.dist, L.sat, L.corto, L.elegida, L.elegidaBeta, L.objetivo,
%             L.iae, L.itae, L.ise, L.itse (nlam x nbeta x 3 x 2),
%             L.iaePI, L.itaePI, L.isePI, L.itsePI (3 x 2),
%             L.Jiae, L.Jitae, L.Jise, L.Jitse (nlam x nbeta),
%             L.figuras y L.opt.(indice) (el par elegido por cada criterio),
%             L.optIAE (= L.opt.iae, por compatibilidad), L.criterio
%
%   See also AMIN_STC_INIT, AMIN_RUN.

opt = struct('lam',[0 0.25 0.5 1 2 5 10 50], 'beta',[0.95 0.98 0.99 1], ...
             'P0',1e2, 'dur',800, 'objetivo',[], 'criterio','figuras', ...
             'verbose',true);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_lambda:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

% LECTURA DE LAS FIGURAS 6a Y 6b, que es lo unico que el articulo da sobre
% el comportamiento del lazo.  Se leen sobre las graficas impresas, cuyos
% ejes son:
%
%   TSSO y TRHO:  140,00  144,00  148,00  152,00   (R x10^1)
%   PSSO:         200,00  220,00  240,00  260,00  280,00   (psia x10^1)
%
% y las consignas caen en 1459,67 R y 2415 psia.  Desviacion maxima de la
% curva del auto-sintonizable respecto de su consigna:
%
%   fig. 6a (90 -> 70 %):  TSSO baja a ~1437 y sube a ~1470  -> ~23 R
%                          TRHO se mueve ~10 R
%                          PSSO sube a ~2660 y baja a ~2260  -> ~250 psia
%   fig. 6b (70 -> 90 %):  TSSO baja a ~1441                 -> ~20 R
%                          TRHO se mueve ~10 R
%                          PSSO baja a ~2215                 -> ~200 psia
%
% SON LECTURAS DE UNA GRAFICA DE CAMARA DE 1984, con su error: sirven para
% ordenar candidatos y para decir cuanto nos separamos, no para validar
% digito a digito.  Se pueden cambiar con la opcion 'objetivo'.
if isempty(opt.objetivo)
    opt.objetivo = [23 10 250;      % 90 -> 70 %   (TSSO R, TRHO R, PSSO psia)
                    20 10 200];     % 70 -> 90 %
end

pruebas = {[90 70], [70 90]};
nl = numel(opt.lam);
nb = numel(opt.beta);
L = struct('lam',opt.lam(:).', 'beta',opt.beta(:).', ...
           'emax',nan(nl,nb,3,2), 'peor',nan(nl,nb), ...
           'objetivo',opt.objetivo, 'dist',nan(nl,nb), ...
           'corto',false(nl,nb,2), 'sat',nan(nl,nb,2), ...
           'iae',nan(nl,nb,3,2), 'itae',nan(nl,nb,3,2), ...
           'ise',nan(nl,nb,3,2), 'itse',nan(nl,nb,3,2), ...
           'iaePI',nan(3,2), 'itaePI',nan(3,2), 'isePI',nan(3,2), 'itsePI',nan(3,2), ...
           'Jiae',nan(nl,nb), 'Jitae',nan(nl,nb), 'Jise',nan(nl,nb), ...
           'Jitse',nan(nl,nb), 'criterio',opt.criterio);
IND = {'iae','itae','ise','itse'};

for p = 1:2
    [P, info] = amin_rampa(pruebas{p}(1), pruebas{p}(2), ...
                           'dur',opt.dur, 'verbose',false);
    d0 = [];  if isfield(M,'nd') && M.nd > 0, d0 = info.ss.ldc; end
    M0 = amin_modelo(M.th, M.N, M.nu, M.ny, M.k, M.T, info.ss.u, info.ss.y, NaN, d0);
    % Referencia para normalizar los indices: los PI de Usoro en esta prueba.
    Rpi = amin_lazo([], P);
    for m = 1:4
        L.([IND{m} 'PI'])(:,p) = Rpi.(IND{m})(:);
    end
    for q = 1:nl
        for b = 1:nb
            S = amin_stc_init(M0, 'lambda',opt.lam(q), 'beta',opt.beta(b), ...
                              'adapt',true, 'P0',opt.P0, 'Tc',M.T);
            R = amin_lazo(S, P);
            L.emax(q,b,:,p) = R.emax;
            for m = 1:4
                L.(IND{m})(q,b,:,p) = R.(IND{m});
            end
            % DOS COSAS QUE EL e_max SOLO NO DICE, y sin las cuales la tabla
            % enganya: si la corrida se corto (la planta salio del rango
            % fisico, y entonces el e_max es el de un trozo) y que fraccion
            % de los instantes tiene algun mando contra los topes de 1 o 5 V.
            % Saturado no se esta controlando: se esta yendo a tope.
            L.corto(q,b,p) = R.t(end) < opt.dur - 1e-6;
            L.sat(q,b,p) = mean(any(R.U <= 1 + 1e-9 | R.U >= 5 - 1e-9, 1));
            if opt.verbose
                marca = '';
                if L.corto(q,b,p), marca = '  <-- CORTADA'; end
                fprintf(['lambda %6.2f  beta %5.3f  prueba %d  ' ...
                         'IAE %9.0f %9.0f %10.0f   sat %3.0f %%%s\n'], ...
                        opt.lam(q), opt.beta(b), p, R.iae, ...
                        100*L.sat(q,b,p), marca);
            end
        end
    end
end

for q = 1:nl
    for b = 1:nb
        L.peor(q,b) = max(max(L.emax(q,b,:,:)));
        d = 0;
        for p = 1:2
            e = reshape(L.emax(q,b,:,p), 1, 3);
            d = d + sum(((e - opt.objetivo(p,:))./opt.objetivo(p,:)).^2);
        end
        L.dist(q,b) = sqrt(d/6);
        for m = 1:4
            r = reshape(L.(IND{m})(q,b,:,:), 3, 2) ./ L.([IND{m} 'PI']);
            L.(['J' IND{m}])(q,b) = mean(r(:));
        end
    end
end

% Solo compiten los pares cuyas DOS corridas llegaron al final.
vale = ~any(L.corto, 3);
d = L.dist;
if ~any(vale(:))
    L.ningunaEntera = true;
else
    L.ningunaEntera = false;
    d(~vale) = inf;
end
[~, j] = min(d(:));
[jq, jb] = ind2sub([nl nb], j);
L.figuras = [opt.lam(jq) opt.beta(jb)];
L.opt = struct();
for m = 1:4
    J = L.(['J' IND{m}]);  J(~vale) = inf;
    [~, j2] = min(J(:));
    [iq, ib] = ind2sub([nl nb], j2);
    L.opt.(IND{m}) = [opt.lam(iq) opt.beta(ib)];
    if strcmpi(opt.criterio, IND{m}), jq = iq;  jb = ib; end
end
L.optIAE = L.opt.iae;
if ~any(strcmpi(opt.criterio, [{'figuras'} IND]))
    error('amin_lambda:criterio', 'criterio desconocido: %s', opt.criterio);
end
L.elegida = opt.lam(jq);
L.elegidaBeta = opt.beta(jb);

if opt.verbose
    fprintf('\nDISTANCIA A LAS FIGURAS 6a/6b  (filas lambda, columnas beta)\n');
    fprintf('%10s', 'lambda');
    fprintf(' %9.3f', opt.beta);  fprintf('\n');
    for q = 1:nl
        fprintf('%10.2f', opt.lam(q));
        fprintf(' %9.3f', L.dist(q,:));
        fprintf('\n');
    end
    fprintf('\nSATURACION MAXIMA DE LAS DOS PRUEBAS, %% de instantes con algun mando en el tope\n');
    fprintf('%10s', 'lambda');
    fprintf(' %9.3f', opt.beta);  fprintf('\n');
    for q = 1:nl
        fprintf('%10.2f', opt.lam(q));
        fprintf(' %8.0f%%', 100*max(L.sat(q,:,:), [], 3));
        fprintf('\n');
    end
    for m = 1:4
        nomI = upper(IND{m});
        fprintf(['\nJ_%s = media de %s/%s_PI en 3 salidas x 2 pruebas ' ...
                 '(1 = empata con el PI)\n'], nomI, nomI, nomI);
        fprintf('%10s', 'lambda');
        fprintf(' %9.3f', opt.beta);  fprintf('\n');
        for q = 1:nl
            fprintf('%10.2f', opt.lam(q));
            fprintf(' %9.3f', L.(['J' IND{m}])(q,:));
            fprintf('\n');
        end
    end
    fprintf('\ncriterio de figuras (replica):  lambda = %g, beta = %g\n', L.figuras);
    for m = 1:4
        o = L.opt.(IND{m});
        Jm = L.(['J' IND{m}])(opt.lam == o(1), opt.beta == o(2));
        fprintf('criterio de %-5s (sintonia): lambda = %g, beta = %g  (J = %.3f)\n', ...
                upper(IND{m}), o, Jm);
    end
    fprintf('\n-> [%s] lambda = %g, beta = %g  (distancia %.3f, saturacion %.0f %%)\n', ...
            opt.criterio, ...
            L.elegida, L.elegidaBeta, L.dist(jq,jb), ...
            100*max(L.sat(jq,jb,:)));
    fprintf(['ES UNA CALIBRACION DE ESTA REPLICA CONTRA LAS FIGURAS ' ...
             'IMPRESAS,\nno un dato del articulo.\n']);
    if L.ningunaEntera
        fprintf(['\nOJO: NINGUN par completa las dos pruebas.  La eleccion ' ...
                 'es entre corridas cortadas\n     y no significa nada ' ...
                 'todavia.\n']);
    end
end
end
