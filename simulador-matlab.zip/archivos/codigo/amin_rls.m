function E = amin_rls(E, y, x)
%AMIN_RLS  Un paso del estimador de minimos cuadrados recursivo de Amin.
%
%   E = AMIN_RLS(E, Y, X)
%
%   Es LITERALMENTE la ecuacion (15) del articulo:
%
%       th(t) = th(t-1) + [y(t) - th(t-1) x(t-k)] k(t)
%       k(t)  = x(t-k) P(t-1) / (beta + x'(t-k) P(t-1) x(t-k))
%       P(t)  = (1/beta) [ P(t-1) { I - x(t-k) k(t) } ]
%
%   con th de tamano m x npar, x de npar x 1 y k(t) de 1 x npar.  No lleva
%   NINGUNA de las protecciones del resto de esta tesis ---ni zona muerta, ni
%   cota de traza, ni limite de paso, ni proyeccion sobre sigma_min(B0)---
%   porque el articulo no las tiene.  Esa ausencia es parte de la replica.
%
%   CAMPOS DE E
%     th    m x npar,   matriz de parametros [B0 ... BN  -A1 ... -AN]
%     P     npar x npar, covarianza
%     beta  factor de olvido.  EL ARTICULO NO DA SU VALOR (ver README, hueco 2)
%     n     numero de actualizaciones hechas
%
%   La simetrizacion de P al final no esta en el articulo: es aritmetica de
%   punto flotante, no algoritmo.  Sin ella P pierde la simetria en unas pocas
%   decenas de pasos y el estimador se degrada por una razon que no es la que
%   se quiere estudiar.
%
%   Amin, Masada y Womack (1984), ec. (15).
%
%   See also AMIN_IDENT, AMIN_STC.

Px  = E.P * x;
den = E.beta + x.' * Px;
if ~isfinite(den) || den <= 0
    error('amin_rls:den', 'Denominador no positivo (%g) en el paso %d.', den, E.n);
end
k = (Px.') / den;                       % 1 x npar

E.th = E.th + (y - E.th*x) * k;
E.P  = (E.P - Px*k) / E.beta;
E.P  = (E.P + E.P.')/2;
E.n  = E.n + 1;
end
