function D = amin_datos(varargin)
%AMIN_DATOS  Las diez corridas de identificacion de la seccion IV.
%
%   D = AMIN_DATOS
%   D = AMIN_DATOS('pct',75, 'nRun',10, 'dur',400, 'T',20, 'semilla',1984)
%
%   REPRODUCE EL EXPERIMENTO DEL ARTICULO, punto por punto:
%
%   * Nivel de carga: 75 %, en LAZO ABIERTO.  Los tres lazos PI se abren y
%     sus integradores se congelan (bandera `openLoop` del modelo), porque
%     el modelo AR describe la relacion entrada-salida de la planta, no la
%     del lazo cerrado.
%
%     OJO: SOLO se abren esos tres.  Los demas lazos de Usoro siguen
%     cerrados ---aire/combustible con su limite cruzado, agua de
%     alimentacion, nivel de domo y el CONTROL DE CARGA DE LA TURBINA, que
%     mueve la valvula para seguir ldc con los MW medidos---.  El articulo
%     no dice que hace con la turbina (README, hueco 9).  Con ese lazo
%     cerrado y sin el lazo maestro de caldera la presion es INESTABLE en
%     lazo abierto:
%
%       presion baja -> bajan los MW -> la turbina abre la valvula
%                    -> sale mas vapor -> la presion baja mas
%
%     Por eso las diez corridas derivan hacia presiones mas bajas (de -243 a
%     -681 psia a los 400 s).  Con la valvula fija la corrida 1 deriva
%     -112 psia en vez de -606.  Ademas, el limite cruzado aire/combustible
%     rectifica la entrada aleatoria: en promedio entra menos combustible
%     del que pide CBMD, y la presion baja aunque la entrada tenga media
%     cero.
%
%   * Entradas: generador de numeros aleatorios, distribucion gaussiana, con
%     media igual al valor de estado estable de cada entrada y desviacion
%     tipica igual al limite de fluctuacion aceptable:
%
%         CBMD  +-0,1      CXGG  +-0,3      CWSY  +-0,6
%
%     El articulo obtiene esos limites con este criterio, que se comprueba
%     aparte en AMIN_LIMITES:  «the fluctuating input should not cause, in
%     any of the outputs, a fluctuation with amplitude greater than 1 % of
%     the steady state of the output».
%
%     Los tres valores SON DEL ARTICULO (nota al pie de la p. 343) y se usan
%     tal cual.  En esta planta no cumplen ese criterio del 1 % ---lo mide
%     AMIN_LIMITES--- y eso se reporta, pero no se cambian: con otras
%     amplitudes ya no seria su experimento (README, seccion 2 bis d).
%
%   * Duracion: 400 s por corrida.  No es una eleccion de comodidad: pasado
%     ese tiempo el sistema en lazo abierto se ha alejado del nivel de carga
%     inicial y las muestras ya no describen ese punto de operacion.  El
%     articulo lo dice y su figura 5 lo ensena.
%
%   * Numero de corridas: 10, todas desde el MISMO estado inicial y con
%     entradas aleatorias distintas.
%
%   * Muestreo: T = 20 s.  Retencion de orden cero: cada entrada se sortea
%     una vez por periodo de muestreo y se mantiene.  El articulo no dice
%     otra cosa, y sortear en cada paso de integracion convertiria la
%     entrada en ruido blanco continuo, que es un experimento distinto.
%
%   OPCIONES
%     'pct'      nivel de carga                                   [75]
%     'nRun'     numero de corridas                               [10]
%     'dur'      segundos por corrida                            [400]
%     'T'        periodo de muestreo, s                           [20]
%     'sigma'    desviaciones tipicas de las tres entradas [0.1 0.3 0.6]
%     'semilla'  semilla del generador (para poder repetirlo)   [1984]
%     'cache'    guardar/leer datos/amin_datos_<pct>.mat        [true]
%     'sigmaLdc' desviacion tipica de la demanda de carga, V.  Vacio = la
%                demanda se queda quieta, que es el experimento del
%                articulo (modelo 3x3).  Con un valor, ldc se excita tambien
%                y los datos sirven para el modelo 3x4.            [[]]
%     'valvula'  VALVULA DE LA TURBINA FIJA (kc1tr = 0, sin lazo de
%                potencia).  Usa las MISMAS secuencias de mandos que los
%                datos 3x3 guardados, para que la comparacion sea pareada;
%                se guarda en datos/amin_datos_<pct>_valvula.mat.  Es la
%                otra lectura del hueco 9, la que se parece a la figura 5.
%                                                                [false]
%
%   CON LA DEMANDA EXCITADA ---NO ES DEL ARTICULO---.  Para identificar el
%   bloque D del modelo 3x4 la demanda tiene que moverse durante el
%   experimento: si se queda en su valor de estado estable, su columna del
%   regresor es identicamente cero y D no se puede estimar.  Se excita igual
%   que los mandos ---gaussiana alrededor de ldc_ss, retenida un periodo T---
%   y SOLO se anade eso: las secuencias de los tres mandos se LEEN de los
%   datos 3x3 guardados (datos/amin_datos_<pct>.mat), asi que son las
%   mismas y la unica diferencia entre los dos juegos es la demanda.  Si
%   no hay datos 3x3 guardados, se sortean con la semilla, y entonces solo
%   coinciden con los del 3x3 si los dos se generan en la misma plataforma:
%   rng(s,'twister') en MATLAB y randn('state',s) en Octave NO dan la misma
%   secuencia.  Se cachea en datos/amin_datos_<pct>_ldc.mat.
%
%   ERRATA.  El datos/amin_datos_75_ldc.mat que acompana a esta carpeta se
%   genero en Octave ANTES de esta correccion: sus mandos NO son los del
%   3x3 (que se genero en MATLAB).  Ver README, seccion 8.
%
%   CACHE.  Se acepta el archivo guardado solo si coincide con lo que se
%   pide (numero de corridas, duracion, T, sigma y semilla); si no, se
%   genera de nuevo y NO se sobrescribe el guardado, con un aviso.  Asi una
%   corrida de prueba corta no puede reemplazar los datos de la replica.
%
%   DEVUELVE  D.run(r).U (3 x n), D.run(r).Y (3 x n), D.run(r).t
%             D.run(r).L (1 x n, ldc; vacio en el 3x3)
%             D.u_ss, D.y_ss, D.d_ss, D.T, D.k, D.pct, D.sigma, D.sigmaLdc,
%             D.semilla
%
%   See also AMIN_ESTACIONARIO, AMIN_IDENT, AMIN_LIMITES.

opt = struct('pct',75, 'nRun',10, 'dur',400, 'T',20, ...
             'sigma',[0.1 0.3 0.6], 'semilla',1984, 'cache',true, ...
             'verbose',true, 'sigmaLdc',[], 'valvula',false);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_datos:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

conLdc = ~isempty(opt.sigmaLdc) && opt.sigmaLdc > 0;
if conLdc, suf = '_ldc'; else, suf = ''; end
if opt.valvula, suf = [suf '_valvula']; end
arch = fullfile('datos', sprintf('amin_datos_%s%s.mat', num2str(opt.pct), suf));
guardar = opt.cache;
if opt.cache && exist(arch,'file') == 2
    q = load(arch);  D = q.D;
    if conLdc && (~isfield(D,'sigmaLdc') || D.sigmaLdc ~= opt.sigmaLdc)
        error('amin_datos:cacheldc', ...
              ['%s se genero con sigmaLdc = %g y se pide %g.  Borralo para ' ...
               'regenerarlo.'], arch, D.sigmaLdc, opt.sigmaLdc);
    end
    igual = numel(D.run) == opt.nRun && D.dur == opt.dur && D.T == opt.T && ...
            isequal(D.sigma(:), opt.sigma(:)) && D.semilla == opt.semilla;
    if igual
        if opt.verbose
            fprintf('datos de identificacion: leidos de %s (%d corridas)\n', ...
                    arch, numel(D.run));
        end
        return
    end
    warning('amin_datos:otrocache', ...
        ['%s es de otro experimento (%d corridas de %g s).  Se generan datos ' ...
         'nuevos y NO se guardan, para no reemplazarlo.'], arch, numel(D.run), D.dur);
    guardar = false;
end

S = amin_estacionario(opt.pct, 'verbose',opt.verbose);

Ts     = 0.1;
stride = round(opt.T/Ts);
nS     = floor(opt.dur/opt.T);              % muestras por corrida
nPaso  = nS*stride;

reinicia_semilla_(opt.semilla);

D = struct();
D.pct = opt.pct;  D.T = opt.T;  D.k = 1;
D.u_ss = S.u(:);  D.y_ss = S.y(:);
D.sigma = opt.sigma(:).';
D.semilla = opt.semilla;
D.dur = opt.dur;
D.valvula = opt.valvula;
D.run = struct('U',{},'Y',{},'t',{},'L',{});
if conLdc
    D.d_ss = S.ldc;  D.sigmaLdc = opt.sigmaLdc;
else
    D.d_ss = zeros(0,1);  D.sigmaLdc = 0;
end

% Las secuencias de los MANDOS se sortean todas primero y en el mismo orden
% que siempre.  En el 3x4 se toman, si existen, de los datos 3x3 guardados:
% asi los mandos son exactamente los mismos en cualquier plataforma y la
% demanda es lo unico que cambia (ver la cabecera).
UseqAll = cell(1, opt.nRun);
for r = 1:opt.nRun
    UseqAll{r} = S.u(:)*ones(1,nS) + diag(opt.sigma)*randn(3, nS);
end
D.mandosDe = 'sorteo';
arch3 = fullfile('datos', sprintf('amin_datos_%s.mat', num2str(opt.pct)));
if (conLdc || opt.valvula) && exist(arch3,'file') == 2
    q3 = load(arch3);
    if numel(q3.D.run) >= opt.nRun && size(q3.D.run(1).U,2) == nS
        for r = 1:opt.nRun, UseqAll{r} = q3.D.run(r).U; end
        D.mandosDe = arch3;
    end
end
LseqAll = cell(1, opt.nRun);
for r = 1:opt.nRun
    if conLdc
        L = S.ldc + opt.sigmaLdc*randn(1, nS);
        LseqAll{r} = min(max(L, 1), 5);      % rango del Load Demand Computer
    else
        LseqAll{r} = zeros(0, nS);
    end
end

for r = 1:opt.nRun
    % Secuencia de entradas de ESTA corrida, una muestra por periodo.
    Useq = UseqAll{r};
    Lseq = LseqAll{r};

    uNow = Useq(:,1);
    P = amin_planta(S.base, 'ldcStart',S.ldc, 'ldcRate',0, ...
                     'ldcT0',0, 'ldcT1',0, 'samples',nPaso+1);
    P.x0 = S.x0;
    P.openLoop = [true true true];
    if opt.valvula, P.kc1tr = 0; end      % valvula de la turbina fija (hueco 9)
    P.uFcn = @(tt) uNow;

    x = S.x0(:);  t = 0;
    U = zeros(3,nS);  Y = zeros(3,nS);  tt = zeros(1,nS);

    for s = 1:nS
        uNow = Useq(:,s);
        P.uFcn = @(z) uNow;
        if conLdc
            lNow = Lseq(s);
            P.ldcFcn = @(z) lNow;
        end
        % La muestra se toma ANTES de aplicar el periodo: y(t) es la salida
        % con la que el estimador ve u(t).  Con k = 1 el modelo relaciona
        % y(t) con u(t-1), asi que el desfase lo pone el regresor, no aqui.
        [~, yl] = digpte47(t, x, P);
        U(:,s) = uNow;
        Y(:,s) = yl(26:28).';
        tt(s)  = t;
        for i = 1:stride
            xd1 = digpte47(t,      x,              P);
            xd2 = digpte47(t+Ts/2, x + (Ts/2)*xd1, P);
            xd3 = digpte47(t+Ts/2, x + (Ts/2)*xd2, P);
            xd4 = digpte47(t+Ts,   x +  Ts  *xd3,  P);
            x = x + (Ts/6)*(xd1 + 2*xd2 + 2*xd3 + xd4);
            x = pte47_clamp(x, P);
            t = t + Ts;
        end
        if ~all(isfinite(x)) || ~isreal(x)
            error('amin_datos:diverge', ...
                  'Corrida %d: estado no finito o complejo en t = %g s.', r, t);
        end
    end

    D.run(r).U = U;  D.run(r).Y = Y;  D.run(r).t = tt;  D.run(r).L = Lseq;
    if opt.verbose
        dy = max(abs(Y - D.y_ss(:)*ones(1,nS)), [], 2).';
        fprintf(['corrida %2d/%2d   desviacion maxima de las salidas ' ...
                 '%7.2f %7.2f %8.2f\n'], r, opt.nRun, dy);
    end
end

if guardar
    if exist('datos','dir') ~= 7, mkdir('datos'); end
    save(arch, 'D', '-v7');            % -v7: legible en MATLAB y en Octave
end
end

% =========================================================================
function reinicia_semilla_(s)
%REINICIA_SEMILLA_  Reinicia el generador.  OJO: MATLAB (rng twister) y
%   Octave (randn state) dan secuencias DISTINTAS con la misma semilla.
try
    rng(s, 'twister');
catch
    randn('state', s); %#ok<RAND>
    rand('state',  s); %#ok<RAND>
end
end
