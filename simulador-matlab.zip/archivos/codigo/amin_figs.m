function arch = amin_figs(R, varargin)
%AMIN_FIGS  Las figuras 6, 7 y 8 del articulo, con sus mismos ejes.
%
%   ARCH = AMIN_FIGS(R)
%   ARCH = AMIN_FIGS(R, 'carpeta','resultados', 'fmt','png')
%
%   R sale de AMIN_RUN.  Se dibuja una figura por cada figura del articulo:
%
%     fig6  PI contra auto-sintonizable            (3 salidas x 2 pruebas)
%     fig7  PI contra «modified S.T.C.»            (3 salidas x 2 pruebas)
%     fig8  los tres mandos, PI / STC / modificado (3 mandos  x 2 pruebas)
%     fig_mando2s  la variante de mando cada 2 s, que el articulo describe pero no
%           publica: «the outputs for this case behave more smoothly than
%           those shown in Fig. 7, but deviations from the set points are
%           almost the same for both cases.  For this reason inputs and
%           outputs for this case are not shown.»
%
%   LOS EJES SON LOS DEL ARTICULO, leidos de sus graficas impresas:
%   temperaturas de 1440 a 1520 R, presion de 2200 a 2600 psia, tiempo de 0 a
%   800 s.  Se dejan fijos a proposito: reproducir una figura con otra escala
%   es reproducir otra figura.  Si una curva se sale del cuadro, se sale ---y
%   eso es informacion, no un defecto del dibujo---.
%
%   See also AMIN_RUN.

opt = struct('carpeta','resultados', 'fmt','png', 'res',150, 'ejes',true);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_figs:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end
if exist(opt.carpeta,'dir') ~= 7, mkdir(opt.carpeta); end

nomY = {'TSSO,  R', 'TRHO,  R', 'PSSO,  psia'};
nomU = {'CBMD,  V', 'CXGG,  V', 'CWSY,  V'};
limY = {[1440 1520], [1440 1520], [2200 2600]};
limU = {[1 5], [1 5], [1 5]};
limT = [0 800];

arch = {};

arch{end+1} = salidas_(R, {'pi','stc'}, ...
    {'PI de Usoro','auto-sintonizable'}, 'fig6', ...
    'Figura 6: respuesta a la rampa de carga al 10 %/min', ...
    nomY, limY, limT, opt);

arch{end+1} = salidas_(R, {'pi','mstc20'}, ...
    {'PI de Usoro','modified S.T.C.'}, 'fig7', ...
    'Figura 7: PI contra el S.T.C. modificado (tabla por carga)', ...
    nomY, limY, limT, opt);

arch{end+1} = mandos_(R, {'pi','stc','mstc20'}, ...
    {'PI de Usoro','auto-sintonizable','modified S.T.C.'}, 'fig8', ...
    'Figura 8: mandos calculados por cada controlador', ...
    nomU, limU, limT, opt);

arch{end+1} = salidas_(R, {'mstc20','mstc2'}, ...
    {'modificado, mando 20 s','modificado, mando 2 s'}, 'fig_mando2s', ...
    'Mando cada 2 s contra cada 20 s (no publicada en el artículo)', ...
    nomY, limY, limT, opt);
end

% =========================================================================
function a = salidas_(R, cs, et, nombre, titulo, nomY, limY, limT, opt)
f = figure('Position',[60 60 1000 780], 'Color','w');
for p = 1:2
    for s = 1:3
        subplot(3,2,(s-1)*2 + p);  hold on
        C = R.prueba(p).ctrl;
        plot(C.(cs{1}).tc, C.(cs{1}).W(s,:), 'k--', 'LineWidth',1.0);
        h = [];
        for q = 1:numel(cs)
            h(end+1) = plot(C.(cs{q}).tc, C.(cs{q}).Y(s,:), '-', 'LineWidth',1.5);
        end
        xlim(limT);
        if opt.ejes, ylim(limY{s}); end
        grid on;  box off
        ylabel(nomY{s});
        if s == 1, title(R.prueba(p).nombre); end
        if s == 3, xlabel('TIME , SEC.'); end
        if s == 1 && p == 1
            try, legend([h], et, 'Location','best', 'Box','off'); catch, end
        end
    end
end
try
    sgtitle(titulo);
catch
    try, annotation(f,'textbox',[0.05 0.96 0.9 0.03],'String',titulo, ...
                    'EdgeColor','none','HorizontalAlignment','center'); catch, end
end
a = fullfile(opt.carpeta, sprintf('amin_%s.%s', nombre, opt.fmt));
guarda_(f, a, opt.res);
close(f);
end

% =========================================================================
function a = mandos_(R, cs, et, nombre, titulo, nomU, limU, limT, opt)
f = figure('Position',[60 60 1000 780], 'Color','w');
for p = 1:2
    for s = 1:3
        subplot(3,2,(s-1)*2 + p);  hold on
        C = R.prueba(p).ctrl;
        h = [];
        for q = 1:numel(cs)
            h(q) = plot(C.(cs{q}).tc, C.(cs{q}).U(s,:), '-', 'LineWidth',1.5);
        end
        xlim(limT);
        if opt.ejes, ylim(limU{s}); end
        grid on;  box off
        ylabel(nomU{s});
        if s == 1, title(R.prueba(p).nombre); end
        if s == 3, xlabel('TIME , SEC.'); end
        if s == 1 && p == 1
            try, legend(h, et, 'Location','best', 'Box','off'); catch, end
        end
    end
end
try
    sgtitle(titulo);
catch
    try, annotation(f,'textbox',[0.05 0.96 0.9 0.03],'String',titulo, ...
                    'EdgeColor','none','HorizontalAlignment','center'); catch, end
end
a = fullfile(opt.carpeta, sprintf('amin_%s.%s', nombre, opt.fmt));
guarda_(f, a, opt.res);
close(f);
end

% =========================================================================
function guarda_(f, a, res)
try
    exportgraphics(f, a, 'Resolution',res, 'BackgroundColor','white');
catch
    print(f, a, '-dpng', sprintf('-r%d', res));
end
end
