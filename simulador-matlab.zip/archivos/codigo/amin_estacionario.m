function S = amin_estacionario(pct, varargin)
%AMIN_ESTACIONARIO  Estado estable de la planta a un nivel de carga dado.
%
%   S = AMIN_ESTACIONARIO(PCT)
%   S = AMIN_ESTACIONARIO(PCT, 'asentar',3000, 'cache',true)
%
%   POR QUE HACE FALTA.  El articulo identifica al 75 % de carga y construye
%   su tabla de parametros a 70, 75, 80, 85 y 90 %.  La tesis de Usoro solo
%   tabula las condiciones iniciales de tres niveles: 100, 77,5 y 50 %.  Los
%   cinco de Amin hay que generarlos, y la unica forma honesta de hacerlo es
%   la misma que usaria la planta: llevarla alli con la demanda de carga y
%   dejar que los lazos PI originales la asienten.
%
%   PROCEDIMIENTO
%     1. arrancar en el caso tabulado mas cercano ('100', '775' o '50');
%     2. rampa de ldc hasta el nivel pedido a 10 %/min, la velocidad de Amin;
%     3. mantener la demanda y correr hasta que el estado deje de moverse;
%     4. devolver x, y = (TSSO, TRHO, PSSO) y u = (CBMD, CXGG, CWSY).
%
%   Se comprueba explicitamente que ||xdot|| ha caido y se AVISA si no.  Un
%   punto de operacion mal asentado se propaga a todo lo demas: el modelo
%   incremental quedaria referido a un punto que la planta no ocupa.
%
%   OPCIONES
%     'asentar'  segundos de carga constante tras la rampa       [3000]
%     'cache'    guardar/leer datos/amin_ss_<pct>.mat            [true]
%     'tol'      aviso si ||xdot|| final supera este valor        [1e-2]
%
%   DEVUELVE  S.pct, S.ldc, S.x0 (47x1), S.y (3x1), S.u (3x1), S.w (3x1),
%             S.xdot, S.base, S.t
%
%   See also AMIN_CARGA, AMIN_DATOS, AMIN_TABLA.

opt = struct('asentar',3000, 'cache',true, 'tol',1e-2, 'verbose',true);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_estacionario:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

arch = fullfile('datos', sprintf('amin_ss_%s.mat', num2str(pct)));
if opt.cache && exist(arch,'file') == 2
    q = load(arch);  S = q.S;
    % NO FIARSE DEL CACHE.  Un punto de operacion malo se propaga a todo lo
    % demas sin dar la cara: el modelo incremental quedaria referido a un
    % estado que la planta no ocupa, y si ademas es COMPLEJO ---lo que ocurre
    % cuando la planta se sale del rango fisico y una rutina de propiedades
    % del vapor evalua sqrt() de un argumento negativo--- el sintoma aparece
    % mucho despues y en otro sitio, tipicamente al dibujar:
    %     «Complex values are not supported for 'Y'»
    % Por eso se comprueba al LEER, no solo al escribir.
    if ~isreal(S.x0) || ~all(isfinite(S.x0)) || ...
       ~isreal(S.y)  || ~all(isfinite(S.y))  || ...
       ~isreal(S.u)  || ~all(isfinite(S.u))
        warning('amin_estacionario:cachemalo', ...
            ['El estacionario guardado en %s no es real y finito.  Se ' ...
             'descarta y se vuelve a calcular.'], arch);
        delete(arch);
    else
        if opt.verbose
            fprintf('estacionario %g %%: leido de %s\n', pct, arch);
        end
        return
    end
end

[ldc, base] = amin_carga(pct);
ldc0 = amin_carga(pct_de_base_(base));

rate = sign(ldc - ldc0) / 120;              % 10 %/min = 1/120 V/s
if ldc == ldc0
    tramp = 0;  rate = 0;
else
    tramp = abs(ldc - ldc0) * 120;
end
T0 = 10;
dur = T0 + tramp + opt.asentar;

P = amin_planta(base, 'ldcStart',ldc0, 'ldcRate',rate, ...
                 'ldcT0',T0, 'ldcT1',T0+tramp, ...
                 'samples', round(dur/0.1)+1);

x  = P.x0(:);
Ts = P.Ts;
n  = P.samples - 1;
t  = 0;
for i = 1:n
    xd1 = digpte47(t,        x,              P);
    xd2 = digpte47(t+Ts/2,   x + (Ts/2)*xd1, P);
    xd3 = digpte47(t+Ts/2,   x + (Ts/2)*xd2, P);
    xd4 = digpte47(t+Ts,     x +  Ts  *xd3,  P);
    x = x + (Ts/6)*(xd1 + 2*xd2 + 2*xd3 + xd4);
    x = pte47_clamp(x, P);
    t = t + Ts;
    if ~all(isfinite(x)) || ~isreal(x)
        error('amin_estacionario:diverge', ...
              ['Estado no finito o COMPLEJO en t = %g s llevando la planta ' ...
               'al %g %%.  Un estado complejo sale de un sqrt() de argumento ' ...
               'negativo en las rutinas de propiedades del vapor: la planta ' ...
               'se ha salido del rango fisico.'], t, pct);
    end
end

[xd, yl] = digpte47(t, x, P);

S = struct();
S.pct  = pct;
S.ldc  = ldc;
S.base = base;
S.t    = t;
S.x0   = x;
S.y    = yl(26:28).';
S.u    = yl(29:31).';
S.w    = yl(32:34).';
S.ldcF = yl(35);
S.xdot = norm(xd);

if S.xdot > opt.tol
    warning('amin_estacionario:noasentado', ...
        ['A %g %% de carga ||xdot|| = %.3g tras %g s de carga constante ' ...
         '(tolerancia %.3g).  Sube `asentar`.'], pct, S.xdot, opt.asentar, opt.tol);
end
if abs(S.ldcF - ldc) > 1e-9
    warning('amin_estacionario:ldc', ...
        'ldc final %.4f y se pedia %.4f.', S.ldcF, ldc);
end

if opt.verbose
    fprintf(['estacionario %5.1f %%  ldc %.4f   y = %9.3f %9.3f %9.3f   ' ...
             'u = %6.4f %6.4f %6.4f   ||xdot|| = %.2e\n'], ...
            pct, S.ldc, S.y, S.u, S.xdot);
end

if ~isreal(S.x0) || ~isreal(S.y) || ~isreal(S.u)
    error('amin_estacionario:complejo', ...
        ['El estado al %g %% de carga salio COMPLEJO.  Eso significa que la ' ...
         'planta se salio del rango fisico durante el asentamiento y alguna ' ...
         'rutina de propiedades del vapor evaluo sqrt() de un argumento ' ...
         'negativo.  No se guarda nada.'], pct);
end

if opt.cache
    if exist('datos','dir') ~= 7, mkdir('datos'); end
    save(arch, 'S', '-v7');            % -v7: legible en MATLAB y en Octave
end
end

% =========================================================================
function p = pct_de_base_(base)
switch base
    case '100', p = 100;
    case '775', p = 77.5;
    case '50',  p = 50;
    otherwise,  error('amin_estacionario:base','caso desconocido: %s', base);
end
end
