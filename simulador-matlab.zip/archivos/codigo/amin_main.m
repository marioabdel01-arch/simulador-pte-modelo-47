function OUT = amin_main(varargin)
%AMIN_MAIN  Corre la replica completa de Amin et al. (1984), de principio a fin.
%
%   >> setup_amin
%   >> OUT = amin_main
%   >> OUT = amin_main('rapido',true)       version corta, para comprobar
%
%   Ejecuta, EN EL ORDEN DEL ARTICULO:
%
%     seccion IV   1. retardos entrada-salida en lazo abierto      -> k
%                  2. limites de fluctuacion de las entradas
%                  3. limite superior del periodo de muestreo      -> T
%                  4. las diez corridas de 400 s al 75 % de carga
%                  5. identificacion del modelo AR y eleccion de N
%     seccion V    6. calibracion de lambda y beta (los dos que no da)
%                  7. la tabla de parametros por nivel de carga
%                  8. las dos rampas con los cuatro controladores
%                  9. las figuras
%
%   OPCIONES
%     'rapido'   corridas mas cortas y menos niveles.  NO es la replica:
%                sirve para comprobar que todo enlaza antes de pagar la
%                corrida entera.  NO TOCA los archivos de la replica: no
%                lee ni escribe la cache de datos ni de la tabla, y lo que
%                guarda lleva el sufijo _rapido (resultados/rapido/ para las
%                figuras).                                         [false]
%     'lambda'   saltarse la calibracion y fijar el valor              []
%     'beta'     igual, para el factor de olvido                      []
%     'pasos'    subconjunto de pasos a ejecutar               [1:9]
%     'orden'    'articulo' usa N = 5, el del articulo, y ademas imprime
%                el barrido completo para ensenar que el criterio no
%                separa ordenes; 'criterio' deja que el barrido elija.
%                POR OMISION 'articulo': esto es una replica, y el orden
%                es un dato publicado, no algo que haya que redescubrir.
%                                                          ['articulo']
%     'modelo'   '3x3' es el del articulo: u = [CBMD CXGG CWSY] -> y.
%                '3x4' anade la demanda de carga ldc como cuarta entrada
%                ---medida, no manipulada---: se excita en las corridas de
%                identificacion, el modelo gana el bloque D (39 par./fila)
%                y la ley la usa como prealimentacion.  NO ES DEL ARTICULO:
%                todo lo que produce va a archivos con sufijo _ldc y a
%                resultados/modelo_3x4/, y el 3x3 no se toca.     ['3x3']
%     'sigmaLdc' excitacion de ldc en la identificacion, V (solo 3x4)
%                                                  [AMIN_SIGMA_LDC]
%
%   El resultado se guarda en resultados/amin_replica.mat y el resumen en
%   resultados/amin_resumen.txt.
%
%   COSTE.  En MATLAB, la replica completa son del orden de 40 min: la mayor
%   parte se va en generar los estacionarios de 70..90 % y las diez corridas
%   de identificacion.  Todo eso se cachea en datos/, asi que la segunda vez
%   son minutos.
%
%   See also AMIN_RETARDOS, AMIN_DATOS, AMIN_IDENT, AMIN_TABLA, AMIN_RUN.

opt = struct('rapido',false, 'lambda',[], 'beta',[], 'pasos',1:9, ...
             'orden','articulo', 'verbose',true, 'modelo','3x3', 'sigmaLdc',[]);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_main:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

switch lower(opt.modelo)
  case '3x3', es34 = false;  suf = '';
  case '3x4', es34 = true;   suf = '_ldc';
  otherwise
    error('amin_main:modelo','modelo desconocido: %s  (''3x3'' o ''3x4'')', opt.modelo);
end
sigL = [];
if es34
    sigL = opt.sigmaLdc;
    if isempty(sigL), sigL = amin_sigma_ldc(); end
    fprintf(['\nMODELO 3x4: ldc como entrada exogena medida (sigma = %g V en la ' ...
             'identificacion).\nNO ES DEL ARTICULO.  Todo va a archivos *_ldc.\n'], sigL);
end

cacheOK = ~opt.rapido;               % 'rapido' no lee ni escribe cache
if opt.rapido
    nRun = 3;  Ncand = 1:5;  niveles = [70 80 90];  asentar = 600;
    lamv = [0.5 1 2];  betv = [0.98 1];  dur = 400;
    suf = [suf '_rapido'];
else
    nRun = 10; Ncand = 1:8;  niveles = 70:5:90;     asentar = 2000;
    lamv = [0 0.25 0.5 1 2 5 10 50];  betv = [0.95 0.98 0.99 1];  dur = 800;
end

OUT = struct('opt',opt);
tic;

if any(opt.pasos == 1)
    titulo_('1.  Retardos entrada-salida (seccion IV)');
    OUT.retardos = amin_retardos('verbose',opt.verbose);
end

if any(opt.pasos == 2)
    titulo_('2.  Limites de fluctuacion de las entradas (nota 1, p. 343)');
    OUT.limites = amin_limites('verbose',opt.verbose, 'ldc',es34);
end

if any(opt.pasos == 4) || any(opt.pasos == 3) || any(opt.pasos >= 5)
    titulo_('4.  Diez corridas de 400 s al 75 %, lazo abierto (seccion IV)');
    OUT.datos = amin_datos('nRun',nRun, 'verbose',opt.verbose, 'sigmaLdc',sigL, ...
                           'cache',cacheOK);
end

if any(opt.pasos == 3)
    titulo_('3.  Limite superior del periodo de muestreo (seccion IV)');
    OUT.espectro = amin_espectro(OUT.datos, 'verbose',opt.verbose);
end

if any(opt.pasos >= 5)
    titulo_('5.  Identificacion del modelo AR y eleccion del orden N');
    switch lower(opt.orden)
      case 'articulo'
        % El barrido se corre igual ---es el material del hueco 8--- pero
        % la eleccion la impone el articulo: N = 5.
        [OUT.M, OUT.tablaN] = amin_ident(OUT.datos, 'N',Ncand, ...
            'criterio','fijo', 'Nfijo',5, 'verbose',opt.verbose);
      case 'criterio'
        [OUT.M, OUT.tablaN] = amin_ident(OUT.datos, 'N',Ncand, ...
            'verbose',opt.verbose);
      otherwise
        error('amin_main:orden', ...
              'orden desconocido: %s  (''articulo'' o ''criterio'')', opt.orden);
    end
    % Se guarda aparte porque AMIN_SIM lo busca aqui.
    M = OUT.M;  M.pct = OUT.datos.pct; %#ok<NASGU>
    save(fullfile('datos',['amin_modelo' suf '.mat']), 'M', '-v7');
end

lam = opt.lambda;  bet = opt.beta;
if any(opt.pasos == 6) && isempty(lam)
    titulo_('6.  Calibracion de lambda y beta (los dos valores que el articulo no da)');
    OUT.lambda = amin_lambda(OUT.M, 'lam',lamv, 'beta',betv, 'dur',dur, ...
                             'verbose',opt.verbose);
    lam = OUT.lambda.elegida;
    if isempty(bet), bet = OUT.lambda.elegidaBeta; end
end
if isempty(lam), lam = 1; end
if isempty(bet), bet = 0.99; end
OUT.lambdaUsada = lam;
OUT.betaUsada   = bet;

if any(opt.pasos >= 7)
    titulo_('7.  Tabla de parametros por nivel de carga (seccion V)');
    OUT.TB = amin_tabla(OUT.M, 'pct',niveles, 'asentar',asentar, ...
                        'lambda',lam, 'beta',bet, 'verbose',opt.verbose, ...
                        'cache',cacheOK);
end

if any(opt.pasos >= 8)
    titulo_('8.  Las dos rampas del articulo con los cuatro controladores');
    OUT.R = amin_run(OUT.M, OUT.TB, 'lambda',lam, 'beta',bet, 'dur',dur, ...
                     'verbose',opt.verbose);
end

if any(opt.pasos == 9) && isfield(OUT,'R')
    titulo_('9.  Figuras');
    carpeta = 'resultados';
    if es34,       carpeta = fullfile(carpeta, 'modelo_3x4'); end
    if opt.rapido, carpeta = fullfile(carpeta, 'rapido');     end
    OUT.figs = amin_figs(OUT.R, 'carpeta',carpeta);
    for i = 1:numel(OUT.figs), fprintf('  %s\n', OUT.figs{i}); end
end

OUT.segundos = toc;

if exist('resultados','dir') ~= 7, mkdir('resultados'); end
save(fullfile('resultados',['amin_replica' suf '.mat']), 'OUT', '-v7');
amin_resumen(OUT, fullfile('resultados',['amin_resumen' suf '.txt']));

fprintf('\nReplica terminada en %.1f min.\n', OUT.segundos/60);
fprintf('  resultados/amin_replica%s.mat\n  resultados/amin_resumen%s.txt\n', suf, suf);
end

% =========================================================================
function titulo_(s)
fprintf('\n%s\n%s\n', s, repmat('-', 1, numel(s)));
end
