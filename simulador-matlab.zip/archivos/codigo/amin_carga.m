function [ldc, base] = amin_carga(pct)
%AMIN_CARGA  Conversion entre nivel de carga en por ciento y senal ldc.
%
%   [LDC, BASE] = AMIN_CARGA(PCT)
%
%   El Load Demand Computer de Usoro entrega 1..5 V por transductor lineal y
%   5 V corresponde a plena carga (600 MW):
%
%       ldc = 0.05 * pct          100 % -> 5.000 V
%                                  90 % -> 4.500 V
%                                  85 % -> 4.250 V
%                                  80 % -> 4.000 V
%                                  77,5 % -> 3.875 V   <- caso '775' del repo
%                                  75 % -> 3.750 V     <- nivel de Amin
%                                  70 % -> 3.500 V
%                                  50 % -> 2.500 V
%
%   BASE es el nombre del caso de condiciones iniciales mas cercano de los
%   tres que trae el modelo de Usoro ('100', '775', '50').  Los niveles que
%   Amin necesita ---70, 75, 80, 85 y 90 %--- NO estan tabulados en la tesis
%   de Usoro, asi que hay que generarlos llevando la planta hasta alli y
%   dejandola asentar (AMIN_ESTACIONARIO).
%
%   Velocidad de rampa de Amin: 10 % por minuto.
%
%       0.10 * 5 V / 60 s = 1/120 V/s = 8.3333e-3 V/s
%
%   (Usoro y Galindo usan 15 %/min = 0.0125 V/s.  No es la misma prueba.)
%
%   See also AMIN_ESTACIONARIO, AMIN_RAMPA.

ldc = 0.05 * pct;

d = abs([5.000 3.875 2.500] - ldc);
nm = {'100', '775', '50'};
[~, i] = min(d);
base = nm{i};
end
