function R = amin_lazo(S, P, varargin)
%AMIN_LAZO  Corre la planta de 47 estados con el controlador de Amin.
%
%   R = AMIN_LAZO([], P)                      solo los PI originales de Usoro
%   R = AMIN_LAZO(S, P)                       con el auto-sintonizable
%   R = AMIN_LAZO(S, P, 'tabla',TB, 'congelar',[t0 t1])   el «modificado»
%
%   S sale de AMIN_STC_INIT; P sale de PTE47_PARAMS con la rampa de carga ya
%   puesta (ver AMIN_RAMPA).  Con S vacio no se toca nada: la planta corre
%   con sus tres lazos PI, y es la linea base contra la que el articulo
%   compara en todas sus figuras.
%
%   INTEGRACION.  Runge-Kutta de cuarto orden y paso fijo 0,1 s, igual que el
%   resto del repositorio y que el FORTRAN de Usoro.  El mando se recalcula
%   cada S.Tc segundos y se mantiene entre instantes de control.
%
%   EL «MODIFIED S.T.C.» DE LA SECCION V se arma con dos opciones:
%
%     'tabla'     estructura de AMIN_TABLA con un juego de parametros por
%                 cada 5 % de carga.  En cada instante de control se lee la
%                 demanda, se redondea al nodo de 5 % mas cercano y, si ha
%                 cambiado, se cargan sus parametros.  Redondear al mas
%                 cercano es exactamente la regla del articulo: «the set of
%                 parameters that was obtained for the 70% load was used
%                 until the load reached 72.5% after which the controller
%                 switched to the set of parameters that was identified for
%                 75% load», y asi sucesivamente.
%
%     'congelar'  [t0 t1] segundos entre los que el estimador se apaga.  El
%                 articulo lo apaga al empezar el transitorio y lo mantiene
%                 apagado 130 s despues de llegar a la carga final.
%
%   PRUEBA CON DEMANDA REAL (AMIN_DEMANDA).  Opciones para el modificado:
%
%     'interp'    true: la tabla se interpola con la carga (AMIN_STC_INTERP)
%                 en lugar de conmutar al nodo mas cercano.          [false]
%     'umbral'    %/min: congela el estimador mientras la carga se mueve mas
%                 que esto y 'reten' segundos despues (AMIN_CONGELA_MOV).
%                 Vacio = no se usa.                                    [[]]
%     'reten'     s.                                                   [130]
%     'guardaX'   false: R.x y R.t solo en los instantes de control (24 h
%                 con el paso de 0,1 s serian 325 MB).                [true]
%
%   DEVUELVE
%     R.t, R.x        trayectoria completa (paso de integracion)
%     R.tc            instantes de control
%     R.Y, R.W, R.U   salidas, consignas y mandos en esos instantes
%     R.ldc           demanda de carga en esos instantes
%     R.nodo          nodo de la tabla usado en cada instante (NaN sin tabla)
%     R.adapt         si el estimador actualizo en ese instante
%     R.S             el controlador al final de la corrida
%
%   See also AMIN_STC_INIT, AMIN_STC, AMIN_TABLA, AMIN_RAMPA.

opt = struct('tabla',[], 'congelar',[], 'verbose',false, ...
             'interp',false, 'umbral',[], 'reten',130, 'guardaX',true);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_lazo:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

Ts = P.Ts;
n  = P.samples - 1;

soloPI = isempty(S);
if soloPI
    stride = round(20/Ts);          % solo para muestrear el registro
    % LA LINEA BASE MANDA CON LOS PI DE USORO, pase lo que pase con el P que
    % nos den.  Si el llamante venia de preparar una corrida del STC, ese P
    % trae openLoop = true y un uFcn que devuelve ceros: correr la base con
    % eso pone los tres mandos a 0 V ---fuera del rango 1..5 V de los
    % transductores--- y la planta se desploma.  Era exactamente el fallo de
    % la linea base del simulador.
    P.openLoop = [false false false];
    P.uFcn = [];
else
    stride = round(S.Tc/Ts);
    % OJO: NO se abre el lazo todavia.  Mientras el estimador se calienta
    % ---las primeras N muestras, que con N = 6 y T = 20 s son 120 s--- el
    % que tiene que mandar de verdad es el PI de Usoro, con sus integradores
    % vivos.  Abrir el lazo aqui congelaba esos integradores y dejaba los
    % tres mandos clavados en su valor de t = 0 durante toda la rampa: la
    % planta se iba sola y el STC recibia, al arrancar, un punto de
    % operacion absurdo y una historia sin informacion.
    P.openLoop = [false false false];
    P.uFcn = [];
end

nc  = floor(n/stride) + 1;
tc  = nan(1,nc);   Yc = nan(3,nc);  Wc = nan(3,nc);
Uc  = nan(3,nc);   Lc = nan(1,nc);  Nd = nan(1,nc);
Ad  = false(1,nc);

x  = P.x0(:);
t  = 0;
kc = 0;
uNow = [];
mandaSTC = false;             % true en cuanto la ley entrega su primer u

if opt.guardaX
    xs = nan(n+1, 47);  ts = nan(1, n+1);
    xs(1,:) = x.';  ts(1) = 0;
else
    xs = nan(nc, 47);  ts = nan(1, nc);       % se llenan en los instantes de control
end
g = struct('umbral',opt.umbral, 'reten',opt.reten, 'ult',-inf, 'lPrev',NaN);

for i = 1:n
    if mod(i-1, stride) == 0
        % --- instante de control ---------------------------------------
        % Mientras manda el PI, P ya esta en lazo cerrado y yl(29:31) trae su
        % mando de verdad.  Cuando manda el STC, P esta en lazo abierto y
        % yl(29:31) trae lo que se le esta imponiendo a la planta, que es lo
        % que el estimador tiene que registrar.
        [~, yl] = digpte47(t, x, P);
        y   = yl(26:28).';
        w   = yl(32:34).';
        uPI = yl(29:31).';
        ldc = yl(35);

        kc = kc + 1;
        nodo = NaN;

        if ~soloPI
            % --- tabla por carga (seccion V) ---------------------------
            if ~isempty(opt.tabla)
                nodo = amin_nodo(opt.tabla, ldc);
                if ~opt.interp && (~isfield(S,'nodoActual') || S.nodoActual ~= nodo)
                    S = carga_nodo_(S, opt.tabla, nodo);
                end
            end
            % --- congelacion del estimador -----------------------------
            if ~isempty(opt.congelar)
                S.adapt = ~(t >= opt.congelar(1) && t <= opt.congelar(2));
            end
            if ~isempty(opt.umbral)          % demanda real: mientras se mueve
                [S, g] = amin_congela_mov(S, g, t, ldc, stride*Ts);
            end
            if opt.interp                    % demanda real: tabla interpolada
                S = amin_stc_interp(S, opt.tabla, ldc);
            end

            [u, S] = amin_stc(S, y, w, uPI, ldc);   % ldc: solo la usa el 3x4
            if isempty(u)
                % CALENTAMIENTO: manda el PI de Usoro, y manda de verdad ---
                % el lazo sigue cerrado y sus integradores siguen vivos---.
                uNow = uPI;
                P.openLoop = [false false false];
                P.uFcn = [];
            else
                uNow = u;
                Ad(kc) = S.log.upd(end);
                if ~mandaSTC
                    mandaSTC = true;
                    P.openLoop = [true true true];
                end
                P.uFcn = @(z) uNow;
            end
        else
            uNow = uPI;
        end

        tc(kc) = t;  Yc(:,kc) = y;  Wc(:,kc) = w;
        Uc(:,kc) = uNow;  Lc(kc) = ldc;  Nd(kc) = nodo;
        if ~opt.guardaX, xs(kc,:) = x.';  ts(kc) = t; end
    end

    xd1 = digpte47(t,        x,              P);
    xd2 = digpte47(t+Ts/2,   x + (Ts/2)*xd1, P);
    xd3 = digpte47(t+Ts/2,   x + (Ts/2)*xd2, P);
    xd4 = digpte47(t+Ts,     x +  Ts  *xd3,  P);
    x = x + (Ts/6)*(xd1 + 2*xd2 + 2*xd3 + xd4);
    x = pte47_clamp(x, P);
    t = t + Ts;

    if opt.guardaX, xs(i+1,:) = x.';  ts(i+1) = t; end

    if ~all(isfinite(x)) || ~isreal(x)
        warning('amin_lazo:diverge', ...
            ['Estado no finito o COMPLEJO en t = %g s.  La corrida se corta ' ...
             'ahi y lo devuelto llega solo hasta ese instante.'], t);
        if opt.guardaX, xs = xs(1:i+1,:);  ts = ts(1:i+1); end
        break
    end
end

if ~opt.guardaX, xs = xs(1:kc,:);  ts = ts(1:kc); end
R = struct('t',ts, 'x',xs, 'tc',tc(1:kc), 'Y',Yc(:,1:kc), 'W',Wc(:,1:kc), ...
           'U',Uc(:,1:kc), 'ldc',Lc(1:kc), 'nodo',Nd(1:kc), ...
           'adapt',Ad(1:kc), 'S',S, 'soloPI',soloPI);
R.emax = max(abs(R.Y - R.W), [], 2).';

% INDICES INTEGRALES.  El error maximo esconde el comportamiento: una
% respuesta con un pico y que se asienta puede puntuar peor que otra que no
% se asienta nunca.  IAE e ITAE se calculan sobre la rejilla de control, con
% el paso Tc, y sirven para separar configuraciones que empatan en e_max.
% No son del articulo ---el solo ensena figuras--- y se declaran como tales.
dt = stride*Ts;
e  = abs(R.Y - R.W);
R.iae  = sum(e, 2).' * dt;
R.itae = sum(e .* (ones(3,1)*R.tc), 2).' * dt;
% ISE e ITSE: el error al cuadrado castiga mas las desviaciones grandes; la
% ponderacion por t, igual que en ITAE, castiga lo que tarda en asentarse.
R.ise  = sum(e.^2, 2).' * dt;
R.itse = sum((e.^2) .* (ones(3,1)*R.tc), 2).' * dt;
end

% =========================================================================
function S = carga_nodo_(S, TB, nodo)
%CARGA_NODO_  Sustituye el modelo y el punto de operacion del controlador.
%   Se reemplaza tambien el theta del estimador: si mas tarde se vuelve a
%   encender, tiene que partir del juego correcto, no del anterior.
S = amin_stc_nodo(S, TB.M(nodo));
S.nodoActual = nodo;
end
