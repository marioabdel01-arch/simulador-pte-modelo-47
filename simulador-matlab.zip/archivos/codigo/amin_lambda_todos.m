function LT = amin_lambda_todos(M, varargin)
%AMIN_LAMBDA_TODOS  Barrido de lambda y beta para LOS TRES controladores.
%
%   LT = AMIN_LAMBDA_TODOS(M)
%   LT = AMIN_LAMBDA_TODOS(M, 'lam',[0.25 0.5 1 2 5], 'beta',[0.98 0.99 1])
%
%   AMIN_LAMBDA barre solo el auto-sintonizable (el de la figura 6).  Pero
%   lambda y beta entran tambien en los dos modificados:
%
%     - lambda esta en la ley de control de los tres;
%     - beta es el olvido del estimador, que en el modificado de 20 s se
%       vuelve a encender a los 130 s de llegar a la carga final, y que
%       ademas se usa AL CONSTRUIR LA TABLA POR CARGA (seccion V: el
%       auto-sintonizable se deja trabajar a carga constante en cada nivel).
%
%   Por eso aqui, para cada par (lambda, beta):
%
%     1. se reconstruye la tabla por carga con ESE par (AMIN_TABLA, sin
%        tocar la cache de datos/amin_tabla.mat);
%     2. se corren las dos pruebas con los cuatro controladores (AMIN_RUN);
%     3. se guardan IAE, ITAE, ISE e ITSE de cada controlador, salida y
%        prueba, y si la corrida se corto.
%
%   Para cada controlador c se calcula, como en AMIN_LAMBDA,
%
%       J_c = (1/6) sum_{prueba, salida} indice_c / indice_PI
%
%   y el mejor par de cada controlador segun cada indice, descartando los
%   pares en que alguna de sus dos corridas se corto.
%
%   ES LARGO: cada par reconstruye una tabla (5 niveles x 2000 s) y corre
%   10 simulaciones de 800 s.  Por eso guarda el avance despues de cada par
%   en resultados/amin_lambda_todos.mat y, si se vuelve a llamar con el mismo
%   modelo y la misma rejilla, CONTINUA donde se quedo.
%
%   OPCIONES
%     'lam'      valores de lambda                 [0 0.25 0.5 1 2 5 10 50]
%     'beta'     valores de beta                           [0.95 0.98 0.99 1]
%     'arch'     archivo de avance       [resultados/amin_lambda_todos.mat]
%     'P0'       covarianza inicial en linea                           [1e2]
%     'dur'      duracion de cada prueba, s                            [800]
%     'asentar'  segundos a carga constante al construir la tabla     [2000]
%
%   DEVUELVE  LT.lam, LT.beta, LT.ctrl (nombres), LT.ind (nombres),
%             LT.val.(ctrl).(ind)  (nlam x nbeta x 3 x 2),
%             LT.pi.(ind)          (3 x 2),
%             LT.corto.(ctrl)      (nlam x nbeta x 2),
%             LT.J.(ctrl).(ind)    (nlam x nbeta),
%             LT.mejor.(ctrl).(ind) = [lambda beta],  LT.hecho (nlam x nbeta)
%
%   See also AMIN_LAMBDA, AMIN_TABLA, AMIN_RUN.

opt = struct('lam',[0 0.25 0.5 1 2 5 10 50], 'beta',[0.95 0.98 0.99 1], ...
             'arch',fullfile('resultados','amin_lambda_todos.mat'), 'P0',1e2, ...
             'dur',800, 'asentar',2000);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_lambda_todos:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end
% El barrido del modelo 3x4 va a su propio archivo: si compartiera el del
% 3x3, retomar uno completaria el otro con celdas del modelo equivocado.
if ~isempty(amin_sufijo(M)) && ~any(strcmp(varargin(1:2:end), 'arch'))
    opt.arch = fullfile('resultados', ['amin_lambda_todos' amin_sufijo(M) '.mat']);
end

CT  = {'stc','mstc20','mstc2','tablapura'};   % tablapura: no es del articulo
IND = {'iae','itae','ise','itse'};
nl = numel(opt.lam);  nb = numel(opt.beta);
huella = sum(abs(M.th(:)));

% ------------------------------------------------------------ reanudar
LT = [];
if exist(opt.arch,'file') == 2
    q = load(opt.arch);
    if isfield(q,'LT') && isequal(q.LT.lam, opt.lam(:).') && ...
            isequal(q.LT.beta, opt.beta(:).') && q.LT.huella == huella && ...
            isfield(q.LT,'dur') && q.LT.dur == opt.dur
        LT = q.LT;
        fprintf('Continuando: %d de %d pares ya hechos.\n', nnz(LT.hecho), nl*nb);
        % Avances guardados antes de que se anadiera 'tablapura': se rellena
        % su hueco con NaN (esos pares no la tienen medida).
        for c = 1:numel(CT)
            if ~isfield(LT.val, CT{c})
                for m = 1:numel(IND), LT.val.(CT{c}).(IND{m}) = nan(nl,nb,3,2); end
                LT.corto.(CT{c}) = false(nl,nb,2);
            end
        end
        LT.ctrl = CT;
    end
end
if isempty(LT)
    LT = struct('lam',opt.lam(:).', 'beta',opt.beta(:).', 'huella',huella, 'dur',opt.dur, ...
                'ctrl',{CT}, 'ind',{IND}, 'hecho',false(nl,nb));
    for c = 1:numel(CT)
        for m = 1:numel(IND)
            LT.val.(CT{c}).(IND{m}) = nan(nl,nb,3,2);
        end
        LT.corto.(CT{c}) = false(nl,nb,2);
    end
    for m = 1:numel(IND), LT.pi.(IND{m}) = nan(3,2); end
end
d = fileparts(opt.arch);
if ~isempty(d) && exist(d,'dir') ~= 7, mkdir(d); end

% ------------------------------------------------------------ barrido
t0 = tic;
for q = 1:nl
    for b = 1:nb
        if LT.hecho(q,b), continue; end
        fprintf('lambda %6.2f  beta %5.3f ... ', opt.lam(q), opt.beta(b));
        try
            TB = amin_tabla(M, 'lambda',opt.lam(q), 'beta',opt.beta(b), ...
                            'P0',opt.P0, 'asentar',opt.asentar, 'cache',false, ...
                            'verbose',false);
            R  = amin_run(M, TB, 'lambda',opt.lam(q), 'beta',opt.beta(b), ...
                          'P0',opt.P0, 'dur',opt.dur, 'verbose',false);
            for p = 1:2
                C = R.prueba(p).ctrl;
                for c = 1:numel(CT)
                    X = C.(CT{c});
                    for m = 1:numel(IND)
                        LT.val.(CT{c}).(IND{m})(q,b,:,p) = X.(IND{m});
                    end
                    LT.corto.(CT{c})(q,b,p) = X.t(end) < R.opt.dur - 1e-6;
                end
                if any(isnan(LT.pi.iae(:,p)))
                    for m = 1:numel(IND)
                        LT.pi.(IND{m})(:,p) = C.pi.(IND{m})(:);
                    end
                end
            end
            fprintf('ok  (%.0f s acumulados)\n', toc(t0));
        catch err
            % La tabla puede no construirse si el lazo diverge a carga
            % constante: el par queda marcado como cortado para todos.
            for c = 1:numel(CT), LT.corto.(CT{c})(q,b,:) = true; end
            fprintf('FALLO: %s\n', err.message);
        end
        LT.hecho(q,b) = true;
        save(opt.arch, 'LT', '-v7');
    end
end

% ------------------------------------------------------------ J y mejores
for c = 1:numel(CT)
    vale = ~any(LT.corto.(CT{c}), 3);
    for m = 1:numel(IND)
        J = nan(nl,nb);
        for q = 1:nl
            for b = 1:nb
                r = reshape(LT.val.(CT{c}).(IND{m})(q,b,:,:), 3, 2) ./ LT.pi.(IND{m});
                J(q,b) = mean(r(:));
            end
        end
        LT.J.(CT{c}).(IND{m}) = J;
        Jv = J;  Jv(~vale | isnan(J)) = inf;
        [~, j] = min(Jv(:));  [iq, ib] = ind2sub([nl nb], j);
        LT.mejor.(CT{c}).(IND{m}) = [opt.lam(iq) opt.beta(ib)];
    end
end
save(opt.arch, 'LT', '-v7');

% ------------------------------------------------------------ informe
nomC = struct('stc','auto-sintonizable', 'mstc20','modificado 20 s', ...
              'mstc2','modificado 2 s', 'tablapura','tabla, estim. apagado');
fprintf('\nMEJOR PAR POR CONTROLADOR E INDICE (J = media de indice/indice_PI)\n');
fprintf('%-20s', 'controlador');
for m = 1:numel(IND), fprintf('%-24s', upper(IND{m})); end
fprintf('\n');
for c = 1:numel(CT)
    fprintf('%-20s', nomC.(CT{c}));
    for m = 1:numel(IND)
        o = LT.mejor.(CT{c}).(IND{m});
        Jm = LT.J.(CT{c}).(IND{m})(opt.lam == o(1), opt.beta == o(2));
        fprintf('l=%-5g b=%-5g J=%-8.3g', o(1), o(2), Jm);
    end
    fprintf('\n');
end
fprintf('\nTiempo total de esta llamada: %.0f s\n', toc(t0));
end
