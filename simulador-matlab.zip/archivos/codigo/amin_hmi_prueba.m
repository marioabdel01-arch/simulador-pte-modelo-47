function ok = amin_hmi_prueba()
%AMIN_HMI_PRUEBA  Pruebas del motor de la consola de la replica, sin ventana.
%
%   1. con el modificado de 20 s y la rampa 90 -> 70 % a 10 %/min lanzada a
%      los 10 s, la consola reproduce AMIN_LAZO con la congelacion del
%      articulo [T0, T1 + 130 s]
%   2. lo mismo con el auto-sintonizable (figura 6)
%   3. cambio de PI a controlador de Amin en marcha: arranca en espera, con
%      el PI mandando, y la ley toma el mando al llenar la historia
%   4. vuelta al PI sin salto en los tres mandos
%   5. lambda y beta cambian en vivo
%
%   Se corre desde 7-replica-amin despues de SETUP_AMIN.
%
%   See also AMIN_HMI_MOTOR, AMIN_HMI.

ok = true;
fprintf('\nAMIN_HMI_PRUEBA\n%s\n', repmat('=',1,60));
dur = 400;
q = load(fullfile('datos','amin_modelo.mat'));  Mo = q.M;
q = load(fullfile('datos','amin_tabla.mat'));   TB = q.TB;

[P, info] = amin_rampa(90, 70, 'dur',dur, 'verbose',false);
nombres = {'modificado 20 s','auto-sintonizable'};
for caso = 1:2
    if caso == 1
        [~, i0] = min(abs(TB.pct - 90));
        S = amin_stc_init(TB.M(i0), 'lambda',0.5,'beta',0.99,'adapt',false,'Tc',20);
        R = amin_lazo(S, P, 'tabla',TB, 'congelar',[info.T0, info.T1 + 130]);
        kc = 3;
    else
        M0 = amin_modelo(Mo.th, Mo.N, Mo.nu, Mo.ny, Mo.k, Mo.T, info.ss.u, info.ss.y, NaN, []);
        S = amin_stc_init(M0, 'lambda',0.5,'beta',0.99,'adapt',true,'Tc',20);
        R = amin_lazo(S, P);
        kc = 2;
    end
    M = amin_hmi_motor('crear', 90);
    M = amin_hmi_motor('controlador', M, kc);
    M = amin_hmi_motor('avanzar', M, round(info.T0/0.1));
    M = amin_hmi_motor('demanda', M, 70, 10);
    M = amin_hmi_motor('avanzar', M, round((dur - info.T0)/0.1));
    % salidas en los instantes de control
    tc = R.tc;  Yc = R.Y;
    Yh = interp1(M.log(1:M.nlog,1), M.log(1:M.nlog,[26 27 28]), tc).';
    d = max(abs(Yh - Yc), [], 2).';
    adA = R.adapt(:).';
    adH = M.logC(1:M.nlogC, 8).';
    n = min(numel(adA), numel(adH));
    igualCongelacion = isequal(logical(adA(1:n)), logical(adH(1:n)));
    r = all(d < [1 1 3]) && (caso == 2 || igualCongelacion);
    ok = ok & r;
    fprintf(['  %d %-18s max |dy| contra AMIN_LAZO: %.3f R  %.3f R  %.3f psia;  ' ...
             'misma congelacion: %s   %s\n'], caso, nombres{caso}, d, si_(igualCongelacion), si_(r));
end

% ---- 3 y 4: PI -> Amin en marcha -> PI ---------------------------------
M = amin_hmi_motor('crear', 80);
M = amin_hmi_motor('avanzar', M, 300);
M = amin_hmi_motor('controlador', M, 3);
M = amin_hmi_motor('avanzar', M, 1000);            % 100 s: aun en espera
esp = ~M.mandaSTC;
M = amin_hmi_motor('avanzar', M, 1500);            % 250 s en total: ya manda
manda = M.mandaSTC;
r = esp && manda && isempty(M.error);
ok = ok & r;
fprintf('  3 PI -> modificado en marcha: espera a los 100 s %s, manda a los 250 s %s   %s\n', ...
        si_(esp), si_(manda), si_(r));
u1 = M.uNow(:).';
M = amin_hmi_motor('controlador', M, 1);
salto = max(abs(M.yl(29:31) - u1));
r = salto < 1e-6;
ok = ok & r;
fprintf('  4 vuelta al PI: salto en el mando %.2g V   %s\n', salto, si_(r));

% ---- 5: lambda y beta en vivo -------------------------------------------
M = amin_hmi_motor('controlador', M, 2);
M = amin_hmi_motor('lambda', M, 3);
M = amin_hmi_motor('beta', M, 0.97);
r = M.S.lambda == 3 && M.S.E.beta == 0.97;
M = amin_hmi_motor('avanzar', M, 3000);
r = r && isempty(M.error);
ok = ok & r;
V = amin_hmi_motor('variables', M);
fprintf('  5 lambda = %g y beta = %g en vivo; tras 300 s: cond(B0) %.3g, tr P %.3g   %s\n', ...
        M.S.lambda, M.S.E.beta, V.condB0, V.trP, si_(r));

fprintf('%s\n', repmat('=',1,60));
if ok, fprintf('TODO BIEN.\n'); else, fprintf('HAY FALLOS.\n'); end
end

function s = si_(b)
if b, s = 'bien'; else, s = 'MAL'; end
end
