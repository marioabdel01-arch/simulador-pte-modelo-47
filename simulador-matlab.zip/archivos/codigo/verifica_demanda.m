function ok = verifica_demanda()
%VERIFICA_DEMANDA  Comprobaciones de la prueba con demanda real del SIN.
%
%   OK = VERIFICA_DEMANDA()      (unos 2 min en Octave, segundos en MATLAB)
%
%   1. Perfiles: tres dias de 1441 valores, de 70 a 90 %, que empiezan en 70.
%   2. AMIN_DEMANDA: ldc(t) reproduce el perfil en cada minuto y es lineal
%      entre minutos.
%   3. AMIN_TABLA_EN: en cada nodo da exactamente el modelo de la tabla; a
%      medio camino, el promedio de los dos vecinos.
%   4. AMIN_STC_INTERP congelado en un nodo = AMIN_STC_NODO con reref 'todo'.
%   5. AMIN_CONGELA_MOV: congela con una rampa de 10 %/min, no con 0,05 %/min,
%      y suelta 130 s despues del ultimo movimiento.
%   6. 600 s del STC modificado con la demanda del jueves 20/08/2026 sin
%      errores ni divergencia.
%
%   See also AMIN_DEMANDA, AMIN_TABLA_EN, AMIN_STC_INTERP, AMIN_CONGELA_MOV.

raiz = fileparts(fileparts(mfilename('fullpath')));
antes = pwd;  cd(raiz);  vuelve = onCleanup(@() cd(antes)); %#ok<NASGU>
res = false(1,6);

% 1 ---------------------------------------------------------------------
D = amin_demanda();
r = numel(D.dias) == 3;
for k = 1:3
    p = D.dias(k).pct;
    r = r && numel(p) == 1441 && p(1) == 70 && abs(min(p) - 70) < 1e-12 && abs(max(p) - 90) < 1e-12;
end
res(1) = r;  informa_(1, r, 'tres perfiles de 1441 valores, de 70 a 90 %, que empiezan en 70');

% 2 ---------------------------------------------------------------------
[P, info] = amin_demanda('d2', 'dur',600);
p = info.dia.pct;
tm = (0:1440)*60;
e1 = max(abs(arrayfun(P.ldcFcn, tm) - 0.05*p));
e2 = abs(P.ldcFcn(90) - 0.05*(p(2) + 0.5*(p(3) - p(2))));
r = e1 < 1e-12 && e2 < 1e-12 && P.ldcFcn(1e6) == 0.05*p(end);
res(2) = r;  informa_(2, r, sprintf('ldc(t) = 0,05 pct(t): error %.1e en los minutos, %.1e entre minutos', e1, e2));

% 3 ---------------------------------------------------------------------
s = load(fullfile(raiz,'datos','amin_tabla.mat'));  TB = s.TB;
r = true;
for i = 1:numel(TB.pct)
    Mi = amin_tabla_en(TB, TB.pct(i));
    r = r && cerca_(Mi.th, TB.M(i).th) && cerca_(Mi.u_ss, TB.M(i).u_ss) && cerca_(Mi.y_ss, TB.M(i).y_ss);
end
Mm = amin_tabla_en(TB, 72.5);
r = r && max(abs(Mm.th(:) - (TB.M(1).th(:) + TB.M(2).th(:))/2)) < 1e-12 ...
      && max(abs(Mm.u_ss - (TB.M(1).u_ss + TB.M(2).u_ss)/2)) < 1e-12;
res(3) = r;  informa_(3, r, 'tabla interpolada: igual a la tabla en los nodos (1e-12) y promedio a 72,5 %');

% 4 ---------------------------------------------------------------------
M0 = TB.M(1);
S = amin_stc_init(M0, 'lambda',0.5, 'beta',0.99, 'adapt',false, 'Tc',20);
S.Yh = randn(size(S.Yh));  S.Uh = randn(size(S.Uh));
S1 = amin_stc_interp(S, TB, 0.05*80);
Sr = S;  Sr.reref = 'todo';  S2 = amin_stc_nodo(Sr, TB.M(3));
r = max(abs(S1.Yh(:) - S2.Yh(:))) < 1e-12 && max(abs(S1.Uh(:) - S2.Uh(:))) < 1e-12 ...
    && cerca_(S1.E.th, TB.M(3).th);
res(4) = r;  informa_(4, r, 'interpolada en un nodo = conmutar al nodo re-refiriendo la historia');

% 5 ---------------------------------------------------------------------
g = struct('umbral',1, 'reten',130, 'ult',-inf, 'lPrev',NaN);
S = struct('adapt',true);  dt = 20;
[S, g] = amin_congela_mov(S, g, 0, 3.5, dt);            a0 = S.adapt;
[S, g] = amin_congela_mov(S, g, 20, 3.5 + 0.05*10/3, dt);  a1 = S.adapt;   % 10 %/min
[S, g] = amin_congela_mov(S, g, 140, 3.5 + 0.05*10/3, dt); a2 = S.adapt;   % 120 s quieto
[S, g] = amin_congela_mov(S, g, 160, 3.5 + 0.05*10/3, dt); a3 = S.adapt;   % 140 s quieto
[S, ~] = amin_congela_mov(S, g, 180, 3.5 + 0.05*10/3 + 0.05*0.05/3, dt); a4 = S.adapt;  % 0,05 %/min
r = a0 && ~a1 && ~a2 && a3 && a4;
res(5) = r;  informa_(5, r, 'congela con 10 %/min, no con 0,05 %/min, y suelta a los 130 s');

% 6 ---------------------------------------------------------------------
[P, info] = amin_demanda('d1', 'dur',600);
s = load(fullfile(raiz,'datos','amin_modelo.mat'));  M = s.M;
M0 = TB.M(amin_nodo(TB, info.ss.ldc));
S = amin_stc_init(M0, 'lambda',0.5, 'beta',0.99, 'adapt',false, 'Tc',M.T);
R = amin_lazo(S, P, 'tabla',TB, 'interp',true, 'umbral',info.umbral, 'guardaX',false);
r = numel(R.tc) == 30 && all(isfinite(R.Y(:))) && all(isfinite(R.x(:))) && max(R.emax) < 5;
res(6) = r;  informa_(6, r, sprintf('600 s del STC modificado con el perfil d1: e_max %s', mat2str(R.emax, 3)));

ok = all(res);
fprintf('\nverifica_demanda: %d de %d.\n', sum(res), numel(res));
end

function r = cerca_(a, b)
r = isequal(size(a), size(b)) && max(abs(a(:) - b(:))) <= 1e-12*max(1, max(abs(b(:))));
end

function informa_(i, r, txt)
if r, e = 'ok   '; else, e = 'FALLA'; end
fprintf('  %d  %s  %s\n', i, e, txt);
end
