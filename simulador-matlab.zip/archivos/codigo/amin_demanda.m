function [P, info] = amin_demanda(dia, varargin)
%AMIN_DEMANDA  Prepara la prueba de 24 h con la demanda real del SIN (CENACE).
%
%   [P, INFO] = AMIN_DEMANDA('d1')               jueves 20/08/2026, 24 h
%   [P, INFO] = AMIN_DEMANDA(2, 'dur',43200)     miercoles 11/03/2026, 12 h
%   D = AMIN_DEMANDA()                           los tres perfiles
%
%   La carga sigue, en tiempo real, la demanda horaria del Sistema
%   Interconectado Nacional de un dia real (CENACE, «Estimacion de la Demanda
%   Real del Sistema por Balance»), interpolada cada minuto (PCHIP) y escalada
%   para que el minimo del dia corresponda al 70 % y el maximo al 90 %.  La
%   ventana empieza en la hora de menor demanda; si la carga baja del valle
%   inicial se recorta en 70 % (minimo tecnico).  Es el rango de los
%   estacionarios y de la tabla por carga.
%
%     d1  jueves 20/08/2026     pico de demanda del año, desde las 6:00
%     d2  miercoles 11/03/2026  dia laborable tipico,    desde las 4:00
%     d3  domingo 18/01/2026    fin de semana de invierno, desde las 5:00
%
%   Los perfiles (1441 valores por dia, uno por minuto) estan en
%   datos/demanda_sin.mat.  Entre minutos, la demanda es lineal en t:
%   ldc(t) = 0,05 * pct(t), continua, como en AMIN_RAMPA.
%
%   La corrida arranca del estacionario al 70 % (AMIN_ESTACIONARIO).
%
%   INFO trae T0 = 0, T1 (fin del perfil), dia, perfil, el estacionario y el
%   umbral y la retencion de la congelacion del STC modificado
%   (AMIN_CONGELA_MOV: 1 %/min y 130 s).
%
%   See also AMIN_RAMPA, AMIN_LAZO, AMIN_STC_INTERP, AMIN_CONGELA_MOV.

opt = struct('dur',86400, 'verbose',false);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_demanda:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end
raiz = fileparts(fileparts(mfilename('fullpath')));
D = load(fullfile(raiz, 'datos', 'demanda_sin.mat'));
if nargin == 0, P = D;  return, end
if ischar(dia)
    k = find(strcmp({D.dias.clave}, dia), 1);
else
    k = dia;
end
if isempty(k) || k < 1 || k > numel(D.dias)
    error('amin_demanda:dia', 'Dia desconocido (use ''d1'', ''d2'' o ''d3'').');
end
pf = D.dias(k);
% Nombres para mostrar (con acentos aqui y no en el .mat, para que MATLAB y
% Octave lean el archivo igual).
nom = {'jueves 20/08/2026', 'miércoles 11/03/2026', 'domingo 18/01/2026'};
nota = {'pico de demanda del año', 'día laborable típico', 'fin de semana de invierno'};
pf.nombre = nom{k};  pf.nota = nota{k};

Si = amin_estacionario(pf.pct(1), 'verbose',opt.verbose);
ldc0 = 0.05*pf.pct(1);
P = amin_planta(Si.base, 'ldcStart',ldc0, 'ldcRate',0, 'ldcT0',0, 'ldcT1',0, ...
                'samples', round(opt.dur/0.1)+1);
P.ldcFcn = @(t) 0.05*perfil_(pf.pct, pf.dt, t);
P.x0 = Si.x0;
P.ldc = ldc0;

info = struct('pctIni',pf.pct(1), 'pctFin',pf.pct(end), 'T0',0, ...
              'T1',(numel(pf.pct)-1)*pf.dt, 'dur',opt.dur, 'ss',Si, ...
              'ldc0',ldc0, 'dia',pf, 'fuente',D.fuente, ...
              'umbral',1, 'reten',130);
if opt.verbose
    fprintf('demanda real del SIN, %s (%s): %g s desde las %s h\n', ...
            pf.nombre, pf.nota, opt.dur, pf.inicio);
end
end

% =========================================================================
function v = perfil_(pct, dt, t)
%PERFIL_  Interpolacion lineal entre los valores de cada minuto.
k = t/dt;  n = numel(pct) - 1;
if k <= 0
    v = pct(1);
elseif k >= n
    v = pct(n+1);
else
    i = floor(k);  a = k - i;
    v = pct(i+1) + a*(pct(i+2) - pct(i+1));
end
end
