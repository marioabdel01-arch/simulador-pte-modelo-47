function D = amin_retardos(varargin)
%AMIN_RETARDOS  Los retardos entrada-salida en lazo abierto (seccion IV).
%
%   D = AMIN_RETARDOS
%   D = AMIN_RETARDOS('pct',75, 'paso',[0.1 0.3 0.6], 'dur',200)
%
%   Reproduce el experimento con el que el articulo fija k:
%
%     «To compute k, the time delays between the inputs and outputs are
%      determined by having the system operate at a steady state and by
%      introducing, in open loop, a step change in one of the inputs while
%      the other two inputs are kept at their steady state values.  The
%      largest time delay of 20 seconds was between CWSY and TRHO.»
%
%   y con el que despues concluye, con T = 20 s, que k = 1:
%
%     «The value of k [...] is determined by dividing the largest time delay
%      by the sampling time and then setting k equal to the integer which is
%      greater than the quotient by less than 1 or is equal to the quotient.»
%
%   MEDIDA DEL RETARDO.  El articulo no dice como lo mide.  Aqui se toma el
%   primer instante en que la salida se separa de su valor de estado estable
%   mas que `umbral` veces su excursion total en la corrida.  Es el criterio
%   mas conservador y se declara: con otro umbral el numero cambia, y eso
%   forma parte de lo que hay que reportar (README, hueco 5).
%
%   DEVUELVE  D.tau (3 x 3, salida x entrada, en segundos), D.tauMax,
%             D.k (con T = 20 s), D.umbral
%
%   See also AMIN_DATOS, AMIN_ESTACIONARIO.

opt = struct('pct',75, 'paso',[0.1 0.3 0.6], 'dur',200, 'umbral',0.02, ...
             'verbose',true);
for i = 1:2:numel(varargin)
    if ~isfield(opt, varargin{i})
        error('amin_retardos:opcion','opcion desconocida: %s', varargin{i});
    end
    opt.(varargin{i}) = varargin{i+1};
end

S = amin_estacionario(opt.pct, 'verbose',opt.verbose);
nomU = {'CBMD','CXGG','CWSY'};
nomY = {'TSSO','TRHO','PSSO'};
Ts = 0.1;  n = round(opt.dur/Ts);

D = struct('tau',nan(3,3), 'nomU',{nomU}, 'nomY',{nomY}, ...
           'umbral',opt.umbral, 'pct',opt.pct);

for e = 1:3
    uNow = S.u(:);  uNow(e) = uNow(e) + opt.paso(e);
    P = amin_planta(S.base, 'ldcStart',S.ldc, 'ldcRate',0, ...
                     'ldcT0',0, 'ldcT1',0, 'samples',n+1);
    P.x0 = S.x0;  P.ldc = S.ldc;
    P.openLoop = [true true true];
    P.uFcn = @(z) uNow;

    x = S.x0(:);  t = 0;
    Y = nan(3, n+1);  tv = nan(1, n+1);
    for i = 1:n+1
        [~, yl] = digpte47(t, x, P);
        Y(:,i) = yl(26:28).';  tv(i) = t;
        if i > n, break, end
        xd1 = digpte47(t,      x,              P);
        xd2 = digpte47(t+Ts/2, x + (Ts/2)*xd1, P);
        xd3 = digpte47(t+Ts/2, x + (Ts/2)*xd2, P);
        xd4 = digpte47(t+Ts,   x +  Ts  *xd3,  P);
        x = x + (Ts/6)*(xd1 + 2*xd2 + 2*xd3 + xd4);
        x = pte47_clamp(x, P);
        t = t + Ts;
        if ~all(isfinite(x)) || ~isreal(x)
            warning('amin_retardos:diverge', ...
                'Escalon en %s: estado no finito o complejo en t = %g s.', ...
                nomU{e}, t);
            Y = Y(:,1:i);  tv = tv(1:i);
            break
        end
    end

    for s = 1:3
        d = abs(Y(s,:) - S.y(s));
        r = max(d);
        if r <= 0, continue, end
        j = find(d >= opt.umbral*r, 1, 'first');
        if ~isempty(j), D.tau(s,e) = tv(j); end
    end
    if opt.verbose
        fprintf('escalon en %s (+%.2f V):  retardo a %s %5.1f s, %s %5.1f s, %s %5.1f s\n', ...
                nomU{e}, opt.paso(e), nomY{1}, D.tau(1,e), ...
                nomY{2}, D.tau(2,e), nomY{3}, D.tau(3,e));
    end
end

D.tauMax = max(D.tau(:));
D.k20 = max(1, ceil(D.tauMax/20));
if opt.verbose
    fprintf('\nretardo maximo medido %.1f s  ->  k = %d con T = 20 s\n', ...
            D.tauMax, D.k20);
    fprintf('Amin: 20 s entre CWSY y TRHO  ->  k = 1\n');
end
end
