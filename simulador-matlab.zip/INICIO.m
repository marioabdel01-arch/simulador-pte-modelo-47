function INICIO(modo)
%INICIO  Simulador Planta Termoeléctrica modelo de orden 47.
%        Réplica de Amin, Masada y Womack (1984): abre el simulador.
%
%   Abrir MATLAB en esta carpeta y escribir
%
%       >> INICIO
%
%   (o abrir este archivo y pulsar «Run»).  No hace falta ningún paso previo:
%   ni setup_amin, ni verificaciones, ni identificar el modelo.  El modelo AR
%   y la tabla por carga ya están calculados en archivos/datos/.
%
%   Se abre el SIMULADOR.  Para correr una prueba del artículo:
%
%     1. «Prueba»: 90 -> 70 % o 70 -> 90 % (rampas de 10 %/min), o uno de
%        los tres días de demanda real del SIN (24 h en tiempo real, 70-90 %;
%        ver AMIN_DEMANDA)
%     2. «Controlador»: PI de Usoro, auto-sintonizable (fig. 6), modificado
%        con tabla por carga (fig. 7), modificado con mando cada 2 s, ...
%     3. «Iniciar».  La planta de 47 estados se simula en vivo; la pestaña
%        «Resumen» muestra las tres salidas y los mandos, y la tabla de abajo
%        los índices IAE e ITAE contra el PI de Usoro.
%
%   Otras opciones:
%     INICIO('figuras')     las figuras 6 a 9 del artículo y la tabla de
%                           índices, con los resultados ya calculados
%                           (instantáneo, sin simular)
%     INICIO('consola')     la consola de operación tipo HMI (demanda libre,
%                           cambio de controlador en marcha, emergencias)
%     INICIO('recalcular')  vuelve a simular las dos pruebas con los cinco
%                           controladores (5 a 20 min) y dibuja las figuras
%
%   Requiere MATLAB R2021b o posterior para el simulador y la consola.
%
%   Configuración de la réplica (lo que el artículo no publica se declara):
%     modelo AR 3x3, N = 5, k = 1, T = 20 s, identificado al 75 % de carga;
%     lambda = 0,5 y beta = 0,99 (no están en el artículo), P(0) en línea =
%     la covarianza con que termina la identificación (AMIN_COVARIANZA);
%     en el modificado, estimador congelado de T0 a T1 + 130 s.
%
%   Esta carpeta solo contiene INICIO.m.  Todo lo demás (código, copia del
%   modelo de planta, datos, resultados) está en la carpeta «archivos»;
%   no hace falta abrirla.  Documentación completa: archivos/README.md.

if nargin < 1 || isempty(modo), modo = 'simulador'; end

% Todo lo de la replica vive en la subcarpeta «archivos».  Si no existe
% (copias anteriores de la carpeta), se busca al lado de este archivo.
aqui = fileparts(mfilename('fullpath'));
if exist(fullfile(aqui,'archivos','codigo'),'dir') == 7
    aqui = fullfile(aqui,'archivos');
end
addpath(fullfile(aqui,'codigo'), fullfile(aqui,'planta','codigo'), ...
        fullfile(aqui,'planta','funciones'));

switch lower(modo)
    case 'simulador'
        amin_sim;
        return
    case 'consola'
        amin_hmi;
        return
    case {'figuras','recalcular'}
    otherwise
        error('INICIO:modo', ['Opción desconocida: «%s».  Use INICIO, ' ...
              'INICIO(''figuras''), INICIO(''consola'') o INICIO(''recalcular'').'], modo);
end

arch = fullfile(aqui, 'resultados', 'amin_resultados.mat');
if strcmpi(modo, 'recalcular') || exist(arch, 'file') ~= 2
    R = recalcula_(aqui, arch);
else
    q = load(arch);  R = q.R;
    if ~ischar(R.config.P0)
        % Resultados de antes del 2026-10-04, con P(0) = 100·I: se rehacen
        % con la P(0) heredada, que es la configuracion vigente.
        fprintf('\nLos resultados guardados son con P(0) = %g·I; se recalculan.\n', R.config.P0);
        R = recalcula_(aqui, arch);
    end
end

cabecera_(R);
figura_salidas_(R, {'pi','stc'}, {'PI de Usoro','auto-sintonizable'}, ...
    'Figura 6', 'Figura 6.  Respuesta a la rampa de carga de 10 %/min: PI contra auto-sintonizable');
figura_salidas_(R, {'pi','mstc20'}, {'PI de Usoro','auto-sintonizable modificado'}, ...
    'Figura 7', 'Figura 7.  PI contra el auto-sintonizable modificado');
figura_mandos_(R, {'pi','stc','mstc20'}, {'PI de Usoro','auto-sintonizable','modificado'}, ...
    'Figura 8', 'Figura 8.  Mandos calculados por cada controlador');
figura_salidas_(R, {'mstc20','mstc2'}, {'modificado, mando cada 20 s','modificado, mando cada 2 s'}, ...
    'Mando 2 s', 'Mando cada 2 s contra cada 20 s (el artículo describe el caso pero no publica sus figuras)');
figura_indices_(R);
end

% =========================================================================
function R = recalcula_(aqui, arch)
anterior = cd(aqui);
vuelve = onCleanup(@() cd(anterior));
fprintf('\nSimulando las dos pruebas con los cinco controladores...\n');
fprintf('(de 5 a 20 minutos; el avance se imprime abajo)\n\n');
q = load(fullfile('datos','amin_modelo.mat'));  M = q.M;
q = load(fullfile('datos','amin_tabla.mat'));   TB = q.TB;
Rc = amin_run(M, TB, 'lambda',0.5, 'beta',0.99, 'dur',800, 'verbose',true);
R = aligera_(Rc, M);
if exist(fileparts(arch),'dir') ~= 7, mkdir(fileparts(arch)); end
save(arch, 'R', '-v7');
fprintf('\nResultados guardados en %s\n', arch);
end

function R = aligera_(Rc, M)
%ALIGERA_  Solo lo que hace falta para las figuras y los indices.
R = struct();
P0 = Rc.opt.P0;  if ~isscalar(P0), P0 = 'heredada'; end
R.config = struct('lambda',Rc.opt.lambda, 'beta',Rc.opt.beta, 'P0',P0, ...
                  'dur',Rc.opt.dur, 'N',M.N, 'k',M.k, 'T',M.T, ...
                  'fecha',datestr(now,'yyyy-mm-dd HH:MM')); %#ok<TNOW1,DATST>
campos = {'tc','Y','W','U','ldc','iae','itae','emax'};
for p = 1:numel(Rc.prueba)
    R.prueba(p).nombre = Rc.prueba(p).nombre;
    f = fieldnames(Rc.prueba(p).ctrl);
    for c = 1:numel(f)
        X = Rc.prueba(p).ctrl.(f{c});
        for k = 1:numel(campos)
            R.prueba(p).ctrl.(f{c}).(campos{k}) = X.(campos{k});
        end
    end
end
end

% =========================================================================
function cabecera_(R)
c = R.config;
fprintf('\n');
fprintf('RÉPLICA DE AMIN, MASADA Y WOMACK (1984)\n');
fprintf('Application of a Multivariable Self-Tuning Controller to a Power Plant Boiler\n');
fprintf('Planta: modelo de 47 estados de Usoro (1977), caldera de 600 MW\n');
fprintf('%s\n', repmat('-',1,78));
fprintf('Pruebas: rampas de carga 90 -> 70 %% y 70 -> 90 %% a 10 %%/min, %g s\n', c.dur);
fprintf('Modelo AR: 3x3, N = %d, k = %d, T = %g s, identificado al 75 %% de carga\n', c.N, c.k, c.T);
if ischar(c.P0), tP = 'heredada de la identificación'; else, tP = sprintf('%g·I', c.P0); end
fprintf('lambda = %s  y  beta = %s  (el artículo no da estos valores),  P(0) %s\n', ...
        num_(c.lambda,'%g'), num_(c.beta,'%g'), tP);
fprintf('Ejes de las figuras: arrancan en los del artículo (1440-1520 R, 2200-2600 psia)\n');
fprintf('y se ensanchan sólo si una curva se sale de ese rango.\n');
fprintf('%s\n\n', repmat('-',1,78));
end

% =========================================================================
function figura_salidas_(R, cs, et, nombre, titulo)
C = colores_();
nomY = {'TSSO  (°R)', 'TRHO  (°R)', 'PSSO  (psia)'};
limY = {[1440 1520], [1440 1520], [2200 2600]};
f = figure('Name',nombre, 'NumberTitle','off', 'Color','w', 'Position',[40 40 1100 800]);
for p = 1:2
    for s = 1:3
        subplot(3,2,(s-1)*2 + p);  hold on
        X = R.prueba(p).ctrl;
        h = plot(X.(cs{1}).tc, X.(cs{1}).W(s,:), 'k--', 'LineWidth',1.0);
        for q = 1:numel(cs)
            h(end+1) = plot(X.(cs{q}).tc, X.(cs{q}).Y(s,:), '-', ...
                            'Color',C{q}, 'LineWidth',1.7); %#ok<AGROW>
        end
        xlim([0 R.config.dur]);
        v = X.(cs{1}).W(s,:);
        for q = 1:numel(cs), v = [v, X.(cs{q}).Y(s,:)]; end %#ok<AGROW>
        ylim(ejes_(limY{s}, v));
        grid on;  box off
        ylabel(nomY{s});
        if s == 1, title(['Prueba ' strrep(R.prueba(p).nombre,'->','→')]); end
        if s == 3, xlabel('tiempo (s)'); end
    end
end
estilos = [{'k--'}, repmat({'-'},1,numel(cs))];
cols = [{[0 0 0]}, C(1:numel(cs))];
leyenda_(f, [{'consigna'}, et], estilos, cols);
titulo_(f, titulo);
end

function L = ejes_(L, v)
%EJES_  Los ejes del articulo, ensanchados si alguna curva se sale.
v = v(isfinite(v));
if ~isempty(v), L = [min(L(1), min(v)), max(L(2), max(v))]; end
L = L + [-1 1]*0.02*(L(2) - L(1));
end

function leyenda_(f, et, estilos, cols)
%LEYENDA_  Una sola leyenda, abajo y fuera de las graficas, para no tapar
%   ninguna curva.
a = axes(f, 'Position',[0.10 0.005 0.80 0.035], 'Visible','off');
hold(a, 'on');
h = zeros(1, numel(et));
for i = 1:numel(et)
    h(i) = plot(a, nan, nan, estilos{i}, 'Color',cols{i}, 'LineWidth',1.7);
end
legend(a, h, et, 'Orientation','horizontal', 'Location','north', 'Box','off');
end

function figura_mandos_(R, cs, et, nombre, titulo)
C = colores_();
nomU = {'CBMD  (V)', 'CXGG  (V)', 'CWSY  (V)'};
f = figure('Name',nombre, 'NumberTitle','off', 'Color','w', 'Position',[60 60 1100 800]);
for p = 1:2
    for s = 1:3
        subplot(3,2,(s-1)*2 + p);  hold on
        X = R.prueba(p).ctrl;
        h = [];
        for q = 1:numel(cs)
            h(end+1) = plot(X.(cs{q}).tc, X.(cs{q}).U(s,:), '-', ...
                            'Color',C{q}, 'LineWidth',1.5); %#ok<AGROW>
        end
        xlim([0 R.config.dur]);  ylim([0.8 5.2]);
        grid on;  box off
        ylabel(nomU{s});
        if s == 1, title(['Prueba ' strrep(R.prueba(p).nombre,'->','→')]); end
        if s == 3, xlabel('tiempo (s)'); end
    end
end
leyenda_(f, et, repmat({'-'},1,numel(cs)), C(1:numel(cs)));
titulo_(f, titulo);
end

function titulo_(f, s)
try
    sgtitle(f, s, 'FontWeight','bold');
catch
    annotation(f, 'textbox', [0 0.955 1 0.04], 'String',s, 'EdgeColor','none', ...
               'HorizontalAlignment','center', 'FontWeight','bold');
end
end

function C = colores_()
C = {[0.45 0.45 0.45], [0.20 0.45 0.80], [0.85 0.40 0.10], [0.50 0.25 0.65]};
end

% =========================================================================
function figura_indices_(R)
%FIGURA_INDICES_  IAE e ITAE por salida, y el cociente promedio contra el PI.
nom = {'pi','stc','mstc20','mstc2','tablapura'};
et  = {'PI de Usoro', 'Autosintonizable (fig. 6)', 'Modificado, mando 20 s (fig. 7)', ...
       'Modificado, mando 2 s (no publicada)', 'Tabla, estimador apagado (*)'};
hay = isfield(R.prueba(1).ctrl, nom);
nom = nom(hay);  et = et(hay);
sal = {'TSSO','TRHO','PSSO'};
filas = {};  datos = {};
for p = 1:2
    B = R.prueba(p).ctrl.pi;
    for c = 1:numel(nom)
        X = R.prueba(p).ctrl.(nom{c});
        r = X.iae ./ B.iae;
        fila = {R.prueba(p).nombre, et{c}};
        for s = 1:3, fila{end+1} = num_(X.iae(s),'%.4g'); end %#ok<AGROW>
        for s = 1:3, fila{end+1} = num_(X.itae(s),'%.4g'); end %#ok<AGROW>
        fila{end+1} = num_(mean(r),'%.2f'); %#ok<AGROW>
        datos(end+1,:) = fila; %#ok<AGROW>
    end
end
col = [{'prueba','controlador'}, strcat('IAE ', sal), strcat('ITAE ', sal), {'IAE / IAE PI'}];

% J de las dos pruebas juntas
J = zeros(1,numel(nom));
for c = 1:numel(nom)
    r = [];
    for p = 1:2
        r = [r, R.prueba(p).ctrl.(nom{c}).iae ./ R.prueba(p).ctrl.pi.iae]; %#ok<AGROW>
    end
    J(c) = mean(r);
end

% ---- en la ventana de comandos ---------------------------------------------
fprintf('ÍNDICES (integrados en los %g s de cada prueba)\n', R.config.dur);
fprintf('%-10s %-34s %10s %10s %10s   %8s\n', 'prueba', 'controlador', ...
        'IAE TSSO', 'IAE TRHO', 'IAE PSSO', 'IAE/PI');
for i = 1:size(datos,1)
    fprintf('%-10s %-34s %10s %10s %10s   %8s\n', datos{i,1}, datos{i,2}, ...
            datos{i,3}, datos{i,4}, datos{i,5}, datos{i,9});
end
fprintf('\nJ = promedio de IAE / IAE del PI en las 3 salidas y las 2 pruebas');
fprintf(' (< 1 mejora al PI):\n');
for c = 1:numel(nom)
    fprintf('   %-34s J = %s\n', et{c}, num_(J(c),'%.3f'));
end
fprintf('(*) no es del artículo: la tabla por carga sin reidentificar nunca.\n\n');

% ---- en una ventana ------------------------------------------------------------
f = figure('Name','Índices', 'NumberTitle','off', 'Color','w', ...
           'Position',[80 80 1150 520], 'MenuBar','none');
try
    uitable(f, 'Data',datos, 'ColumnName',col, 'RowName',[], ...
            'Units','normalized', 'Position',[0.01 0.30 0.98 0.68], ...
            'ColumnWidth',{70, 230, 75, 75, 75, 80, 80, 80, 90});
catch
end
txt = {'J = promedio de IAE / IAE del PI en las 3 salidas y las 2 pruebas (< 1 mejora al PI):'};
for c = 2:numel(nom)
    txt{end+1} = sprintf('      %s:   J = %s', et{c}, num_(J(c),'%.2f')); %#ok<AGROW>
end
txt{end+1} = '(*) No es del artículo: la tabla por carga sin reidentificar nunca.';
annotation(f, 'textbox', [0.01 0.01 0.98 0.24], 'String',txt, ...
           'EdgeColor','none', 'FontSize',10, 'VerticalAlignment','bottom');
end

function s = num_(v, fmt)
s = strrep(sprintf(fmt, v), '.', ',');
end
